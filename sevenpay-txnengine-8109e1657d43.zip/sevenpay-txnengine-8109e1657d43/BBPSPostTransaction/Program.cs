﻿using Confluent.Kafka;
using Domains.Entities.Common;
using Domains.Entities.DMT.Transaction;
using Engine.Events.BBPS;
using Engine.Events.DMT;
using Logger;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Net;
using System.Text.Json;

namespace BBPSPostTransaction
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World from BBPS Post Transaction");

			var serviceProvider = new ServiceCollection()
				// Add your services here..
				.AddSingleton<ICustomLogger, CustomLogger>()
				.BuildServiceProvider();
			// Now get Your Services like this
			var demoService = serviceProvider.GetRequiredService<ICustomLogger>();

			//code to read the configuration from appsetting.json
			IConfiguration config = new ConfigurationBuilder()
				.AddJsonFile("appsettings.json")
				.AddEnvironmentVariables()
				.Build();

			// Get values from the config, given their key and their target type.
			ProducerConfig pconfig = config.GetRequiredSection("ProducerConfig").Get<ProducerConfig>();
			ConsumerConfig cconfig = config.GetRequiredSection("ConsumerConfig").Get<ConsumerConfig>();
			string postpath = config.GetRequiredSection("PostPath").Get<string>();

			BBPSPostProcess bbpsPostProcess = new BBPSPostProcess(pconfig, cconfig, postpath);
			bbpsPostProcess.Init();
		}

		public class BBPSPostProcess
		{
			private static ProducerConfig _pconfig;
			private static ConsumerConfig _cconfig;
			private static string _path;

			//logger 
			private readonly ICustomLogger _logger;

			public BBPSPostProcess(ProducerConfig pconfig, ConsumerConfig cconfig, string path)
			{
				_cconfig = cconfig;
				_pconfig = pconfig;
				_path = path;
				_logger = new CustomLogger("PostBBPSLog");
			}

			public void Init()
			{
				//code added by swapnal and running on different thread for health checkup
				Task.Factory.StartNew(() => new HealthCheckService(), TaskCreationOptions.PreferFairness);

				// queue init );
				using (var _consumer = new ConsumerBuilder<Ignore, string>(_cconfig).Build())
				{
					_consumer.Subscribe("BBPSPostTransaction");

					CancellationTokenSource cts = new CancellationTokenSource();
					Console.CancelKeyPress += (_, e) =>
					{
						e.Cancel = true; // prevent the process from terminating.
						cts.Cancel();
					};

					try
					{
						while (true)
						{
							try
							{
								var _message = _consumer.Consume(cts.Token);
								Console.WriteLine($"Consumed message '{_message.Message.Value}' at: '{_message.TopicPartitionOffset}'.");
								_consumer.Commit(_message);

								//code to decode the values
								if (_message != null)
								{
									BBPSPreTransactionUpdatedEvent? _responseModel = JsonSerializer.Deserialize<BBPSPreTransactionUpdatedEvent>(_message.Message.Value);

									if (_responseModel != null)
									{
										//var _postTransactionModel = new BBPSTransactionResponseModel
										//{
										//	p_txnid = int.Parse(_responseModel.TransactionId.ToString()),
										//	p_txnstatus = _responseModel.responseModel.p_txnstatus,
										//	p_supptxnnumber = _responseModel.responseModel.p_supptxnnumber,
										//	p_userid = _responseModel.request.channelPartnerInfo.userId,
										//	p_remarks = _responseModel.responseModel.p_remarks,
										//	p_sprefno = _responseModel.responseModel.p_sprefno,
										//	p_apprefno = _responseModel.responseModel.p_apprefno,
										//	p_custref5 = _responseModel.responseModel.p_custref5,
										//	p_modifieripaddress = "NA"
										//};

										//code added by swapnal for transaction status
										//if (_postTransactionModel.p_txnstatus == 0 && _postTransactionModel.p_trndes.Contains("Successful")) //succesful transaction
										//{ 
										//}
										//if (_postTransactionModel.p_txnstatus != 0 && _postTransactionModel.p_trndes.Contains("pending")) //pending transaction
										//	_postTransactionModel.p_txnstatus = 6; //transaction updated as pending

										//if (_postTransactionModel.p_txnstatus != 0 || _postTransactionModel.p_trndes.Contains("Failed"))
										//	_postTransactionModel.p_txnstatus = 6; //transaction updated as failed


										if (_responseModel.responseModel != null)
										{
											//var _inputData = JsonSerializer.Serialize(_postTransactionModel);

											try
											{
												//code to call the API from here
												using (var client = new WebClient())
												{
													client.Headers.Add("Content-Type:application/json");
													client.Headers.Add("Accept:*/*");
													var result = client.UploadString(_path, JsonSerializer.Serialize(_responseModel.responseModel)); //"https://localhost:7268/api/DMTTransaction/PostFundTransfer"
													Console.WriteLine(result);
												}
											}
											catch (Exception ex)
											{
												_logger.LogInfo("Exception:" + ex.Message.ToString());
												Console.WriteLine("Exception " + DateTime.Now + " " + ex.Message.ToString());
												//throw;
											}

											//code added by swapnal to raise the mobile notification event
											TransactionNotificationModel notificationModel = new TransactionNotificationModel
											{
												transactionId = _responseModel.responseModel.p_txnid,
												message = _responseModel.responseModel.p_remarks,
												responseCode = _responseModel.responseModel.p_txnstatus.ToString(),
												operatorReferenceId = _responseModel.responseModel.p_supptxnnumber,
												updatedOn = DateTime.Now
											};

											string _notificationMsg = JsonSerializer.Serialize(notificationModel);
											TransactionsQueueReceiveCompleted(_notificationMsg);
										}
									}
								}
							}
							catch (ConsumeException ex)
							{
								_logger.LogInfo("Exception:" + ex.Message.ToString());
								Console.WriteLine($"Error occured: {ex.Error.Reason}");
							}
						}
					}
					catch (OperationCanceledException)
					{
						// Close and Release all the resources held by this consumer  
						_consumer.Close();
					}
				}
				//End Code Accounting queue init

				while (Console.ReadKey().Key != ConsoleKey.Q)
				{
					//Console.WriteLine("Transaction Processing Engine exits gracefully.......");
				}
			}
			private void TransactionsQueueReceiveCompleted(string message)
			{
				object LockObject = new object();
				Console.WriteLine("Hey Delegate called !!!!!!!!!!!!!!!!");
				try
				{
					lock (LockObject)
					{
						//Thread.Sleep(5);

						using (var _publish = new ProducerBuilder<Null, string>(_pconfig).Build())
						{
							try
							{
								var _message = _publish.ProduceAsync("MobileNotification", new Message<Null, string> { Value = message });
								//var _message =  _publish.Produce("DMTPostTransaction", new Message<Null, string> { Value = message },null);
								//Console.WriteLine($"Delivered '{_message.Result.Value}' to '{_message.Result.TopicPartitionOffset}'");
								_publish.Flush();
								//Thread.Sleep(50000);
							}
							catch (ProduceException<Null, string> e)
							{
								_logger.LogInfo("Exception:" + e.Message.ToString());
								Console.WriteLine($"Delivery failed: {e.Error.Reason}");
							}
						}
					}
				}
				catch (Exception exception)
				{
					_logger.LogInfo("Exception:" + exception.Message.ToString());
					Console.WriteLine("ERROR  { QueueReceiveCompleted }-> " + exception.Message);
				}
			}
		}
	}
}

