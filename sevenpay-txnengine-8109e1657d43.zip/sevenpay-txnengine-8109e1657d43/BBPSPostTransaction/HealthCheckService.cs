﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BBPSPostTransaction
{
	public class HealthCheckService
	{
		public HealthCheckService()
		{
			//code added by swapnal for health check up
			using var listener = new HttpListener();
			listener.Prefixes.Add("http://*:8003/");

			listener.Start();

			Console.WriteLine("Listening on port 8003...");

			while (true)
			{
				HttpListenerContext ctx = listener.GetContext();
				using HttpListenerResponse resp = ctx.Response;
				string? path = ctx.Request.Url?.LocalPath;

				if (path == "/health/status")
				{
					resp.StatusCode = (int)HttpStatusCode.OK;
					resp.StatusDescription = "Status OK";


					// Get the data from the HTTP stream
					var body = new StreamReader(ctx.Request.InputStream).ReadToEnd();

					byte[] b = Encoding.UTF8.GetBytes("health ok");
					ctx.Response.StatusCode = 200;
					ctx.Response.KeepAlive = false;
					ctx.Response.ContentLength64 = b.Length;

					var output = ctx.Response.OutputStream;
					output.Write(b, 0, b.Length);
					ctx.Response.Close();
				}
			}
		}
	}
}
