﻿using AEPSLibrary;
using AEPSLibrary.PaySprint;
using AEPSLibrary.YesBank;
using Confluent.Kafka;
using Domains.Entities.AEPS;
using Engine.Events.AEPS;
using Logger;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System.Linq.Expressions;
using System.Net;

namespace AEPSCashWithdrawal
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World from AEPS");

			var serviceProvider = new ServiceCollection()
				// Add your services here..
				.AddSingleton<ICustomLogger, CustomLogger>()
				.BuildServiceProvider();
			// Now get Your Services like this
			var demoService = serviceProvider.GetRequiredService<ICustomLogger>();

			//code to read the configuration from appsetting.json
			IConfiguration config = new ConfigurationBuilder()
				.AddJsonFile("appsettings.json")
				.AddEnvironmentVariables()
				.Build();

			// Get values from the config, given their key and their target type.
			ProducerConfig pconfig = config.GetRequiredSection("ProducerConfig").Get<ProducerConfig>();
			ConsumerConfig cconfig = config.GetRequiredSection("ConsumerConfig").Get<ConsumerConfig>();


			AEPSProcess aepsProcess = new AEPSProcess(pconfig, cconfig);
			aepsProcess.Init();

		}
	}

	public class AEPSProcess
	{
		private static ProducerConfig _pconfig;
		private static ConsumerConfig _cconfig;
		//logger 
		private readonly ICustomLogger _logger;

		public AEPSProcess(ProducerConfig pconfig, ConsumerConfig cconfig)
		{
			_cconfig = cconfig;
			_pconfig = pconfig;
			_logger = new CustomLogger("PreAEPSLog");
		}

		public void Init()
		{
			//code added by swapnal and running on different thread for health checkup
			Task.Factory.StartNew(() => new HealthCheckService(), TaskCreationOptions.PreferFairness);

			// queue init );
			using (var _consumer = new ConsumerBuilder<Ignore, string>(_cconfig).Build())
			{
				_consumer.Subscribe("AEPSpreTransaction");

				CancellationTokenSource cts = new CancellationTokenSource();
				Console.CancelKeyPress += (_, e) => {
					e.Cancel = true; // prevent the process from terminating.
					cts.Cancel();
				};

				try
				{
					while (true)
					{
						try
						{
							var _postTransactionModel = new AEPSPostTransactionRequestModel();
							var _message = _consumer.Consume(cts.Token);
							Console.WriteLine($"Consumed message '{_message.Message.Value}' at: '{_message.TopicPartitionOffset}'.");
							_consumer.Commit(_message);
							_logger.LogInfo("Request : " + _message.Message.Value);
							//code to write the logs

							//code commented by swapnal
							var _aepsModel = System.Text.Json.JsonSerializer.Deserialize<AEPSPreTransactionCreatedEvent>(_message.Message.Value);
							Console.WriteLine(_aepsModel);

							switch (_aepsModel.request.product.serviceId)
							{
								case 200:
									// code block for pay sprint
									IAEPSTransaction paysprintAEPSTransaction = new PaySprintTransaction();
									var withdrawalRequestModel = new WithdrawalRequestModel {
										latitude = _aepsModel.request.location.lat,
										longitude = _aepsModel.request.location.lang,
										ipaddress = _aepsModel.request.location.ip,
										mobilenumber = _aepsModel.request.transactionInfo.transactionData.mobilenumber,
										referenceno = _aepsModel.TransactionId.ToString(),
										adhaarnumber = _aepsModel.request.transactionInfo.transactionData.adhaarnumber,
										accessmodetype = "APP",
										nationalbankidentification = _aepsModel.request.transactionInfo.transactionData.nationalbankidentification,
										requestremarks = "remark",
										data = _aepsModel.request.transactionInfo.transactionData.data,
										pipe = _aepsModel.request.transactionInfo.transactionData.pipe,
										timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
										transactiontype = "MS",
										submerchantid = _aepsModel.request.transactionInfo.transactionData.submerchantid,
										amount = _aepsModel.request.transactionInfo.transactionAmount,
										is_iris = "No"
									};
									_logger.LogInfo("Request : " + System.Text.Json.JsonSerializer.Serialize(withdrawalRequestModel));
									var _responseModel_paysprint = paysprintAEPSTransaction.CashWithdrawal(System.Text.Json.JsonSerializer.Serialize(withdrawalRequestModel));
									_logger.LogInfo("Response : " + _responseModel_paysprint);

									if (!string.IsNullOrEmpty(_responseModel_paysprint))
									{
										_aepsModel.response = _responseModel_paysprint;
										TransactionsQueueReceiveCompleted(System.Text.Json.JsonSerializer.Serialize(_aepsModel));
									}

									break;
								case 201: //yes bank
									/*
									//code to process the request via yesbank
									YesBankCashWithdrawalModel yesBankCashWithdrawalModel = new YesBankCashWithdrawalModel
									{
										txnId = _aepsModel.TransactionId.ToString(),
										agentId = _aepsModel.requestDto.agentId, // "MAX1764147",
										partnerId = _aepsModel.requestDto.partnerId, // "3909",
										channel = _aepsModel.requestDto.channel, // "1",
										aadharNumber = _aepsModel.request.transactionInfo.transactionData.aadharNumber,
										isVid = false,
										bankIIN = _aepsModel.request.transactionInfo.transactionData.bankIIN,
										biometricData = System.Text.Json.JsonSerializer.Deserialize<Object>(_aepsModel.request.transactionInfo.transactionData.biometricData).ToString(),
										customerConsent = _aepsModel.requestDto.customerConsent,// 1,
										latitude = _aepsModel.request.location.lat,
										longitude = _aepsModel.request.location.lang,
										appVersion = _aepsModel.requestDto.appVersion, // "1.0.1",
										appId = _aepsModel.requestDto.appId, // "l",
										agentName = _aepsModel.requestDto.agentName,
										agentAddress = _aepsModel.requestDto.agentAddress,
										agentPincode = _aepsModel.requestDto.agentPincode,
										agentDistrict = _aepsModel.requestDto.agentDistrict,
										agentState = _aepsModel.requestDto.agentState,
										agentCountry = _aepsModel.requestDto.agentCountry,
										terminalId = _aepsModel.requestDto.terminalId, //"YBL00003",
										deviceType = _aepsModel.request.transactionInfo.transactionData.deviceType,
										deviceMake = _aepsModel.request.transactionInfo.transactionData.deviceMake,
										deviceModel = _aepsModel.request.transactionInfo.transactionData.deviceModel,
										deviceIp = _aepsModel.request.location.ip,
										customerName = _aepsModel.request.transactionInfo.transactionData.customerName,
										customerMob = _aepsModel.request.transactionInfo.transactionData.customerMob,
										aggregatorCode = _aepsModel.requestDto.aggregatorCode, // "BC00003",
										amount = long.Parse(_aepsModel.request.transactionInfo.transactionAmount.ToString())
									};
									*/
									IAEPSTransaction aepsTransaction = new YesBankTransaction();

									//string data = Newtonsoft.Json.JsonConvert.SerializeObject(yesBankCashWithdrawalModel);

									//code temp added by swapnal
									string data = string.Empty;
									//var _responseModel = aepsTransaction.CashWithdrawal(data);

									var _responseModel = _message;

									_logger.LogInfo("Response : " + _responseModel);
									//code to decode the values
									if (_responseModel == null)
									{
										var _response = JsonConvert.DeserializeObject<CommonLibrary.ResponseModel>(_responseModel.ToString());

										var _code = _response.ResponseCode;
										var _supplierTxnId = _aepsModel.TransactionId.ToString();
										var _transactionStatus = _response.Response;

										if (_code == "00")
										{
											var _withdrawalresponse = JsonConvert.DeserializeObject<AEPSCommonResponseModel<AEPSWithdrawalResponseModel>>(_responseModel.ToString());

											_postTransactionModel = new AEPSPostTransactionRequestModel
											{
												p_txnid = _aepsModel.TransactionId,
												p_txnstatus = int.Parse(_code),
												p_supptxnnumber = _withdrawalresponse.Data.referenceNo,
												p_userid = _aepsModel.request.channelPartnerInfo.userId,
												p_remarks = _withdrawalresponse.Response,
												p_sprefno = _withdrawalresponse.Response
											};
										}
										else
										{
											_postTransactionModel = new AEPSPostTransactionRequestModel
											{
												p_txnid = _aepsModel.TransactionId,
												p_txnstatus = int.Parse(_code),
												p_supptxnnumber = _aepsModel.TransactionId.ToString(),
												p_userid = _aepsModel.request.channelPartnerInfo.userId,
												p_remarks = _response.Response,
												p_sprefno = _response.Response,
											};
										}


										if (_postTransactionModel != null)
										{
											var _testData = System.Text.Json.JsonSerializer.Serialize(_postTransactionModel);

											try
											{
												//code to call the API from here
												using (var client = new WebClient())
												{
													client.Headers.Add("Content-Type:application/json");
													client.Headers.Add("Accept:*/*");
													var result = client.UploadString("https://localhost:7268/api/AEPS/AEPSPostTransaction", System.Text.Json.JsonSerializer.Serialize(_postTransactionModel));
													Console.WriteLine(result);
												}
											}
											catch (Exception ex)
											{
												_logger.LogException(ex);
												Console.WriteLine("Exception " + DateTime.Now + " " + ex.Message.ToString());
												throw;
											}
										}
									}

									Console.WriteLine("");
									Console.WriteLine("");
									Console.WriteLine("");
									Console.WriteLine("");
									Console.WriteLine("****** Response from operator *************");
									Console.WriteLine(_responseModel);

									break;
								default:
									// code block
									break;
							}							
						}
						catch (ConsumeException ex)
						{
							_logger.LogException(ex);
							Console.WriteLine($"Error occured: {ex.Error.Reason}");
						}
					}
				}
				catch (OperationCanceledException ex)
				{
					_logger.LogException(ex);
					// Close and Release all the resources held by this consumer
					Console.WriteLine("Error " + ex.Message.ToString());
					_consumer.Close();
				}
			}
			//End Code Accounting queue init

			while (Console.ReadKey().Key != ConsoleKey.Q)
			{
				//Console.WriteLine("Transaction Processing Engine exits gracefully.......");
			}
		}

		private void TransactionsQueueReceiveCompleted(string message)
		{
			object LockObject = new object();


			Console.WriteLine("Hey Delegate called !!!!!!!!!!!!!!!!");
			try
			{
				lock (LockObject)
				{
					//Thread.Sleep(5);

					using (var _publish = new ProducerBuilder<Null, string>(_pconfig).Build())
					{
						try
						{
							Console.WriteLine(message);
							_publish.Produce("AEPSPostTransaction", new Message<Null, string> { Value = message }, null);
							//Console.WriteLine($"Delivered '{_message.Result.Value}' to '{_message.Result.TopicPartitionOffset}'");
							_publish.Flush();
							//Thread.Sleep(50000);
							Console.WriteLine("We are out of sleep - Thread.Sleep(50000)");
						}
						catch (ProduceException<Null, string> e)
						{
							_logger.LogException(e);
							Console.WriteLine($"Delivery failed: {e.Error.Reason}");
						}
					}
				}
			}
			catch (Exception exception)
			{
				_logger.LogException(exception);
				Console.WriteLine("ERROR  { QueueReceiveCompleted }-> " + exception.Message);
			}
		}
	}
}

