﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.Fino
{
	public class FinoStatusCheckResponseModel
	{
		public string ActCode { get; set; }
		public string TxnID { get; set; }
		public double AmountRequested { get; set; }
		public double ChargesDeducted { get; set; }
		public double TotalAmount { get; set; }
		public string BeneName { get; set; }
		public string Rfu1 { get; set; }
		public string Rfu2 { get; set; }
		public string Rfu3 { get; set; }
		public string TransactionDatetime { get; set; }
		public object TxnDescription { get; set; }
	}
}
