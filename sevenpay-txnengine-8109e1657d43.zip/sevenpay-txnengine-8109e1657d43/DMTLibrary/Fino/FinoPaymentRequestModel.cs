﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.Fino
{
    public class FinoPaymentRequestModel
    {
        public string ClientUniqueID { get; set; }
        public long CustomerMobileNo { get; set; }
        public string CustomerName { get; set; }
        public string BeneIFSCCode { get; set; }
        public string BeneAccountNo { get; set; }
        public string BeneName { get; set; }
        public int Amount { get; set; }
        public string RFU1 { get; set; }
        public string RFU2 { get; set; }
        public string RFU3 { get; set; }
    }
}
