﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.Fino
{
	public class FinoResponseModel
	{
		public int ResponseCode { get; set; }
		public string MessageString { get; set; }
		public string DisplayMessage { get; set; }
		public string RequestID { get; set; }
		public object ClientUniqueID { get; set; }
		public string ResponseData { get; set; }
	}
}
