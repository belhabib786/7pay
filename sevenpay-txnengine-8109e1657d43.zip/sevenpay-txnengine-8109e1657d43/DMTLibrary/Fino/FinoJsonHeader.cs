﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.Fino
{
    public class FinoJsonHeader
    {
		//DEMO
		//public int ClientId { get; set; } = 185;
		public int ClientId { get; set; } = 185;
		//DEMO
		//public Guid AuthKey { get; set; } = Guid.Parse("0f2dbdc5-a924-4d2d-b5e6-fdb42c1ae7da");
		//Production
		public Guid AuthKey { get; set; } = Guid.Parse("8f4c0355-33c9-4f0c-b87d-56b2abf38f6f");
        
	}
}
