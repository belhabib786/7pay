﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.ZoopOne
{
    public class Metadata
    {
        public string billable { get; set; }
        public string reason_code { get; set; }
        public string reason_message { get; set; }
    }
}
