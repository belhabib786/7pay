﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.ZoopOne
{
    public class ZoopOneBankVerificationModel
    {
        public string account_number { get; set; }
        public string ifsc { get; set; }
        public string consent { get; set; }
        public string consent_text { get; set; }
    }
}
