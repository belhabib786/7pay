﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.ZoopOne
{
    public partial class Result
    {
        public string bank_ref_no { get; set; }
        public string beneficiary_name { get; set; }
        public string transaction_remark { get; set; }
        public string verification_status { get; set; }
    }
}
