﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.ZoopOne
{
    public class ZoopOneOKYCVerificationPreResponseModel
    {
        public string request_id { get; set; }
        public bool is_otp_sent { get; set; }
        public bool is_number_linked { get; set; }
        public bool is_aadhaar_valid { get; set; }
    }
}
