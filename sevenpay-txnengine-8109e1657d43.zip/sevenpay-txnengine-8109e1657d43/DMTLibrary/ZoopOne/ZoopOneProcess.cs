﻿using Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace DMTLibrary.ZoopOne
{
    public class ZoopOneProcess
    {
		//demo
		//private readonly string baseurl = "https://test.zoop.one";
		//production
		private readonly string baseurl = "https://live.zoop.one";
		private readonly ICustomLogger _logger;
        public ZoopOneProcess()
        {
			_logger = new CustomLogger("ZoopOne");
		}
		public string GetBankVerification(string ifsccode, string bankaccountno)
        {
            try
            {
                ZoopOneBankVerificationModel zoopOneBankVerificationModel = new ZoopOneBankVerificationModel
                {
                    account_number = bankaccountno, //"006002600001063", //"0653104000110XXX",
                    ifsc = ifsccode, //"HDFC0CMALAD", //"IBKL0000XXX",
                    consent = "Y",
                    consent_text = "I hear by declare my consent agreement for fetching my information via ZOOP API."
                };

                ZoopOneRequestModel zoopOneRequestModel = new ZoopOneRequestModel
                {
                    data = zoopOneBankVerificationModel,
                    task_id = Guid.NewGuid().ToString() //"2"
                };

                ZoopOneProcess zoopOneProcess = new ZoopOneProcess();
                var _requestdata = JsonSerializer.Serialize(zoopOneRequestModel);
				_logger.LogInfo("Request : " + _requestdata);
				string response = zoopOneProcess.ProcessRequest(baseurl + "/api/v1/in/financial/bav/lite", zoopOneRequestModel);
				_logger.LogInfo("Request : " + response);
				//static data
				//string response = "{\"request_id\":\"90dca759-76e2-49c0-abfd-2efd75ffd505\",\"task_id\":\"4d08ffd5-467f-4f6b-9847-5f6eed0fcbcb\",\"group_id\":\"c77b5f9c-3be7-4253-9dd9-70dd41234932\",\r\n\"success\":true,\"response_code\":\"100\",\"response_message\":\"Valid Authentication\",\"metadata\":{\"billable\":\"Y\",\"reason_code\":\"TXN\",\"reason_message\":\"Transaction Successful\"},\"result\":{\"bank_ref_no\":\"305815096389\",\"beneficiary_name\":\"MR BISWARANJAN NAY\",\"transaction_remark\":\"Transaction Successful\",\"verification_status\":\"VERIFIED\"},\"request_timestamp\":\"2023-02-27T09:37:53.286Z\",\"response_timestamp\":\"2023-02-27T09:37:55.371Z\"}";


				if (!string.IsNullOrEmpty(response.ToString()))
                {
                    var _responseObj = JsonSerializer.Deserialize<ZoopOneResponseModel>(response.ToString());

                    if (_responseObj != null)
                    {
                        if (_responseObj.response_code.ToString() != "100")
                        {
                            return _responseObj.metadata.reason_message.ToString();
                        }

                        var d = JsonDocument.Parse(response);  //JsonDocument.Parse(reader.ReadToEnd())
                        var result = d.RootElement.EnumerateObject();
                        foreach (var r in result)
                        {
                            if (r.Value.ValueKind == JsonValueKind.Object && r.Value.GetRawText().Contains("beneficiary_name"))
                            {
                                var _benModel = JsonSerializer.Deserialize<ZoopOneBankVerificationResponseModel>(r.Value.GetRawText());
                                return JsonSerializer.Serialize(_benModel);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
				//code added by swapnal
				_logger.LogInfo("Exception:" + ex.Message.ToString());
				return "Somthing went wrong. Please try after sometime.";
                //throw;
            }

            return "Somthing went wrong. Please try after sometime.";
        }

        public string GetPanLiteVerification(string transactionId, string pancard)
        {
            try
            {
                ZoopOnePanLiteVerificationModel model = new ZoopOnePanLiteVerificationModel
                {
                    customer_pan_number = pancard,
                    consent = "Y",
                    consent_text = "I hear by declare my consent agreement for fetching my information via ZOOP API."
                };

                ZoopOneRequestModel zoopOneRequestModel = new ZoopOneRequestModel
                {
                    data = model,
                    //task_id = transactionId
                    task_id = Guid.NewGuid().ToString()
                };

                //JsonSerializer.Serialize(jsonHeader)

                ZoopOneProcess zoopOneProcess = new ZoopOneProcess();
                var _requestdata = JsonSerializer.Serialize(zoopOneRequestModel);
				_logger.LogInfo("Request : " + _requestdata);
				string response = zoopOneProcess.ProcessRequest(baseurl + "/api/v1/in/identity/pan/lite", zoopOneRequestModel);
				_logger.LogInfo("Request : " + response);

				//static data
				//string response = "{\"request_id\":\"c97e4c0d-4e41-4df8-acf4-331b8c48aef7\",\"task_id\":\"1dae089b-547c-4300-ad04-6b90c25fdb1d\",\"group_id\":\"847b6050-eac8-420c-be02-e9daa0c39a19\",\"success\":true,\"response_code\":\"100\",\"response_message\":\"Valid Authentication\",\"metadata\":{\"billable\":\"Y\"},\"result\":{\"pan_number\":\"AFIPC0999P\",\"pan_status\":\"VALID\",\"user_full_name\":\"SWAPNAL RAVISHCHANDRA CHONKAR\",\"pan_type\":\"Person\"},\"request_timestamp\":\"2023-02-27T12:36:53.686Z\",\"response_timestamp\":\"2023-02-27T12:36:55.109Z\"}";

				if (!string.IsNullOrEmpty(response.ToString()))
                {
                    var _responseObj = JsonSerializer.Deserialize<ZoopOneResponseModel>(response.ToString());

                    if (_responseObj != null)
                    {
                        if (_responseObj.response_code.ToString() != "100")
                        {
                            return _responseObj.metadata.reason_message.ToString();
                        }

                        var d = JsonDocument.Parse(response);  //JsonDocument.Parse(reader.ReadToEnd())
                        var result = d.RootElement.EnumerateObject();
                        foreach (var r in result)
                        {
                            if (r.Value.ValueKind == JsonValueKind.Object && r.Value.GetRawText().Contains("pan_number"))
                            {
                                var _pancardModel = JsonSerializer.Deserialize<ZoopOnePanCardVerificationResponseModel>(r.Value.GetRawText());
                                return JsonSerializer.Serialize(_pancardModel);
                            }
                        }
                    }
                }
                return "Somthing went wrong. Please try after sometime.";
            }
            catch (Exception ex)
            {
				//code added by swapnal
				_logger.LogInfo("Exception:" + ex.Message.ToString());
				return "Somthing went wrong. Please try after sometime.";
            }
        }

        public string GetOKYCVerification(string transactionId, string aadharNumber)
        {
            ZoopOneOKYCVerificationPreResponseModel _responseModel = new ZoopOneOKYCVerificationPreResponseModel();
            try
            {
                ZoopOneOKYCVerificationModel model = new ZoopOneOKYCVerificationModel
                {
                    customer_aadhaar_number = aadharNumber,
                    consent = "Y",
                    consent_text = "I hear by declare my consent agreement for fetching my information via ZOOP API."
                };

                ZoopOneRequestModel zoopOneRequestModel = new ZoopOneRequestModel
                {
                    data = model,
                    //task_id = transactionId
                    task_id = Guid.NewGuid().ToString()
                };

                //JsonSerializer.Serialize(jsonHeader)

                ZoopOneProcess zoopOneProcess = new ZoopOneProcess();
                var _requestdata = JsonSerializer.Serialize(zoopOneRequestModel);
				_logger.LogInfo("Request : " + _requestdata);
				//string response = zoopOneProcess.ProcessRequest(baseurl + "/in/identity/okyc/otp/request", zoopOneRequestModel);
				string response = zoopOneProcess.ProcessRequest(baseurl + "/in/identity/okyc/otp/request", zoopOneRequestModel);
				//https://live.zoop.one/in/identity/okyc/otp/request

				_logger.LogInfo("Request : " + response);
				//static response
				//string response = "{\"request_id\":\"f43163d1-8a53-40f1-afc5-b55d76e7c49e\",\"task_id\":\"d0f751fe-a388-4e68-b84a-c117af27415e\",\"group_id\":\"eb5c5c85-6bff-4ef2-983a-c780c29d4a72\",\"success\":true,\"response_code\":\"100\",\"response_message\":\"Valid Authentication\",\"result\":{\"is_otp_sent\":true,\"is_number_linked\":true,\"is_aadhaar_valid\":true},\"metadata\":{\"billable\":\"N\"},\"request_timestamp\":\"2023-02-27T13:30:05.577Z\",\"response_timestamp\":\"2023-02-27T13:30:07.690Z\"}";

				//ZoopOneOKYCVerificationPreResponseModel
				if (!string.IsNullOrEmpty(response.ToString()))
                {
                    var _responseObj = JsonSerializer.Deserialize<ZoopOneResponseModel>(response.ToString());

                    if (_responseObj != null)
                    {
                        if (_responseObj.response_code.ToString() != "100")
                        {
                            return _responseObj.metadata.reason_message.ToString();
                        }

                        _responseModel.request_id = _responseObj.request_id;

                        var d = JsonDocument.Parse(response);  //JsonDocument.Parse(reader.ReadToEnd())
                        var result = d.RootElement.EnumerateObject();
                        foreach (var r in result)
                        {
                            if (r.Value.ValueKind == JsonValueKind.Object && r.Value.GetRawText().Contains("is_otp_sent"))
                            {
                                var _aadharcardModel = JsonSerializer.Deserialize<ZoopOneOKYCVerificationPreResponseModel>(r.Value.GetRawText());
                                _responseModel.is_otp_sent = _aadharcardModel.is_otp_sent;
                                _responseModel.is_aadhaar_valid = _aadharcardModel.is_aadhaar_valid;
                                _responseModel.is_number_linked = _aadharcardModel.is_number_linked;
                                return JsonSerializer.Serialize(_responseModel);
                            }
                        }
                    }
                }

                return "Somthing went wrong. Please try after sometime.";
            }
            catch (Exception ex)
            {
				//code added by swapnal
				_logger.LogInfo("Exception:" + ex.Message.ToString());
				return "Somthing went wrong. Please try after sometime.";
            }
        }

        public string GetPostOKYCVerification(string requestId, string otp)
        {
            ZoopOneOKYCPostVerificationResponseModel _responseModel = new ZoopOneOKYCPostVerificationResponseModel();
            try
            {
                ZoopOneOKYCPostVerificationModel model = new ZoopOneOKYCPostVerificationModel
                {
                    request_id = requestId,
                    otp = otp,
                    consent = "Y",
                    consent_text = "I hear by declare my consent agreement for fetching my information via ZOOP API."
                };

                ZoopOneRequestModel zoopOneRequestModel = new ZoopOneRequestModel
                {
                    data = model,
                    //task_id = transactionId
                    task_id = Guid.NewGuid().ToString()
                };

                //JsonSerializer.Serialize(jsonHeader)

                ZoopOneProcess zoopOneProcess = new ZoopOneProcess();
                var _requestdata = JsonSerializer.Serialize(zoopOneRequestModel);
				_logger.LogInfo("Request : " + _requestdata);

				//string response = zoopOneProcess.ProcessRequest(baseurl + "/in/identity/okyc/otp/verify", zoopOneRequestModel);
				string response = zoopOneProcess.ProcessRequest(baseurl + "/in/identity/okyc/otp/verify", zoopOneRequestModel);
				_logger.LogInfo("Request : " + response);
				//staic response
				//string response = "{\"request_id\":\"2d3993bf-cb00-4bb5-9b29-5dfead12b625\",\"task_id\":\"acc6f445-6c2e-49fa-a225-abbc2cd9479e\",\"group_id\":\"7d495295-3a14-4761-9031-3a8325d83ea5\",\"success\":true,\"response_code\":\"100\",\"response_message\":\"Valid Authentication\",\"result\":{\"user_full_name\":\"Mihar Nayak\",\"user_aadhaar_number\":\"********7157\",\"user_dob\":\"10/05/1997\",\"user_gender\":\"M\",\"user_address\":{\"house\":\"\",\"street\":\"\",\"landmark\":\"SRIDHARPUR\",\"loc\":\"\",\"po\":\"Sridharpur\",\"dist\":\"Jajapur\",\"subdist\":\"\",\"vtc\":\"andola\",\"state\":\"Odisha\",\"country\":\"India\"},\"address_zip\":\"755007\",\"user_has_image\":true,\"user_profile_image\":\"/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCADIAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDe256DmgJUhByT1xRt5NQBEYz2FCg9MVKEIpdlKwEaoRSkU4q4+7g/Ws3WNXi0exa5uGUHkIvXcfSgDJ8TeLrLQYjEHEt4R8sY5x9T2ryzUdZvtbu2uLiUsRwiAYAHoMVU1a+k1O/nvLiQF5X3YPYelU4ZQrckAHrgdqoC4HwjLIVD57k5FQZlE5D7ip9DUkk0QAdGkfsxY4H6UJIzR5gkGB15O4UDJWH2ZgyE7uvB60skm9S4yDjkVRFtNK2/zCG65Y/1qWXzomMcpyT0cdKQF7T9ZvNPcPbTyReo3ZBrs9H+IMsZEeprvjP3ZI1AKn39R9OeO+ePOmimC5Izxz9Kri5ZcelFgPorT9Rt9Rt1mtpVkXjO05wfSrdeJeENf/srVojLIUt5CFk6nj6frXs1pcC7jjfpuXdxkfoRUtAWOO9O4x0NPVOadtOKEBDgDtQcdhUpBx0phBHrTuIfwO9IcDkkcU/HHSm7Ae1PUA/Klo2gDoKXAxQAxuAa8l+IfiI3V/8A2Zay5WMlZCp+83p74xXo/iTUBpmgXd2FJdE+UDsTwD6d+9eAF3edpXZjI5O5ieeaYDmVFjzjecY6YzVQRyFiVjP0HapsyyMpUEg8dOtXIImSJi5xn260XGIkMa2gkdwCexGf0zUa3UEaLsUA5ySP1FRTuXOGyB2wM4qoYXP3eeaWgWZd+2K03cIT2plzdbzjJOOOadDpN1Km9YzhSMn0qdNHnc4CEjsSKlziupahJlGO4cAITkN+lOaMODLge4q/PozQqMjnGQfWs9maJhnmmpKWqFKLjuPjJbgDpXd+C/Ek1nItlIGMPJC5wFPX2/rXDQIGy4IBqe3upYJ1eN2R0OQVOKZJ9E20wljVupP+yRVnbkc1zvhHUk1XSop4zjgI6DnDd/8AGukxSAjIptS7aYUoELgYoxxScnHvT8EVQDCmfUUoXHU0/PHSm5FIDgfide+VpcFuD/rGLAfQdenvjt1ryMSgKDt5JxkV6Z8Un2zWO5jwjnZjjqv69a8xVWmuVjQDGaBotwRTyEJHxu6c4FbMPhq68jzDMpJGdtXtG0scFUGfU12FpYlQOPwrgrYhp2idtKimtTzZ9JeNhvQn14oSy82TyooyqqcnNeqro6TA+bGrcckr0p1poNtGGAgHJ5wKlYltal+xVzndFshbShJFJQISTnGeAADVo2BjRvs77IiPuHHH0OOntXVxaOm0lY1Bx3FRXWlFWJ6fSspTk9TRRSOFu7CRj87Ar2HpXJ3+nrBIVk+RG+63vXpt1ZqScEZFc1qmnrNGyEZU1VGq4vUmpTUkcO1mIgTvDdRkHg0kSHgjBz09afe2k1nMQTlCcA+lQQZS54b/APWK9OLTV0efJNOzPWfhbIhs7yEE7kcNz6Ef/WP5+9eiAV5f8MnBvb5gw5VAVH1NeoZzTJAimE0/jsajYDHSkABfnA9BTyDSD/WH8KcaoRGQcinKOKQntTl6UhnmXxThLLayDPBO7056fy/zivPNKULNJLsLt0VcV7L44tEudIlVhnuPrXmuh26xRuzD5i5zUVJWiy6avKxattT1C2H/AB7FEHfyya1LPxi6uBLCmR15xn6VGdatbJdrMmB6n/JqCe8stQeERuC8yl4wLZyWGSCQccgFWH4GuS3NvE637v2js9M8SRXi4MO0565zkV0Fvc25+Y457Zry2H7VaLvhMbxBtu6NgQD6EdQfYgV0Wl6ypjbzQd2Mc9jWM1yvQ1i2zo9S8QNZhhbIm7Ofm5GMfWuL1DxlrVzuSMBQx+XCA4H41NqF6bgMUGcdqy2tLprhIUJknYA+VBh2Gemewz71VN36ClHzFgtNc1BfNb5M/wDPZ+v5ZNSS6XfQsC8ys2OSrZH61STxQbJZkljnPlSCMgugOTnovUj5TkjoSOmRVo6uk8/lzLJFKDnY/wAp/KtJqotbEQ5NrmXdx+Y5imjw304NczMnkag6Dhf5V3FyVlAGMnsa5e+tx9tkYHkEDHrWtB3Ma6O9+G8CCKaUY3MwGfUAf/rr0rBwO9cD4Ct/KtM5+8c134+6K6DmGkYNNwSRTzSYwetADF4ZvrTlOc8UiY2k+tOAwKoBhQs3tUmOOlKPSnEZosBia9bm4snGO1eVm3kj8+JeG8wgZ+gr2maIOu0jIrx60jZbZN5yxOc4weQDzWVV2RrSjd3ItO01oEuRNElwbhCjMxIKg+h7Vd8PeH10q7XUFndblM7NqgkZGMjIIPBI5Hf2rUto1CDPHFWjMiKVhHOMbj2rh9vK+53exiZ2pPCjbwJHuG4aSR88egHQflTdPiXyS3c9abLbtcXSRg8Hkk100WjeXYI+Rhu3es5yujSKszlXjdHYp69K17BrWRQ8Nq0dyB80iSsCfyIqndRmCZtynb6inWfUSREgg8EUKVtQcbi3nhmynuftnkYuGk8w5+YE9eQevPPOc96q6jpX2yYT3MhkkUcNgL+WK6qDUIpY9lzFtfH3h0NVp0jfOPwpyqt7MlU12OVlVY1C45AxmsVbCfUNUm8pf3cfzO54C/Wujv4lD1X0cxtcSpMjNCX3OB0Y4wAfbrW1ObjByRlOClJI6HwXeRNPJYqpLRruD4IDDIB6j3Fd0Olcb4Zt9uu3L7MIIyAfqVI/TNdl2rqpSco3Zy1oqM7IQnnNITzilxxRitDEg3soHfNSg5FR7QQM1IKfUB460uab3paoBrthTXmOpokWpSxKAMSE4AwACeB+A4r05hlTXm/iC3MGtyv2cZ/Ef/WrGrG6NaUrMfDhkxU6RgnrjFUbeXC09rvYCQcV5bjqenGWg2VbqSEXNgYHaInzImbazHPQehrTTXt2nbUjZpgMLExwd3ofSsISebITgAk8nHNbSLbeSrl0Eg5OT2rTS1mib9iilx4ga9/e6datan7x83+v/wBarVosTX86Q42AAkdcE0+9lSXZ5Uv7sc4HfjpVS3uPJkwqqo53YqJarYcTWnVYY97dF5NRyfKCFP60ouBInJ5xVedzt+XFZ2LuZd84y3sKNJuVWxeNVO2TGC2fmfJ5HbABx71BfHII9amuCtra7ZT8qJhfaum3uJLqYX96/Y6Tw5OGvJyvQlR+Q/8A111oORmuO8HRmSJpiMZPFdjjiu+nHlikcFSXNJsUdKKBRVkEAPApwbtUOelPHSmIlDc0u7ios0opgOJ4rivF8bJcwzqBtDYb6GuyNY2u2gu7F0IzxU7jvY4eKXyztOPaoiQzb5icZ4UUyUmOQhuq9aaXD81w1IWZ3U53RGb1jIVhjYj6VajupV6wswPtmqyKquWXr71b/tKRGGYCx9RiqXL0OiDVtWEmoSAAmEn8Kkt72CYlJCY5OuCOtMkvhPEIzAEx3IGagiWMSbieaiaiDt0NWMtG2d25D3qSSfIPNURPtTGc1XkuDjg1lGF2RKViLUptkUhB5A4rIhkur+dEkleTnvVq6D3TrAmcsefpXU+HfDYhkSWQEmu+lG0ThqTuzqfDlp9k0+NSOcVu9RVaKMRoAB0FS5xWpkPJ4pM8U0nIppJoArg81IDxUPPU0oPSmInzSg1FupQ9MCQmq1ym+Fh7VKzZGKjByuM5xxSA8x11TaaiSRhH6+1QQbJV46eoro/Fmnh4WlC/d5rz4XM2mycgtAemP4ayqxT0NaUranX28ca/eTPHFaFrpj3RJOxAOgzjNc5Z6zbyxqUkGR71sDVQVCrIOnrXDKEk9T0Izi1oaMmmCH5JkUj1rLubeJCSnH4VK2pKIyXlzx3NZNzrMIydwJHSpUZSegOUUrskkPlrzWbc3ixL6k8ADqTVSbUmnfbCC7H0qeGxMaGeb5pT09FrqUVBanO5Ob0Nfw1atc3/AJki88V6ZbwiNBgYrkfB9pmATf3j1rtlGFrpWxyPcep+WijtSUxC0GkJozxQBUz15pVyB7UhIHpRnFMB5PFANN3Zo4xQA/cDxTOAfrSg8daytbncpDZRECS6bbn0Ucn9P600rkylyq5m+INQinsLhYQGj2MvmZ+8cc7fYev4D1riFgWaHa4BUj8q67VNkMNyqhRFFZSIoz0Y4H5+/v3zXJ2jfLgmsMQ9FY3wt9eYw7vSDDLmM8Hpio49N1CR9sVwy+xNdFdqG2kdqji4OaxVSVjodJXKcfhjWJcebd4T1zmnHw/FAf3szzMPU8V0VvqBFqyMTuA4rPkJKliaj2k3uV7OJXs4oopQqIBj0q1dH5frUVsuXLDgCpJ8EYH50m9SktDsfBNzE2hOrMomhnK7QeShAIbH1LD8K6xWBAIOQRXl3hK8+za/5ZJKzwum3sWA3DP5EfjXeStcQoZLd92zqpGQy568e5z6nI7Cu+mrxR5lWpyTaZrGjPFUbbUEncxsNko52k9R6g96t7uKbTWjHGSkrxFPINIOg5ozSbue1IZS3Zp4PPNR5AGTwByT2rFv/E9pbEx2w+0SDjKnCD8e/wCHHvVJN7EynGCvJm/n0qpPqdnbblluEDKcFQdzD6gc1xdzq9/qDMJJzHGeqR/KuMYI9x9SahROAqDAFbww7e551bMowdoK7OkufFUcYxBAzE9C5x+gpNGM+o3E19cuSVHlpxwM8kY/KuWMbGTO4EdsV3fh22EWkR5AUvl2Pr6H8gKqcFBEUsROtJXZxfjCd4zHEvSZiGyOyn/EA1i25OB/Sur8X2ZbTIptgJSb5mH8KncP57a5aFSB0rzq71se5hfhuWyuV/xqPyiGyDmpk5TJoVM/WuS522Hqg2cjmoZgccCrI81UwBmopBI33uMUrgMth5YOepomwe9KMKKic7jin1E9ERWRaPVrSRcjbPGeP94V6xbIFghdgCuwZHfGMH8cGvNtItfP1W3B6K2/j/Z5/pXqEUHl28cYxhRg/Qj/ABFd2Hd4s8zF6SRi31tsZ4+jxMcEdQQahttTuogFdvMXp8wyR+PX8609SjPnByfvoD+I4P6jP41imMB2GOD1FdqSktTyJylTn7rNqPU1YcoTj+4c/pViG7hnIEciljn5eh/I81zj26ToUb5W6LIp5Fc9qNmwzbT4z1XnIPoaXsU9i1j5wtzK6GX2sXOoHbJKWGeI0+6Pw/xqskMhXJ2p9eamjjjhURoiqo6KowKVmPauiNNI86piZSeg1FbG0OeOuAKnHC7eo755zUaYGec561LgVokc8m+onHJK578d69IsYfItI41AIRQoz3AGK89toxJdQoRkFxn6Z5/Su0XxLocduobWtLPGDi4X/wCKrnxD2R6WXxdnIjvreO5hktnU7JFYH25/nXn8lo9rcyQSffjbB9/evQkbzFjnjcSQupZXU5DAkEEH0xXOeILUCSG7UABzsb+Y/kf0rzq8eaN+x72Glyyt3OfHB4ocMpBFSTxrgFTzU0GHj55I61wHpFdJiOMHFLIxYVcS3DDIFO+zdNwpXAzNpxyOKUAHmrc6KF7VSlnEQCqRk8j6VUbsVupreHEV9bRCTuCkjB75HHvxmvSJRsRW5OMcev8Ak4rz7wNCZNWluGZcRx4A9yf/AK3616NIuUIJIyMV6VGNoHkYqXNUMvVgUtGfYx8kltowTg4z/In865V9TUtlYj+LV2sTpNCnzKWIKMQc/Mpweo7EGuG1jT20y/ZMfuXOYz2+n4V2UbN8rPJximoqcRj6lKwOwKoP41VlkafiYlvQk5xTCBnilHvXUopHlOpJ7soTLOSywnbMDgcZ59Md6W4stdtEJudM8wY5MLcfpmu38P6Gt5J9vkQKYziMkcM3c++On1+lb0lu8XDrjv8AWuSdXWyPVoYb3LzWh5CuoorYlgnifHIZKDrduiErFcMfaPj869HuJLZZhLIqIoBClsAe5yawtb8TWmnovlRJcyknYBwi+5PfrwB75I4oVWZTwtK5xOoLqNxAst35llbSZCQ9HkHfPTjp/hWfFo9uyFmVj6DPSrGo6lc6nqDXF3JudsKMcBV7KB2A/wAT1JNWR8oB9aS953ZdR+zilHRHo3hJS/hm2TzSXTcmHP8ACCQv4YGM+xpdct92hShc74owxyOcgBiPrwR+FcfoXiWbQLsLcln02RwWIG4wn1A7qe4/Ec5B9GudlzarNC6FZMFXVsqQec57gjmsZw6HXQraJnlP2qVjlVJ/GrME0sanevB4qcWuyV0K7XU4IxVxLRWgbP3q8qcXF2aPdp1IzipJleC8ZTjr9KsSXLOOAOlUxAUfp0qVm4Axk+1Z+hpYryBpDkjPotVzbiZth5Y+ta1tEd24jPFNeJY5mYD5zwK6cPT9rNQWxyY3ELD0XP8Aq5Y8P3S6RqsWBlZP3ZH1xz+eP1rvri5cQpI+NvmKpA6/Mdo/VgT9K8unz5uST6DFehaVqJvtNt5vLDMQN2V43A8/TkZr068baI8HBVHO7k7t6k12Wt4ppVjEpVC2zIG4jnGffpmuc1DXFnh8m98Oaoo6f6OFkCkdxg9etbuoXNpbWrPd3McSNldzOFBJ7ZNStb+cgdGKuyg5Wsos6qttmedG9jSQpsulXOP3luwP4jnFKLveMxwXMg77YG4/SvRrctN8sm3cvDKR39c1T1O9h094/tAdRJnBTkDGOSPxHY10KvU2R58sHQXvNmfZeMjawiNNOARV2oPPPA9+OT78Utx40uJ7HymsbfzieZD8wA9lPf3zRRW3sYb2OF42vtf8EctM7zytJK7O55LMeTWNq3McYGO/9KKKc/hHh23VVzKYdG9q00bfEp9RRRWENz0a/wAKJTh42U4ORV7StfutBhlhjQXNm6nbE7kNC3XK/wCyT1XoevBzkoqpK6MITcXoQ2GtKwXz1JYHBfufrW7BNFOm6Jgw7kUUVxYtKUOZ7o9bAe5UcY7PoJMQvUZJ/WkSIDtkmiivNex7V9CcssURPeqXYu1FFerlkV70j5vPpyShDoQShWtJJWJAjGeByWPRR7k/pk9Aa19F0vXZ7XbDcrYWkuJCdodzx+QyPx4oorqrO7OTBq0U0b1j4T0y0mWeWJ7u5xzPct5jEj61sLxN0xxRRXOztTuQvEUxMg+YM2R6jcaw/F6eZa2kw5ALqT7nGP5Giirp/EjDEr9zI//Z\",\"aadhaar_xml_raw\":\"https://storage.googleapis.com/zoop-okyc-document/2d3993bf-cb00-4bb5-9b29-5dfead12b625-2023-03-17T13%3A05%3A43.264Z.xml?GoogleAccessId=cloud-storage%40zoop-one-development.iam.gserviceaccount.com&Expires=1679065544&Signature=gj%2B5WQ9r5%2BpB51bCWIJdN4ygyPguVzuicP1vN6zOSU7g3UxBtpoVTJo5D4OkyHg5AC3fvRz4bcdY8I0qJ1MVbj%2FQFeORfLCFpWu5ypyHhli74oV7dgP951SDc61IYjKqVPPy6%2BU1qHao3DZG%2FUozXEbGyjyKdVwRT2Rj2Txy3yt4XnhEYQNMCctClDwmJ8t9SUjEDQXEZYbM1BqXwq9DFtE4za8svw4SWGg5FuLCHJYj1tc8q9m00jXxIRTYbLhN0OH0ugpBr9hKJbiqi%2Bgcbj2N0S3v5ncLw4k8pxCi60Wgcur2AuYXEbcnP%2F5sIsg18vO5mVxyjnwVNo6E2GS%2Frw%3D%3D\",\"user_zip_data\":\"https://storage.googleapis.com/zoop-okyc-document/2d3993bf-cb00-4bb5-9b29-5dfead12b625-2023-03-17T13%3A05%3A41.732Z.zip?GoogleAccessId=cloud-storage%40zoop-one-development.iam.gserviceaccount.com&Expires=1679065542&Signature=wGQrdGDHj62y6cEVIIdtnJVABsUPrggiftBLIKxhuYhQ5c95OM8rCAvS2PMG5N4b5Kdlgz42F42EI%2BIs1uwLgyg7CbxOuYT3tcThDKKIT%2F2dpuznNS0a2VeBxFFLvDj%2FEiMVNMfskoCYi6nCTuLzXDSo4Nf8jLqehXNsK2Q9Q27EBy%2BgF21qRXb0H2wc65SaOMLU3AfscXKfk6r78q1V5vyG3gxyj30PaHBnYdviA9dFjBXu0I3Is%2BpacP8cr3dZhN50Aar80NvZPjJR3soB6LyKGMqYLKHyCP2faoCgw4LMA0aLsHZ%2F%2BuP7nrt7limQqWBGUxg3pnBhV%2FwsNbzCiA%3D%3D\",\"user_parent_name\":\"\",\"aadhaar_share_code\":\"8217\",\"reference_id\":\"715720230317183541402\",\"user_mobile_verified\":false},\"metadata\":{\"billable\":\"Y\"},\"request_timestamp\":\"2023-03-17T13:04:04.919Z\",\"response_timestamp\":\"2023-03-17T13:05:43.847Z\"}";

				//ZoopOneOKYCVerificationPreResponseModel
				if (!string.IsNullOrEmpty(response.ToString()))
                {
                    var _responseObj = JsonSerializer.Deserialize<ZoopOneResponseModel>(response.ToString());

                    if (_responseObj != null)
                    {
                        if (_responseObj.response_code.ToString() != "100")
                        {
                            return _responseObj.metadata.reason_message.ToString();
                        }

                        var d = JsonDocument.Parse(response);  //JsonDocument.Parse(reader.ReadToEnd())
                        var result = d.RootElement.EnumerateObject();
                        foreach (var r in result)
                        {
                            //if (r.Value.ValueKind == JsonValueKind.String)
                            //{
                            //    var stringValue = r.Value.GetString();
                            //}
                            if (r.Value.ValueKind == JsonValueKind.Object && r.Value.GetRawText().Contains("user_full_name"))
                            {
                                var _aadharcardModel = JsonSerializer.Deserialize<ZoopOneOKYCPostVerificationResponseModel>(r.Value.GetRawText());
                                return JsonSerializer.Serialize(_aadharcardModel);
                            }
                        }
                    }
                }

                return "Somthing went wrong. Please try after sometime.";
            }
            catch (Exception ex)
            {
				//code added by swapnal
				_logger.LogInfo("Exception:" + ex.Message.ToString());
				return "Somthing went wrong. Please try after sometime.";
            }
        }

        public string ProcessRequest(string url, dynamic requestObject)
        {
            try
            {
                //code added by swapnal to deal with https request
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Ssl3 | (SecurityProtocolType)0x00000C00;

                //code by swapnal to process with http request
                WebRequest request = WebRequest.Create(url); //"https://test.zoop.one/api/v1/in/financial/bav/lite" 
                                                             
                request.Method = "POST"; // Set the Method property of the request to POST.

				//Demo
				//request.Headers.Add("api-key", "9KBMVY3-8VF4CN2-G7CGP42-TY9Z8FE");
				//request.Headers.Add("app-id", "6318bb8c3e37b5001d871f00");
                //Production
				request.Headers.Add("api-key", "4M77D8D-1YH43QH-JX00W49-686M29C");
				request.Headers.Add("app-id", "64bbbf437416a20028d1cede");
				request.Headers.Add("Content-Type", "application/json");

                var requestdata = JsonSerializer.Serialize(requestObject);


                byte[] byteArray = Encoding.UTF8.GetBytes(requestdata);
                //request.ContentLength = byteArray.Length;

                // Set the ContentType property of the WebRequest.
                //code temp commented by swapnal
                //request.ContentType = "application/json";

                // Get the request stream.
                Stream dataStream = request.GetRequestStream();

                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);

                // Close the Stream object.
                dataStream.Close();

                // Get the response.
                WebResponse response = request.GetResponse();

                // Display the status.
                Console.WriteLine(((HttpWebResponse)response).StatusDescription);

                // Get the stream containing content returned by the server.
                dataStream = response.GetResponseStream();

                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);

                // Read the content.
                string responseFromServer = reader.ReadToEnd();

                // Display the content.
                Console.WriteLine(responseFromServer);

                // Clean up the streams.
                reader.Close();
                dataStream.Close();

                //code added by swapnal 
                return responseFromServer;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
				//code added by swapnal
				_logger.LogInfo("Exception:" + ex.Message.ToString());
				throw;
            }
        }
    }
}
