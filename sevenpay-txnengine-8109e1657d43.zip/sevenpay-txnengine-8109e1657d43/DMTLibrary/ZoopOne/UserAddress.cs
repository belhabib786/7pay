﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.ZoopOne
{
    public class UserAddress
    {
        public string house { get; set; }
        public string street { get; set; }
        public string landmark { get; set; }
        public string loc { get; set; }
        public string po { get; set; }
        public string dist { get; set; }
        public string subdist { get; set; }
        public string vtc { get; set; }
        public string state { get; set; }
        public string country { get; set; }
    }
}
