﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.ZoopOne
{
    public class ZoopOneOKYCPostVerificationResponseModel
    {
        public string user_full_name { get; set; }
        public string user_aadhaar_number { get; set; }
        public string user_dob { get; set; }
        public string user_gender { get; set; }
        public UserAddress user_address { get; set; }
        public string address_zip { get; set; }
        public bool user_has_image { get; set; }
        public string user_profile_image { get; set; }
        public string aadhaar_xml_raw { get; set; }
        public string user_zip_data { get; set; }
        public string user_parent_name { get; set; }
        public string aadhaar_share_code { get; set; }
        public string reference_id { get; set; }
        public bool user_mobile_verified { get; set; }
    }
}
