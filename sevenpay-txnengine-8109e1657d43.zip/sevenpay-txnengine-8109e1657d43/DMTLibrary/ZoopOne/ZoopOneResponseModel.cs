﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.ZoopOne
{
    public class ZoopOneResponseModel
    {
        public string request_id { get; set; }
        public string task_id { get; set; }
        public string group_id { get; set; }
        public bool success { get; set; }
        public string response_code { get; set; }
        public string response_message { get; set; }
        public Metadata metadata { get; set; }
        public dynamic result { get; set; }
        public DateTime request_timestamp { get; set; }
        public DateTime response_timestamp { get; set; }
    }
}
