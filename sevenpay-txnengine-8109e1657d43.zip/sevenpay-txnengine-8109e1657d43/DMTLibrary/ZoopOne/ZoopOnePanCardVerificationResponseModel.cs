﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMTLibrary.ZoopOne
{
    public class ZoopOnePanCardVerificationResponseModel
    {
        public string pan_number { get; set; }
        public string pan_status { get; set; }
        public string user_full_name { get; set; }
        public string pan_type { get; set; }
    }
}
