﻿using BBPSLibrary.CCAvenue;
using CommonLibrary;
using Confluent.Kafka;
using Engine.Events.BBPS;
using Engine.Events.DMT;
using Logger;
using Mapster;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Text;
using System.Text.Json;
using System.Xml;
using System.Xml.Linq;

namespace BBPSPreTransaction
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World from BBPSPreTransaction");

			var serviceProvider = new ServiceCollection()
				// Add your services here..
				.AddSingleton<ICustomLogger, CustomLogger>()
				.BuildServiceProvider();
			// Now get Your Services like this
			var demoService = serviceProvider.GetRequiredService<ICustomLogger>();

			//code to read the configuration from appsetting.json
			IConfiguration config = new ConfigurationBuilder()
				.AddJsonFile("appsettings.json")
				.AddEnvironmentVariables()
				.Build();

			// Get values from the config, given their key and their target type.
			ProducerConfig pconfig = config.GetRequiredSection("ProducerConfig").Get<ProducerConfig>();
			ConsumerConfig cconfig = config.GetRequiredSection("ConsumerConfig").Get<ConsumerConfig>();

			BBPSPreTransactionProcess _process = new BBPSPreTransactionProcess(pconfig, cconfig);
			_process.Init();

		}
	}

	public class BBPSPreTransactionProcess
	{
		private static ProducerConfig _pconfig;
		private static ConsumerConfig _cconfig;
		//logger 
		private readonly ICustomLogger _logger;

		//DEMO
		//private readonly string workingKey = "FE6329515D1DA76CE85A02A0446F220C";
		//Production
		private readonly string workingKey = "850C35EFC63147EE4A42A143CEB42304";

		public BBPSPreTransactionProcess(ProducerConfig pconfig, ConsumerConfig cconfig)
		{
			_cconfig = cconfig;
			_pconfig = pconfig;
			_logger = new CustomLogger("PreBBPSLog");
		}

		public void Init()
		{
			//code added by swapnal and running on different thread for health checkup
			Task.Factory.StartNew(() => new HealthCheckService(), TaskCreationOptions.PreferFairness);

			ResponseModel responseModel = new ResponseModel();
			ExtBillPayResponse billPayResponse = new ExtBillPayResponse();

			//BBPS queue init );
			using (var _consumer = new ConsumerBuilder<Ignore, string>(_cconfig).Build())
			{
				_consumer.Subscribe("BBPSPreTransaction");

				CancellationTokenSource cts = new CancellationTokenSource();
				Console.CancelKeyPress += (_, e) => {
					e.Cancel = true; // prevent the process from terminating.
					cts.Cancel();
				};

				try
				{
					while (true)
					{
						try
						{
							var _message = _consumer.Consume(cts.Token);
							Console.WriteLine($"Consumed message '{_message.Message.Value}' at: '{_message.TopicPartitionOffset}'.");
							_consumer.Commit(_message);
							_logger.LogInfo("Request : " + _message.Message.Value);
							//code to write the logs

							//code commented by swapnal
							//var _dmtModel = _message.Message.Value;
							var _bbpsModel = System.Text.Json.JsonSerializer.Deserialize<BBPSPreTransactionCreatedEvent>(_message.Message.Value);
							Console.WriteLine(_bbpsModel);

							if (_bbpsModel == null) return;

							//code to process the request via CCAveune
							StringBuilder requestXML = new StringBuilder();
							requestXML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><billPaymentRequest>");
							requestXML.Append("<agentId>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.agentId);
							requestXML.Append("</agentId>");
							requestXML.Append("<billerAdhoc>true</billerAdhoc>");
							requestXML.Append("<agentDeviceInfo><ip>");
							requestXML.Append(_bbpsModel.request.location.ip);
							requestXML.Append("</ip><initChannel>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.agentDeviceInfo.initChannel);
							requestXML.Append("</initChannel><mac>01-23-45-67-89-ab</mac>");
							requestXML.Append("</agentDeviceInfo><customerInfo><customerMobile>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.customerInfo.customerMobile);
							requestXML.Append("</customerMobile><customerEmail>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.customerInfo.customerEmail);
							requestXML.Append("</customerEmail><customerAdhaar>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.customerInfo.customerAdhaar);
							requestXML.Append("</customerAdhaar><customerPan>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.customerInfo.customerPan);
							requestXML.Append("</customerPan></customerInfo><billerId>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.billerId);
							requestXML.Append("</billerId><inputParams>");

							foreach (var inputNode in _bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.inputParams.Input)
							{
								requestXML.Append("<input>");
								requestXML.Append("<paramName>");
								requestXML.Append(inputNode.paramName);
								requestXML.Append("</paramName>");
								requestXML.Append("<paramValue>");
								requestXML.Append(inputNode.paramValue);
								requestXML.Append("</paramValue>");
								requestXML.Append("</input>");
							}
							requestXML.Append("</inputParams>");

							//code added by swapnal to handle payment request as quick payment
							if (!string.IsNullOrEmpty(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.requestId))
							{
								/*
								 * 100000
									2015-06-14
									12303
									june
									BBPS
									2015-06-20
								 * 
								 */
								requestXML.Append("<billerResponse><billAmount>");
								requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.billerResponse.billAmount);
								requestXML.Append("</billAmount><billDate>");
								requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.billerResponse.billDate);
								requestXML.Append("</billDate><billNumber>");
								requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.billerResponse.billNumber);
								requestXML.Append("</billNumber><billPeriod>");
								requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.billerResponse.billPeriod);
								requestXML.Append("</billPeriod><customerName>");
								requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.billerResponse.customerName);
								requestXML.Append("</customerName><dueDate>");
								requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.billerResponse.dueDate);
								requestXML.Append("</dueDate>");

								requestXML.Append("<amountOptions>");
								foreach (var inputNode in _bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.billerResponse.amountOptions.option)
								{
									requestXML.Append("<option>");
									requestXML.Append("<amountName>");
									requestXML.Append(inputNode.amountName);
									requestXML.Append("</amountName>");
									requestXML.Append("<amountValue>");
									requestXML.Append(inputNode.amountValue);
									requestXML.Append("</amountValue>");
									requestXML.Append("</option>");
								}
								requestXML.Append("</amountOptions>");


								requestXML.Append("</billerResponse>");


								requestXML.Append("<additionalInfo>");
								foreach (var inputNode in _bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.additionalInfo.info)
								{
									requestXML.Append("<info>");
									requestXML.Append("<infoName>");
									requestXML.Append(inputNode.infoName);
									requestXML.Append("</infoName>");
									requestXML.Append("<infoValue>");
									requestXML.Append(inputNode.infoValue);
									requestXML.Append("</infoValue>");
									requestXML.Append("</info>");
								}
								requestXML.Append("</additionalInfo>");
							}
							//end code added by swapnal to handle payment request as quick payment
							requestXML.Append("<amountInfo><amount>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.amountInfo.amount);
							requestXML.Append("</amount><currency>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.amountInfo.currency);
							requestXML.Append("</currency><custConvFee>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.amountInfo.custConvFee);
							requestXML.Append("</custConvFee><amountTags></amountTags>");
							requestXML.Append("</amountInfo><paymentMethod><paymentMode>Cash</paymentMode>");
							requestXML.Append("<quickPay>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.paymentMethod.quickPay);
							requestXML.Append("</quickPay><splitPay>");
							requestXML.Append(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.paymentMethod.splitPay);
							requestXML.Append("</splitPay></paymentMethod>");
							requestXML.Append("<paymentInfo>");
							requestXML.Append("<info>");
							requestXML.Append("<infoName>Remarks</infoName>");
							requestXML.Append("<infoValue>Received</infoValue>");
							requestXML.Append("</info>");
							requestXML.Append("</paymentInfo>");
							requestXML.Append("</billPaymentRequest>");


							_logger.LogInfo("Request: " + requestXML);

							CCACrypto cCACrypto = new CCACrypto();
							var _requestEnc = cCACrypto.Encrypt(requestXML.ToString(), workingKey);
							Console.WriteLine(_requestEnc);
							CCAvenueProcessor cCAvenueProcessor = new CCAvenueProcessor();

							//get request id
							var _requestId = !string.IsNullOrEmpty(_bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.requestId)
												? _bbpsModel.request.transactionInfo.transactionData.billPaymentRequest.requestId
												: cCAvenueProcessor.GenerateRequestId();
							var _ccREsponse = cCAvenueProcessor.ProcessRequest("extBillPayCntrl/billPayRequest/xml", _requestId, _requestEnc);
							_logger.LogInfo("Response: " + _ccREsponse);

							if (string.IsNullOrEmpty(_ccREsponse))
							{
								responseModel.ResponseCode = "-1";
								responseModel.Response = "failed";
								responseModel.Errors = new List<ErrorModel>() { new ErrorModel() {
									ErrorCode  = "-1",
									Error = "Response is null from. Please try after sometime." } };
								
								_logger.LogInfo("Response: " + _ccREsponse); ;
							}

							if (!string.IsNullOrEmpty(_ccREsponse))
							{
								if (_ccREsponse.Contains("errorInfo"))
								{
									XDocument xdoc = new XDocument();
									xdoc = XDocument.Parse(_ccREsponse);

									//Run query
									var errors = from error in xdoc.Descendants("error") select error;

									List<ErrorModel> errorModels = new List<ErrorModel>();
									foreach (var item in errors)
									{
										errorModels.Add(new ErrorModel() { ErrorCode = item.Element("errorCode").Value, Error = item.Element("errorMessage").Value });
									}

									responseModel.ResponseCode = "-1";
									responseModel.Response = "failed";
									responseModel.Errors = errorModels;
									_logger.LogInfo("Response:Error : " + _ccREsponse);
								}
								else
								{
									var doc = XDocument.Parse(_ccREsponse);
									var _modelJSON = JsonConvert.SerializeXNode(doc).ToString();
									var _responsemodel = System.Text.Json.JsonSerializer.Deserialize<ExtBillPayMainResponse>(_modelJSON.ToString());

									var bbpsTransactionResponseModel = new BBPSTransactionResponseModel
									{
										p_txnid = int.Parse(_bbpsModel.TransactionId.ToString()),
										p_supptxnnumber = _responsemodel.ExtBillPayResponse.txnRefId.ToString(),
										p_txnstatus = _responsemodel.ExtBillPayResponse.responseCode == "000" ? 2 : 1,
										p_userid = _bbpsModel.request.channelPartnerInfo.userId,
										p_apprefno = _responsemodel.ExtBillPayResponse.RespBillNumber.ToString(),
										p_custref5 = _responsemodel.ExtBillPayResponse.RespCustomerName,
										p_remarks = _responsemodel.ExtBillPayResponse.responseReason.ToString(),
										p_sprefno = _responsemodel.ExtBillPayResponse.approvalRefNumber.ToString(),
										p_modifieripaddress = "NA"
									};

									var bbpsPreTransactionUpdatedEvent = new BBPSPreTransactionUpdatedEvent { 
										CreatedDate= DateTime.Now,
										UpdateedDate= DateTime.Now,
										request = _bbpsModel.request,
										responseModel = bbpsTransactionResponseModel,
										TransactionId = _bbpsModel.TransactionId,
										
									};
				
									TransactionsQueueReceiveCompleted(System.Text.Json.JsonSerializer.Serialize(bbpsPreTransactionUpdatedEvent));
									_logger.LogInfo("Response:Error : " + _ccREsponse);
								}
							}


							//return responseModel;

							Console.WriteLine("");
							Console.WriteLine("");
							Console.WriteLine("");
							Console.WriteLine("");
							Console.WriteLine("****** Response from CcAvenu *************");
							//Console.WriteLine(response);


							

						}
						catch (ConsumeException ex)
						{
							_logger.LogInfo("Exception:" + ex.Message.ToString());
							Console.WriteLine($"Error occured: {ex.Error.Reason}");
						}
					}
				}
				catch (OperationCanceledException ex)
				{
					_logger.LogInfo("Exception:" + ex.Message.ToString());
					// Close and Release all the resources held by this consumer
					Console.WriteLine("Error " + ex.Message.ToString());
					_consumer.Close();
				}
			}
			//End Code Accounting queue init

			while (Console.ReadKey().Key != ConsoleKey.Q)
			{
				//Console.WriteLine("Transaction Processing Engine exits gracefully.......");
			}
		}

		private void TransactionsQueueReceiveCompleted(string message)
		{
			object LockObject = new object();


			Console.WriteLine("Hey Delegate called !!!!!!!!!!!!!!!!");
			try
			{
				lock (LockObject)
				{
					//Thread.Sleep(5);

					using (var _publish = new ProducerBuilder<Null, string>(_pconfig).Build())
					{
						try
						{
							Console.WriteLine(message);
							//var _message = _publish.ProduceAsync("DMTPostTransaction", new Message<Null, string> { Value = message });
							_publish.Produce("BBPSPostTransaction", new Message<Null, string> { Value = message }, null);
							//Console.WriteLine($"Delivered '{_message.Result.Value}' to '{_message.Result.TopicPartitionOffset}'");
							_publish.Flush();
							//Thread.Sleep(50000);
							//Console.WriteLine("We are out of sleep - Thread.Sleep(50000)");
						}
						catch (ProduceException<Null, string> e)
						{
							_logger.LogException(e);
							Console.WriteLine($"Delivery failed: {e.Error.Reason}");
						}
					}
				}
			}
			catch (Exception exception)
			{
				_logger.LogInfo("Exception:" + exception.Message.ToString());
				Console.WriteLine("ERROR  { QueueReceiveCompleted }-> " + exception.Message);
			}
		}
	}
}

