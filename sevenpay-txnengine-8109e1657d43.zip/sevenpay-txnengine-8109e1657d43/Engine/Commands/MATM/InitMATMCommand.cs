﻿using Contracts.Common;
using Contracts.DMT;
using Contracts.MATM;
using Contracts.Transaction;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Commands.MATM
{
    public record InitMATMCommand(TransactionCommonRequestDto<MATMTransactionRequestModelDto> entity) : IRequest<ResponseModelDto>;
}
