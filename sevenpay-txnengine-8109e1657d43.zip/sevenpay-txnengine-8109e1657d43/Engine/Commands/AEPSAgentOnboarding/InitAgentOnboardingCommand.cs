﻿using Contracts.Common;
using Contracts.Transaction.DMT;
using Contracts.Transaction;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contracts.AEPSOnboarding;

namespace Engine.Commands.AEPSAgentOnboarding
{
    public record InitAgentOnboardingCommand(TransactionCommonRequestDto<object> entity) : IRequest<ResponseModelDto>;
}
