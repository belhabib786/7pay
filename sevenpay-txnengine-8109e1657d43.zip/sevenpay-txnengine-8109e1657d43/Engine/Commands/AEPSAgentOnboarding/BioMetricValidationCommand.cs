﻿using Contracts.AEPSOnboarding;
using Contracts.Common;
using Contracts.Transaction;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Commands.AEPSAgentOnboarding
{    
    public record BioMetricValidationCommand(TransactionCommonRequestDto<KYCBioMetricDto> entity) : IRequest<ResponseModelDto>;
}
