﻿using Contracts.Common;
using Contracts.Transaction;
using Contracts.Transaction.DMT;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Commands.DMT
{
    public record AddBeneficiaryCommand(TransactionCommonRequestDto<BeneficiaryModelDto> entity) : IRequest<ResponseModelDto>;
}
