﻿using Contracts.Common;
using Contracts.Transaction.Recharge;
using Contracts.Transaction;
using Contracts.UserManagement;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contracts.Transaction.DMT;

namespace Engine.Commands.DMT
{
    public record AddSenderCommand(TransactionCommonRequestDto<CustomerModelDto> entity) : IRequest<ResponseModelDto>;
}
