﻿using Contracts.Common;
using Contracts.Transaction;
using Contracts.Transaction.DMT;
using Domains.Entities.DMT.Customer;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Commands.DMT
{
    public record AddSenderOTPVerificationCommand(TransactionCommonRequestDto<CustomerOTPVerificationModelDto> entity) : IRequest<ResponseModelDto>;
}
