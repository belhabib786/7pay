﻿using Contracts.AEPS;
using Contracts.Common;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Commands.AEPS
{
    
        public record MiniStatementAepsCommand(EnquiryRequestModelDto requestDto) : IRequest<ResponseModelDto>;
    
}
