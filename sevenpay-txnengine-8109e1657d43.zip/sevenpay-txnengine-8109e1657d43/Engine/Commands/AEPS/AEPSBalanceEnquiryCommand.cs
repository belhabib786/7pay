﻿using Contracts.Common;
using Contracts.Transaction.DMT;
using Contracts.Transaction;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contracts.AEPS;

namespace Engine.Commands.AEPS
{
	public record AEPSBalanceEnquiryCommand(TransactionCommonRequestDto<AEPSBalanceEnquiryDto> entity) : IRequest<ResponseModelDto>;
}
