﻿using Contracts.AEPS;
using Contracts.Common;
using Contracts.Transaction;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Commands.AEPS
{
	public record AEPSWithdrawalCommand(TransactionCommonRequestDto<AEPSCashWithdrawalDto> entity) : IRequest<ResponseModelDto>;
}
