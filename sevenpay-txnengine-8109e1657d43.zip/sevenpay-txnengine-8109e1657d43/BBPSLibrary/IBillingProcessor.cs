﻿using BBPSLibrary.CCAvenue;
using CommonLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary
{
	public interface IBillingProcessor
	{
		public ResponseModel GetBillerInfo(string billercode);
		ResponseModel FetchBillerInformation(dynamic billerInfoModel);

		ResponseModel QuickBillPayment(dynamic billerModel);
		ResponseModel StatusCheck(int referenceType, string resfeenceInfo);
		ResponseModel ComplaintRegistration(ComplaintRegistrationModel complaintRegistrationModel);
		ResponseModel ComplaintTracking(string complaintId);

		string GenerateRequestId();
		string ProcessRequest(string url, string requestId, string requestdata);
	}
}
