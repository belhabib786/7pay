﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class Xml
	{
		[JsonProperty("@version")]
		public string version { get; set; }

		[JsonProperty("@encoding")]
		public string encoding { get; set; }

		[JsonProperty("@standalone")]
		public string standalone { get; set; }
	}
}
