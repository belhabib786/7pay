﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	public class BillerInfoResponse
	{
		public string responseCode { get; set; }
		public Biller biller { get; set; }
	}
}
