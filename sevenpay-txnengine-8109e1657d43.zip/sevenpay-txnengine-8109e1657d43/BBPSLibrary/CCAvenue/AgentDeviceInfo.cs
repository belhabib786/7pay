﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	[XmlRoot(ElementName = "agentDeviceInfo")]
	public class AgentDeviceInfo
	{
		[XmlElement(ElementName = "ip")]
		public string ip { get; set; }
		[XmlElement(ElementName = "initChannel")]
		public string initChannel { get; set; }
		[XmlElement(ElementName = "mac")]
		public string mac { get; set; }
	}
}
