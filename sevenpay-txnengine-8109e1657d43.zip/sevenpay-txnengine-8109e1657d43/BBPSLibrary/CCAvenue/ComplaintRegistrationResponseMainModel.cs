﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class ComplaintRegistrationResponseMainModel
	{
		public Xml xml { get; set; }
		public ComplaintRegistrationResp complaintRegistrationResp { get; set; }
	}
}
