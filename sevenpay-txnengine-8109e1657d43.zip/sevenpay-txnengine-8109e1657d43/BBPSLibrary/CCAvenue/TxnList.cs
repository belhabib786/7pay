﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class TxnList
	{
		public string agentId { get; set; }
		public string amount { get; set; }
		public string billerId { get; set; }
		public DateTime txnDate { get; set; }
		public string txnReferenceId { get; set; }
		public string txnStatus { get; set; }
		public string mobile { get; set; }
		public string approvalRefNumber { get; set; }
		public List<InputParam> inputParams { get; set; }
		public string txnRespType { get; set; }
		public string custConvFee { get; set; }
		public string respBillNumber { get; set; }
		public string respBillPeriod { get; set; }
		public string respCustomerName { get; set; }
		public string respDueDate { get; set; }
	}
}
