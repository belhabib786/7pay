﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class BillFetchResponseModel
	{
		public string BillFetchResponse { get; set; }
		public string RequestId { get; set; }	
	}
}
