﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class TransactionStatusResp
	{
		public string responseCode { get; set; }
		public string responseReason { get; set; }
		public TxnList txnList { get; set; }
	}
}
