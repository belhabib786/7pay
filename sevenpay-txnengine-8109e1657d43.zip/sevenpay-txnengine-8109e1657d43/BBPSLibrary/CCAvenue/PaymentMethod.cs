﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	[XmlRoot(ElementName = "paymentMethod")]
	public class PaymentMethod
	{
		[XmlElement(ElementName = "paymentMode")]
		public string PaymentMode { get; set; }
		[XmlElement(ElementName = "quickPay")]
		public string QuickPay { get; set; }
		[XmlElement(ElementName = "splitPay")]
		public string SplitPay { get; set; }
	}
}
