﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	public class ComplaintRegistrationResp
	{
		public string complaintAssigned { get; set; }
		public string complaintId { get; set; }
		public string responseCode { get; set; }
		public string responseReason { get; set; }
	}
}
