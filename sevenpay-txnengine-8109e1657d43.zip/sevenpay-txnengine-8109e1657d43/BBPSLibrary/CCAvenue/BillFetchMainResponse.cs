﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class BillFetchMainResponse
	{
		public Xml xml { get; set; }
		public BillFetchResponse billFetchResponse { get; set; }
		public string requestId { get; set; }
	}
}
