﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	public class ExtBillPayResponse
	{
		public string responseCode { get; set; }
		public string responseReason { get; set; }
		public string txnRefId { get; set; }
		public string requestId { get; set; }
		public string approvalRefNumber { get; set; }
		public string txnRespType { get; set; }
		public string CustConvFee { get; set; }
		public string RespAmount { get; set; }
		public DateTime RespBillDate { get; set; }
		public string RespBillNumber { get; set; }
		public string RespBillPeriod { get; set; }
		public string RespCustomerName { get; set; }
		public DateTime RespDueDate { get; set; }
		public ErrorInfo errorInfo { get; set; }
		public Input input { get; set; }
		public InputResponseParams inputParams { get; set; }
	}

}
