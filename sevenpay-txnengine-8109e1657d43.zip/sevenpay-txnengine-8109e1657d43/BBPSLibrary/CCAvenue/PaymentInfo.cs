﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	[XmlRoot(ElementName = "paymentInfo")]
	public class PaymentInfo
	{
		[XmlElement(ElementName = "info")]
		public Info Info { get; set; }
	}
}
