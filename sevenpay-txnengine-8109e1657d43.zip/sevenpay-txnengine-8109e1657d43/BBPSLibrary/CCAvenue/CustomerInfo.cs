﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	[XmlRoot(ElementName = "customerInfo")]
	public class CustomerInfo
	{
		[XmlElement(ElementName = "customerMobile")]
		public string customerMobile { get; set; }
		[XmlElement(ElementName = "customerEmail")]
		public string customerEmail { get; set; }
		[XmlElement(ElementName = "customerAdhaar")]
		public string customerAdhaar { get; set; }
		[XmlElement(ElementName = "customerPan")]
		public string customerPan { get; set; }
	}
}
