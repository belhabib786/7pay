﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	[XmlRoot(ElementName = "billPaymentRequest")]
	public class BillPaymentRequest
	{
		[XmlElement(ElementName = "agentId")]
		public string AgentId { get; set; }

		//code added by swapnal 
		public string requestId {get; set; }

		[XmlElement(ElementName = "billerAdhoc")]
		public string BillerAdhoc { get; set; }
		[XmlElement(ElementName = "agentDeviceInfo")]
		public AgentDeviceInfo AgentDeviceInfo { get; set; }
		[XmlElement(ElementName = "customerInfo")]
		public CustomerInfo CustomerInfo { get; set; }
		[XmlElement(ElementName = "billerId")]
		public string BillerId { get; set; }
		[XmlElement(ElementName = "inputParams")]
		public InputParams InputParams { get; set; }
		[XmlElement(ElementName = "billerResponse")]
		public BillerResponse BillerResponse { get; set; }
		[XmlElement(ElementName = "additionalInfo")]
		public AdditionalInfo AdditionalInfo { get; set; }
		[XmlElement(ElementName = "amountInfo")]
		public AmountInfo AmountInfo { get; set; }
		[XmlElement(ElementName = "paymentMethod")]
		public PaymentMethod PaymentMethod { get; set; }
		[XmlElement(ElementName = "paymentInfo")]
		public PaymentInfo PaymentInfo { get; set; }
	}

}
