﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class BillFetchResponse
	{
		public string responseCode { get; set; }
		public JsonObject? inputParam { get; set; }
		public BillerResponse? billerResponse { get; set; }
		public AdditionalInfo? additionalInfo { get; set; }
	}
}
