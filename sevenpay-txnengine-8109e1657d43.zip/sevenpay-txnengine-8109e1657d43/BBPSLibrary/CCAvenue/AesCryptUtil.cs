﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class AesCryptUtil
	{
		private byte[] data;

		private byte[] AesIV;

		public AesCryptUtil(string Key)
		{
			data = MD5.Create().ComputeHash(Encoding.UTF8.GetBytes(Key));
			AesIV = new byte[16]
			{
			0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
			10, 11, 12, 13, 14, 15
			};
		}

		public string encrypt(string strToEncrypt)
		{
			string text = "";
			using (new RijndaelManaged())
			{
				byte[] array = EncryptStringToBytes(strToEncrypt, data, AesIV);
				StringBuilder stringBuilder = new StringBuilder();
				byte[] array2 = array;
				foreach (byte b in array2)
				{
					stringBuilder.AppendFormat("{0:x2}", b);
				}
				return stringBuilder.ToString();
			}
		}

		private static byte[] EncryptStringToBytes(string plainText, byte[] Key, byte[] IV)
		{
			if (plainText == null || plainText.Length <= 0)
			{
				throw new ArgumentNullException("plainText");
			}
			if (Key == null || Key.Length <= 0)
			{
				throw new ArgumentNullException("Key");
			}
			if (IV == null || IV.Length <= 0)
			{
				throw new ArgumentNullException("Key");
			}
			using RijndaelManaged rijndaelManaged = new RijndaelManaged();
			rijndaelManaged.Key = Key;
			rijndaelManaged.IV = IV;
			ICryptoTransform transform = rijndaelManaged.CreateEncryptor(rijndaelManaged.Key, rijndaelManaged.IV);
			using MemoryStream memoryStream = new MemoryStream();
			using CryptoStream stream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
			using (StreamWriter streamWriter = new StreamWriter(stream))
			{
				streamWriter.Write(plainText);
			}
			return memoryStream.ToArray();
		}

		public string decrypt(string strToDecrypt)
		{
			using (new RijndaelManaged())
			{
				return DecryptStringFromBytes(strToDecrypt, data, AesIV);
			}
		}

		private static string DecryptStringFromBytes(string encryptedText, byte[] Key, byte[] IV)
		{
			int length = encryptedText.Length;
			byte[] array = new byte[length / 2];
			for (int i = 0; i < length; i += 2)
			{
				array[i / 2] = Convert.ToByte(encryptedText.Substring(i, 2), 16);
			}
			if (array == null || array.Length <= 0)
			{
				throw new ArgumentNullException("cipherText");
			}
			if (Key == null || Key.Length <= 0)
			{
				throw new ArgumentNullException("Key");
			}
			if (IV == null || IV.Length <= 0)
			{
				throw new ArgumentNullException("Key");
			}
			string text = null;
			using RijndaelManaged rijndaelManaged = new RijndaelManaged();
			rijndaelManaged.Key = Key;
			rijndaelManaged.IV = IV;
			ICryptoTransform transform = rijndaelManaged.CreateDecryptor(rijndaelManaged.Key, rijndaelManaged.IV);
			using MemoryStream stream = new MemoryStream(array);
			using CryptoStream stream2 = new CryptoStream(stream, transform, CryptoStreamMode.Read);
			using StreamReader streamReader = new StreamReader(stream2);
			return streamReader.ReadToEnd();
		}
	}
}
