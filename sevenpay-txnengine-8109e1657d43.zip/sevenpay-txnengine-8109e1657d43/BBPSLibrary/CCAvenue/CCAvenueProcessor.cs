﻿using CommonLibrary;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace BBPSLibrary.CCAvenue
{
	public class CCAvenueProcessor : IBillingProcessor
	{
		//DEMO
		//string workingKey = "FE6329515D1DA76CE85A02A0446F220C";
		//Production
		string workingKey = "850C35EFC63147EE4A42A143CEB42304";

		public ResponseModel GetBillerInfo(string billercode)
		{
			/*
			 * <?xml version="1.0" encoding="UTF-8"?>
				<billerInfoRequest>
				 <billerId>BHAR00000NATR4</billerId>
				</billerInfoRequest>
			 * 
			 */

			ResponseModel responseModel = new ResponseModel();

			StringBuilder requestXML = new StringBuilder();

			if (billercode != null)
			{
				requestXML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><billerInfoRequest>");
				requestXML.Append("<billerId>");
				requestXML.Append(billercode);
				requestXML.Append("</billerId>");
				requestXML.Append("</billerInfoRequest>");
			}

			CCACrypto cCACrypto = new CCACrypto();
			var _requestEnc = cCACrypto.Encrypt(requestXML.ToString(), workingKey);
			Console.WriteLine(_requestEnc);

			CCAvenueProcessor cCAvenueProcessor = new CCAvenueProcessor();
			var _requestId = cCAvenueProcessor.GenerateRequestId();
			//https://api.billavenue.com/billpay/extMdmCntrl/mdmRequestNew/xml
			var _ccREsponse = cCAvenueProcessor.BiilerInfoFetchRequest("extMdmCntrl/mdmRequestNew/xml", _requestId, _requestEnc);

			if (!string.IsNullOrEmpty(_ccREsponse))
			{
				if (_ccREsponse.Contains("errorCode"))
				{
					XDocument xdoc = new XDocument();
					xdoc = XDocument.Parse(_ccREsponse);

					//Run query
					var errors = from error in xdoc.Descendants("error") select error;

					List<ErrorModel> errorModels = new List<ErrorModel>();
					foreach (var item in errors)
					{
						errorModels.Add(new ErrorModel() { ErrorCode = item.Element("errorCode").Value, Error = item.Element("errorMessage").Value });
					}

					responseModel.ResponseCode = "-1";
					responseModel.Response = "failed";
					responseModel.Errors = errorModels;
					return responseModel;
				}

				//code added by swapnal for testing
				var doc = XDocument.Parse(_ccREsponse);
				var _modelJSON = JsonConvert.SerializeXNode(doc).ToString();
				var _model = System.Text.Json.JsonSerializer.Deserialize<BillerInfoResponseMainModel>(_modelJSON.ToString());

				if (_model != null)
				{
					_model.requestId = _requestId;
					responseModel.ResponseCode = "0";
					responseModel.Response = "Success";
					responseModel.Data = _model;
				}
				else
				{
					responseModel.ResponseCode = "-1";
					responseModel.Response = "failed";
					responseModel.Errors = new List<ErrorModel>() { new ErrorModel() {
					ErrorCode  = "-1",
					Error = "Unable to fetch biller information. Please try after sometime." } };
				}
				//end code added by swapnal for testing

				return responseModel;
			}


			return responseModel;
		}

		public ResponseModel FetchBillerInformation(dynamic billerInfoModel)
		{
			/*
			 * <?xml version=""1.0"" encoding=""UTF-8""?><billFetchRequest>
			   <agentId>CC01CC01513515340681</agentId>
			   <agentDeviceInfo>
				  <ip>192.168.2.73</ip>
				  <initChannel>AGT</initChannel>
				  <mac>01-23-45-67-89-ab</mac>
			   </agentDeviceInfo>
			   <customerInfo>
				  <customerMobile>9898990084</customerMobile>
				  <customerEmail></customerEmail>
				  <customerAdhaar></customerAdhaar>
				  <customerPan></customerPan>
			   </customerInfo>
			   <billerId>OTME00005XXZ43</billerId>
			   <inputParams>
				  <input>
					 <paramName>a</paramName>
					 <paramValue>10</paramValue>
				  </input>
				  <input>
					 <paramName>a b</paramName>
					 <paramValue>20</paramValue>
				  </input>
				  <input>
					 <paramName>a b c</paramName>
					 <paramValue>30</paramValue>
				  </input>
				  <input>
					 <paramName>a b c d</paramName>
					 <paramValue>40</paramValue>
				  </input>
				  <input>
					 <paramName>a b c d e</paramName>
					 <paramValue>50</paramValue>
				  </input>
			   </inputParams>
			</billFetchRequest>
			 * 
			 */

			ResponseModel responseModel = new ResponseModel();

			StringBuilder requestXML = new StringBuilder();

			var _requestString = System.Text.Json.JsonSerializer.Deserialize<Object>(billerInfoModel).ToString();
			BillFetchRequestModel request = System.Text.Json.JsonSerializer.Deserialize<BillFetchRequestModel>(_requestString);

			if (request != null)
			{
				requestXML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><billFetchRequest>"); 
				requestXML.Append("<agentId>"); 
				requestXML.Append(request.billFetchRequestDto.agentId); 
				requestXML.Append("</agentId>"); 
				requestXML.Append("<agentDeviceInfo>"); 
				requestXML.Append("<ip>"); 
				requestXML.Append(request.billFetchRequestDto.agentDeviceInfo.ip); 
				requestXML.Append("</ip>"); 
				requestXML.Append("<initChannel>"); 
				requestXML.Append(request.billFetchRequestDto.agentDeviceInfo.initChannel); 
				requestXML.Append("</initChannel>"); 
				requestXML.Append("<mac>"); 
				requestXML.Append(request.billFetchRequestDto.agentDeviceInfo.mac); 
				requestXML.Append("</mac>"); 
				requestXML.Append("</agentDeviceInfo>"); 
				requestXML.Append("<customerInfo>"); 
				requestXML.Append("<customerMobile>"); 
				requestXML.Append(request.billFetchRequestDto.customerInfo.customerMobile); 
				requestXML.Append("</customerMobile>"); 
				requestXML.Append("<customerEmail>"); 
				requestXML.Append(request.billFetchRequestDto.customerInfo.customerEmail); 
				requestXML.Append("</customerEmail>"); 
				requestXML.Append("<customerAdhaar>"); 
				requestXML.Append(request.billFetchRequestDto.customerInfo.customerAdhaar); 
				requestXML.Append("</customerAdhaar>"); 
				requestXML.Append("<customerPan>"); 
				requestXML.Append(request.billFetchRequestDto.customerInfo.customerPan); 
				requestXML.Append("</customerPan>"); 
				requestXML.Append("</customerInfo>"); 
				requestXML.Append("<billerId>"); 
				requestXML.Append(request.billFetchRequestDto.billerId); 
				requestXML.Append("</billerId>"); 
				requestXML.Append("<inputParams>"); 
				
				foreach (var inputNode in request.billFetchRequestDto.inputParams.input) 
					{ 
						requestXML.Append("<input>"); 
						requestXML.Append("<paramName>"); 
						requestXML.Append(inputNode.paramName); 
						requestXML.Append("</paramName>"); 
						requestXML.Append("<paramValue>"); 
						requestXML.Append(inputNode.paramValue); 
						requestXML.Append("</paramValue>"); 
						requestXML.Append("</input>"); 
					}
						requestXML.Append("</inputParams>"); 
						requestXML.Append("</billFetchRequest>"); 				
			}

			CCACrypto cCACrypto = new CCACrypto();
			var _requestEnc = cCACrypto.Encrypt(requestXML.ToString(), workingKey);
			Console.WriteLine(_requestEnc);

			CCAvenueProcessor cCAvenueProcessor = new CCAvenueProcessor();
			var _requestId = cCAvenueProcessor.GenerateRequestId();
			var _ccREsponse = cCAvenueProcessor.ProcessRequest("extBillCntrl/billFetchRequest/xml", _requestId, _requestEnc);

			if(!string.IsNullOrEmpty(_ccREsponse))
			{
				if (_ccREsponse.Contains("errorCode"))
				{
					XDocument xdoc = new XDocument();
					xdoc = XDocument.Parse(_ccREsponse);

					//Run query
					var errors = from error in xdoc.Descendants("error") select error;

					List<ErrorModel> errorModels = new List<ErrorModel>();
					foreach (var item in errors)
					{
						errorModels.Add(new ErrorModel() { ErrorCode = item.Element("errorCode").Value, Error = item.Element("errorMessage").Value });
					}

					responseModel.ResponseCode = "-1";
					responseModel.Response = "failed";
					responseModel.Errors = errorModels;
					return responseModel;
				}

				//code added by swapnal for testing
				var doc = XDocument.Parse(_ccREsponse);
				var _modelJSON = JsonConvert.SerializeXNode(doc).ToString();
				var _model = System.Text.Json.JsonSerializer.Deserialize<BillFetchMainResponse>(_modelJSON.ToString());

				if (_model != null)
				{
					_model.requestId = _requestId;
					responseModel.ResponseCode = "0";
					responseModel.Response = "Success";
					responseModel.Data = _model;
				}
				else {
					responseModel.ResponseCode = "-1";
					responseModel.Response = "failed";
					responseModel.Errors = new List<ErrorModel>() { new ErrorModel() {
					ErrorCode  = "-1",
					Error = "Unable to fetch biller information. Please try after sometime." } };
				}
				//end code added by swapnal for testing

				/*
				XmlDocument xmlDoc = new XmlDocument();
				xmlDoc.LoadXml(_ccREsponse);
				// Convert XmlDocument to JObject 
				JObject jsonObject = JObject.Parse(JsonConvert.SerializeXmlNode(xmlDoc));
				
				var innerContent = jsonObject.GetValue("billFetchResponse");
				BillFetchResponseModel billFetchResponseModel = new BillFetchResponseModel { BillFetchResponse = innerContent.ToString(),
																	RequestId = _requestId };
				JProperty orderProp = new JProperty("requestId", _requestId);
				//query.Add(orderProp);
				jsonObject.Add(orderProp);
				// Convert JObject to JSON string 
				string jsonResponse = innerContent.ToString();
				responseModel.ResponseCode = "0";
				responseModel.Response = "Success";
				responseModel.Data = billFetchResponseModel;

				*/

				return responseModel;
			}


			return responseModel;
		}
		public ResponseModel QuickBillPayment(dynamic billerModel)
		{
			ResponseModel responseModel = new ResponseModel();

			StringBuilder requestXML = new StringBuilder();

			/*
			 * "<?xml version=""1.0"" encoding=""UTF-8""?>
				<billPaymentRequest>
					<agentId>CC01CC01513515340681</agentId>
					<billerAdhoc>true</billerAdhoc>
					<agentDeviceInfo>
						<ip>192.168.2.73</ip>
						<initChannel>AGT</initChannel>
						<mac>01-23-45-67-89-ab</mac>
					</agentDeviceInfo>
					<customerInfo>
						<customerMobile>9898990084</customerMobile>
						<customerEmail></customerEmail>
						<customerAdhaar></customerAdhaar>
						<customerPan></customerPan>
					</customerInfo>
					<billerId>OTME00005XXZ43</billerId>
				   <inputParams>
					  <input>
						 <paramName>a</paramName>
						 <paramValue>10</paramValue>
					  </input>
					  <input>
						 <paramName>a b</paramName>
						 <paramValue>20</paramValue>
					  </input>
					  <input>
						 <paramName>a b c</paramName>
						 <paramValue>30</paramValue>
					  </input>
					  <input>
						 <paramName>a b c d</paramName>
						 <paramValue>40</paramValue>
					  </input>
					  <input>
						 <paramName>a b c d e</paramName>
						 <paramValue>50</paramValue>
					  </input>
				   </inputParams>
				   <billerResponse>
						<billAmount>100000</billAmount>
						<billDate>2015-06-14</billDate>
						<billNumber>12303</billNumber>
						<billPeriod>june</billPeriod>
						<customerName>BBPS</customerName>
						<dueDate>2015-06-20</dueDate>
						<amountOptions>
							<option>
								<amountName>Late Payment Fee</amountName>
								<amountValue>40</amountValue>
							</option>
							<option>
								<amountName>Fixed Charges</amountName>
								<amountValue>50</amountValue>
							</option>
						<option>
								<amountName>Additional Charges</amountName>
								<amountValue>60</amountValue>
							</option>
						</amountOptions>
					</billerResponse>
					<additionalInfo>
						<info>
							<infoName>a</infoName>
							<infoValue>10</infoValue>
						</info>
						<info>
							<infoName>a b</infoName>
							<infoValue>20</infoValue>
						</info>
						<info>
							<infoName>a b c</infoName>
							<infoValue>30</infoValue>
						</info>
						<info>
							<infoName>a b c d</infoName>
							<infoValue>40</infoValue>
						</info>
					</additionalInfo>
					<amountInfo>
						<amount>100000</amount>
						<currency>356</currency>
						<custConvFee>0</custConvFee>
						<amountTags></amountTags>
					</amountInfo>
					<paymentMethod>
						<paymentMode>Cash</paymentMode>
						<quickPay>N</quickPay>
						<splitPay>N</splitPay>
					</paymentMethod>
					<paymentInfo>
						<info>
							<infoName>Remarks</infoName>
							<infoValue>Received</infoValue>
						</info>
					</paymentInfo>
				</billPaymentRequest>";
			 */

			var _requestString = System.Text.Json.JsonSerializer.Deserialize<Object>(billerModel).ToString();
			BillFetchRequestModel request = System.Text.Json.JsonSerializer.Deserialize<BillFetchRequestModel>(_requestString);

			if (request != null)
			{
				requestXML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><billFetchRequest>");
				requestXML.Append("<agentId>");
				requestXML.Append(request.billFetchRequestDto.agentId);
				requestXML.Append("</agentId>");
				requestXML.Append("<agentDeviceInfo>");
				requestXML.Append("<ip>");
				requestXML.Append(request.billFetchRequestDto.agentDeviceInfo.ip);
				requestXML.Append("</ip>");
				requestXML.Append("<initChannel>");
				requestXML.Append(request.billFetchRequestDto.agentDeviceInfo.initChannel);
				requestXML.Append("</initChannel>");
				requestXML.Append("<mac>");
				requestXML.Append(request.billFetchRequestDto.agentDeviceInfo.mac);
				requestXML.Append("</mac>");
				requestXML.Append("</agentDeviceInfo>");
				requestXML.Append("<customerInfo>");
				requestXML.Append("<customerMobile>");
				requestXML.Append(request.billFetchRequestDto.customerInfo.customerMobile);
				requestXML.Append("</customerMobile>");
				requestXML.Append("<customerEmail>");
				requestXML.Append(request.billFetchRequestDto.customerInfo.customerEmail);
				requestXML.Append("</customerEmail>");
				requestXML.Append("<customerAdhaar>");
				requestXML.Append(request.billFetchRequestDto.customerInfo.customerAdhaar);
				requestXML.Append("</customerAdhaar>");
				requestXML.Append("<customerPan>");
				requestXML.Append(request.billFetchRequestDto.customerInfo.customerPan);
				requestXML.Append("</customerPan>");
				requestXML.Append("</customerInfo>");
				requestXML.Append("<billerId>");
				requestXML.Append(request.billFetchRequestDto.billerId);
				requestXML.Append("</billerId>");
				requestXML.Append("<inputParams>");

				foreach (var inputNode in request.billFetchRequestDto.inputParams.input)
				{
					requestXML.Append("<input>");
					requestXML.Append("<paramName>");
					requestXML.Append(inputNode.paramName);
					requestXML.Append("</paramName>");
					requestXML.Append("<paramValue>");
					requestXML.Append(inputNode.paramValue);
					requestXML.Append("</paramValue>");
					requestXML.Append("</input>");
				}
				requestXML.Append("</inputParams>");
				requestXML.Append("</billFetchRequest>");
			}

			CCACrypto cCACrypto = new CCACrypto();
			var _requestEnc = cCACrypto.Encrypt(requestXML.ToString(), workingKey);
			Console.WriteLine(_requestEnc);

			CCAvenueProcessor cCAvenueProcessor = new CCAvenueProcessor();
			var _requestId = cCAvenueProcessor.GenerateRequestId();
			var _ccREsponse = cCAvenueProcessor.ProcessRequest("extBillCntrl/billFetchRequest/xml", _requestId, _requestEnc);

			if (!string.IsNullOrEmpty(_ccREsponse))
			{
				XmlDocument xmlDoc = new XmlDocument();
				xmlDoc.LoadXml(_ccREsponse);
				// Convert XmlDocument to JObject 
				JObject jsonObject = JObject.Parse(JsonConvert.SerializeXmlNode(xmlDoc));

				var innerContent = jsonObject.GetValue("billFetchResponse");
				BillFetchResponseModel billFetchResponseModel = new BillFetchResponseModel
				{
					BillFetchResponse = innerContent.ToString(),
					RequestId = _requestId
				};
				JProperty orderProp = new JProperty("requestId", _requestId);
				//query.Add(orderProp);
				jsonObject.Add(orderProp);
				// Convert JObject to JSON string 
				string jsonResponse = innerContent.ToString();

				responseModel.ResponseCode = "0";
				responseModel.Response = "Success";
				responseModel.Data = billFetchResponseModel;
				return responseModel;
			}

			responseModel.ResponseCode = "-1";
			responseModel.Response = "failed";
			responseModel.Errors = new List<ErrorModel>() { new ErrorModel() {
					ErrorCode  = "-1",
					Error = "Unable to fetch biller information. Please try after sometime." } };

			return responseModel;
		}
		public ResponseModel StatusCheck(int referenceType, string resfeenceInfo)
		{
			/*
			 * Tracking type (either 
			 * 0 = TRANS_REF_ID, or 
			 * 1 = MOBILE_NO, or 
			 * 2 = REQUEST_ID)

			 * 
			 * 
			 * "<?xml version=""1.0"" encoding=""UTF-8""?>
<transactionStatusReq>
 <trackType>REQUEST_ID</trackType>
 <trackValue>23076bc0233c4b4fac95776d19206151837</trackValue>
</transactionStatusReq>";
			 * 
			 */

			ResponseModel responseModel = new ResponseModel();

			StringBuilder requestXML = new StringBuilder();

			requestXML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			requestXML.Append("<transactionStatusReq><trackType>");
			requestXML.Append(referenceType == 0 ? "TRANS_REF_ID" : referenceType == 1 ? "MOBILE_NO" : "REQUEST_ID");
			requestXML.Append("</trackType><trackValue>");
			requestXML.Append(resfeenceInfo);
			requestXML.Append("</trackValue></transactionStatusReq>");
			
			

			CCACrypto cCACrypto = new CCACrypto();
			var _requestEnc = cCACrypto.Encrypt(requestXML.ToString(), workingKey);
			Console.WriteLine(_requestEnc);

			CCAvenueProcessor cCAvenueProcessor = new CCAvenueProcessor();
			var _requestId = cCAvenueProcessor.GenerateRequestId();
			var _ccREsponse = cCAvenueProcessor.ProcessRequest("transactionStatus/fetchInfo/xml", _requestId, _requestEnc);

			if (!string.IsNullOrEmpty(_ccREsponse))
			{
				if (_ccREsponse.Contains("errorCode"))
				{
					XDocument xdoc = new XDocument();
					xdoc = XDocument.Parse(_ccREsponse);

					//Run query
					var errors = from error in xdoc.Descendants("error") select error;

					List<ErrorModel> errorModels = new List<ErrorModel>();
					foreach (var item in errors)
					{
						errorModels.Add(new ErrorModel() { ErrorCode = item.Element("errorCode").Value, Error = item.Element("errorMessage").Value });
					}

					responseModel.ResponseCode = "-1";
					responseModel.Response = "failed";
					responseModel.Errors = errorModels;
					return responseModel;
				}

				//code added by swapnal for testing
				var doc = XDocument.Parse(_ccREsponse);
				var _modelJSON = JsonConvert.SerializeXNode(doc).ToString();
				var _model = System.Text.Json.JsonSerializer.Deserialize<TransactionStatusMainResponse>(_modelJSON.ToString());

				if (_model != null)
				{
					responseModel.ResponseCode = "0";
					responseModel.Response = "Success";
					responseModel.Data = _model;
				}
				else
				{
					responseModel.ResponseCode = "-1";
					responseModel.Response = "failed";
					responseModel.Errors = new List<ErrorModel>() { new ErrorModel() {
					ErrorCode  = "-1",
					Error = "Unable to check biller transaction information. Please try after sometime." } };
				}
				//end code added by swapnal for testing
			}
			return responseModel;
		}
		public ResponseModel ComplaintRegistration(ComplaintRegistrationModel complaintRegistrationModel)
		{
			/*
				<?xml version="1.0" encoding="UTF-8"?>
				<complaintRegistrationReq>
				<complaintType>Transaction</complaintType>
				 <participationType />
				 <agentId />
				 <txnRefId>CC017B090155</txnRefId>
				 <billerId />
				 <complaintDesc>Complaint initiated through API</complaintDesc>
				 <servReason />
				 <complaintDisposition>Transaction Successful, account not updated</complaintDisposition>
				</complaintRegistrationReq>
			 * 
			 */

			ResponseModel responseModel = new ResponseModel();

			StringBuilder requestXML = new StringBuilder();

			requestXML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			requestXML.Append("<complaintRegistrationReq><complaintType>Transaction</complaintType><participationType /><agentId/><txnRefId>");
			requestXML.Append(complaintRegistrationModel.resfeenceId);
			requestXML.Append("</txnRefId><billerId/><complaintDesc>");
			requestXML.Append(complaintRegistrationModel.complaintDesc);
			requestXML.Append("</complaintDesc><servReason/><complaintDisposition>");
			requestXML.Append(complaintRegistrationModel.complaintDisposition);
			requestXML.Append("</complaintDisposition></complaintRegistrationReq>");


			CCACrypto cCACrypto = new CCACrypto();
			var _requestEnc = cCACrypto.Encrypt(requestXML.ToString(), workingKey);
			Console.WriteLine(_requestEnc);

			CCAvenueProcessor cCAvenueProcessor = new CCAvenueProcessor();
			var _requestId = cCAvenueProcessor.GenerateRequestId();
			var _ccREsponse = cCAvenueProcessor.ProcessRequest("extComplaints/register/xml", _requestId, _requestEnc);

			if (!string.IsNullOrEmpty(_ccREsponse))
			{
				if (_ccREsponse.Contains("errorCode"))
				{
					XDocument xdoc = new XDocument();
					xdoc = XDocument.Parse(_ccREsponse);

					//Run query
					var errors = from error in xdoc.Descendants("error") select error;

					List<ErrorModel> errorModels = new List<ErrorModel>();
					foreach (var item in errors)
					{
						errorModels.Add(new ErrorModel() { ErrorCode = item.Element("errorCode").Value, Error = item.Element("errorMessage").Value });
					}

					responseModel.ResponseCode = "-1";
					responseModel.Response = "failed";
					responseModel.Errors = errorModels;

				}
				
				var doc = XDocument.Parse(_ccREsponse);
				var _modelJSON = JsonConvert.SerializeXNode(doc).ToString();
				var _model = System.Text.Json.JsonSerializer.Deserialize<ComplaintRegistrationResponseMainModel>(_modelJSON.ToString());

				responseModel.ResponseCode = "0";
				responseModel.Response = "Success";
				responseModel.Data = _model;
				return responseModel;
			}
			return responseModel;
		}
		public ResponseModel ComplaintTracking(string complaintId)
		{
			/*
				
				Tracking type (either TRANS_REF_ID, or MOBILE_NO, or REQUEST_ID
			
				<?xml version="1.0" encoding="UTF-8"?>
				<complaintTrackingReq>
				<complaintType>Transaction</complaintType>
				<complaintId>XD1495446616192</complaintId>
				</complaintTrackingReq>
			 * 
			 */

			ResponseModel responseModel = new ResponseModel();

			StringBuilder requestXML = new StringBuilder();

			requestXML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			requestXML.Append("<complaintTrackingReq><complaintType>Transaction</complaintType><complaintId>");
			requestXML.Append(complaintId);
			requestXML.Append("</complaintId></complaintTrackingReq>");
			

			CCACrypto cCACrypto = new CCACrypto();
			var _requestEnc = cCACrypto.Encrypt(requestXML.ToString(), workingKey);
			Console.WriteLine(_requestEnc);

			CCAvenueProcessor cCAvenueProcessor = new CCAvenueProcessor();
			var _requestId = cCAvenueProcessor.GenerateRequestId();
			var _ccREsponse = cCAvenueProcessor.ProcessRequest("extComplaints/track/xml", _requestId, _requestEnc);

			if (!string.IsNullOrEmpty(_ccREsponse))
			{
				if (_ccREsponse.Contains("errorCode"))
				{
					XDocument xdoc = new XDocument();
					xdoc = XDocument.Parse(_ccREsponse);

					//Run query
					var errors = from error in xdoc.Descendants("error") select error;

					List<ErrorModel> errorModels = new List<ErrorModel>();
					foreach (var item in errors)
					{
						errorModels.Add(new ErrorModel() { ErrorCode = item.Element("errorCode").Value, Error = item.Element("errorMessage").Value });
					}

					responseModel.ResponseCode = "-1";
					responseModel.Response = "failed";
					responseModel.Errors = errorModels;

				}

				var doc = XDocument.Parse(_ccREsponse);
				var _modelJSON = JsonConvert.SerializeXNode(doc).ToString();
				var _model = System.Text.Json.JsonSerializer.Deserialize<ComplaintTrackingRespMainModel>(_modelJSON.ToString());

				responseModel.ResponseCode = "0";
				responseModel.Response = "Success";
				responseModel.Data = _model;
				return responseModel;
			}
			return responseModel;
		}
		public string GenerateRequestId()
		{
			StringBuilder finalRequestId = new StringBuilder();

			var preRequetId = Guid.NewGuid().ToString().Replace("-", "");

			var _day = DateTime.Now.Day.ToString().Length == 1 ? "0" + DateTime.Now.Day.ToString() : DateTime.Now.Day.ToString();
			var _month = DateTime.Now.Month.ToString().Length == 1 ? "0" + DateTime.Now.Month.ToString() : DateTime.Now.Month.ToString();
			var _hour = DateTime.Now.Hour.ToString().Length == 1 ? "0" + DateTime.Now.Hour.ToString() : DateTime.Now.Hour.ToString();
			var _min = DateTime.Now.Minute.ToString().Length == 1 ? "0" + DateTime.Now.Minute.ToString() : DateTime.Now.Minute.ToString();


			finalRequestId.Append(preRequetId.Substring(0, 27));
			finalRequestId.Append(_month);
			finalRequestId.Append(_day);
			finalRequestId.Append(_hour);
			finalRequestId.Append(_min);
			return finalRequestId.ToString();
		}

		public string ProcessRequest(string url, string requestId, string requestdata)
		{
			//DEMO
			//string workingKey = "FE6329515D1DA76CE85A02A0446F220C";
			//Production
			string workingKey = "850C35EFC63147EE4A42A143CEB42304";

			StringBuilder postData = new StringBuilder();
			string responseFromServer = string.Empty;
			string responseFinal = string.Empty;
			//Demo
			//string baseurl = "https://stgapi.billavenue.com/billpay/";  //url; // "https://ybluat.transxt.in/dmtaeps-web/api/1.0/enc/fin/cashWithdrawal";
			//Production
			string baseurl = "https://api.billavenue.com/billpay/";  //url; // "https://ybluat.transxt.in/dmtaeps-web/api/1.0/enc/fin/cashWithdrawal";
			StringBuilder processingURL = new StringBuilder();
			processingURL.Append(baseurl);
			processingURL.Append(url);
			processingURL.Append("?");
			//DEMO
			//processingURL.Append("accessCode=AVBQ01CB03CI32EZFX&");
			//Production
			processingURL.Append("accessCode=AVZA28NQ75BK56VXQQ&");
			processingURL.Append("ver=1.0&");
			//Demo
			//processingURL.Append("instituteId=BT55&");
			//Production
			processingURL.Append("instituteId=AC68&");
			processingURL.Append("requestId=");
			processingURL.Append(requestId); //170F5B6CVCLLTAVTVUY26CHUVbb31591717
			processingURL.Append("&encRequest=");
			processingURL.Append(requestdata);

			CCACrypto ccACrypto = new CCACrypto();

			try
			{
				//Code To send webRequest
				// Create a request using a URL that can receive a post. 
				var request = (HttpWebRequest)WebRequest.Create(processingURL.ToString()); //Request procees on Pay World
				Console.WriteLine(processingURL);
				//Set Header
				request.Headers.Add("Content-Type", "text/plain");
				// Set the Method property of the request to POST.
				request.Method = "POST";
				// Create POST data and convert it to a byte array.
				//postData.Append("encRequest=");
				//postData.Append(requestdata);

				byte[] byteArray = Encoding.UTF8.GetBytes(postData.ToString());

				// Set the ContentType property of the WebRequest.
				//request.ContentType = "application/json"; //charset=utf-8"

				// Set the ContentLength property of the WebRequest.
				request.ContentLength = byteArray.Length;
				// Get the request stream.
				Stream dataStream = request.GetRequestStream();
				// Write the data to the request stream.
				dataStream.Write(byteArray, 0, byteArray.Length);
				// Close the Stream object.
				dataStream.Close();
				// Get the response.
				WebResponse response = request.GetResponse();
				// Display the status.
				//Console.WriteLine(((HttpWebResponse)response).StatusDescription);
				// Get the stream containing content returned by the server.
				dataStream = response.GetResponseStream();
				// Open the stream using a StreamReader for easy access.
				var reader = new StreamReader(dataStream);
				// Read the content.
				responseFromServer = reader.ReadToEnd();
				Console.WriteLine(responseFromServer);
				// Clean up the streams.
				reader.Close();
				dataStream.Close();
				response.Close();
				//End Code To send webRequest
				//Console.WriteLine(responseFromServer);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

			if (!string.IsNullOrEmpty(responseFromServer))
			{
				responseFinal = ccACrypto.Decrypt(responseFromServer, workingKey);
				Console.WriteLine(responseFinal);
			}
			else
			{
				Console.WriteLine("something went wrong while processing with request");
			}

			return responseFinal;
		}

		public string BiilerInfoFetchRequest(string url, string requestId, string requestdata)
		{
			//DEMO
			//string workingKey = "FE6329515D1DA76CE85A02A0446F220C";
			//Production
			string workingKey = "850C35EFC63147EE4A42A143CEB42304";

			StringBuilder postData = new StringBuilder();
			string responseFromServer = string.Empty;
			string responseFinal = string.Empty;
			//Demo
			//string baseurl = "https://stgapi.billavenue.com/billpay/";  //url; // "https://ybluat.transxt.in/dmtaeps-web/api/1.0/enc/fin/cashWithdrawal";
			//Production
			string baseurl = "https://api.billavenue.com/billpay/";  //url; // "https://ybluat.transxt.in/dmtaeps-web/api/1.0/enc/fin/cashWithdrawal";
			StringBuilder processingURL = new StringBuilder();
			processingURL.Append(baseurl);
			processingURL.Append(url);
			processingURL.Append("?");
			//DEMO
			//processingURL.Append("accessCode=AVBQ01CB03CI32EZFX&");
			//Production
			processingURL.Append("accessCode=AVZA28NQ75BK56VXQQ&");
			processingURL.Append("ver=1.0&");
			//Demo
			//processingURL.Append("instituteId=BT55&");
			//Production
			processingURL.Append("instituteId=AC68&");
			processingURL.Append("requestId=");
			processingURL.Append(requestId); //170F5B6CVCLLTAVTVUY26CHUVbb31591717
			

			CCACrypto ccACrypto = new CCACrypto();

			try
			{
				//Code To send webRequest
				// Create a request using a URL that can receive a post. 
				var request = (HttpWebRequest)WebRequest.Create(processingURL.ToString()); //Request procees on Pay World
				Console.WriteLine(processingURL);
				//Set Header
				request.Headers.Add("Content-Type", "text/plain");
				// Set the Method property of the request to POST.
				request.Method = "POST";
				// Create POST data and convert it to a byte array.
				//postData.Append("encRequest=");
				postData.Append(requestdata);

				byte[] byteArray = Encoding.UTF8.GetBytes(postData.ToString());

				// Set the ContentType property of the WebRequest.
				//request.ContentType = "application/json"; //charset=utf-8"

				// Set the ContentLength property of the WebRequest.
				request.ContentLength = byteArray.Length;
				// Get the request stream.
				Stream dataStream = request.GetRequestStream();
				// Write the data to the request stream.
				dataStream.Write(byteArray, 0, byteArray.Length);
				// Close the Stream object.
				dataStream.Close();
				// Get the response.
				WebResponse response = request.GetResponse();
				// Display the status.
				//Console.WriteLine(((HttpWebResponse)response).StatusDescription);
				// Get the stream containing content returned by the server.
				dataStream = response.GetResponseStream();
				// Open the stream using a StreamReader for easy access.
				var reader = new StreamReader(dataStream);
				// Read the content.
				responseFromServer = reader.ReadToEnd();
				Console.WriteLine(responseFromServer);
				// Clean up the streams.
				reader.Close();
				dataStream.Close();
				response.Close();
				//End Code To send webRequest
				//Console.WriteLine(responseFromServer);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

			if (!string.IsNullOrEmpty(responseFromServer))
			{
				//temp code added by swapnal 
				//var tempResponse = "1cffe19d7cc6299826b2f836ddce9afc04d5e934d672090101ad9b83f9e24a5306afd3a7c5fb5d27a6e5e7224ddd81cb8e65ed9e42b539b13418eeda9588a33b3462338dbafda8c09cfbf9a42d50d314ae98d31609ff090e051d14165fbae7a946201ae6371a08194c73b96ebf6ff751ced0361a65e43f0eea4e2eb66eaefa3356a267f8d7a837aacc9c4239c912b75d10ee136f972d349abd33425326582ddc0d64218eb61aee048d90cce66e448e2d1e4a1783681bdad930f981a684c323bb602a6de07c04df2040e2e580af2ba333760188ab273e16ae502163741b137a87fa7365e6b897aea4b2389dd6d97da16bfdbd57d2c7e67152cc13709b4dfb31544dd4e5d53a85a600242b5005b6d2b1c80f08dce2f29e931f60b3dd3109951a3e5981b3997e3a636fee99160cd3d17816538596de0b570a26aadb7b79c4091db9fc05b92822a0f3d51ac18ad66b26908f4719816ef92521d503f7b6dc84335b09311d4a55f1863326d887499fe1ac27a2b93729f851ba671a341b4294b254df4e524779213acf0cadc8aa77a3589c53744253859b501818855d5f9b115e7af3c0d99ca393ffb3dc51c38fe17b8d3917a38192b39f858d8e6e8c23dfe89af513da3840afe3c2dbda51e9bbc70a1dcc123268e75f731d4d4aba29e8e565cae1894a893c27b293e7f450cbdb928399342e29780a70caa341f6403c66d0f643d52ed0da9ebeb05ec3594c18dae7dc50d0e0620b8f04ebe86a9abed34bc469e7451e63b1002d0e15c08691b4ddeb0838b1f2da49c6fd618812b330d661833b9589d25cf916b4fad8af729243452ef7c0fd3ad6295e671fa51fcf985b0c276c9ead2e9f73d783575000cc22ea92f506deaf775c9f4aeb0362555619e0267888b0130e506b3f3e64c1a37823995ca629d601a81abde7b7f3ce88c212decc397763d285b4b37963f2a94fa969c6a3b525b41c89568ca7253a7a8bfea993c7d27155646a84eafbd1e1ac3f7a365278ea7c6ccb729d9be55caaec14046b87528b75f254023cf09476c6c187acffde9c6ab7f309e994f03b33476c28b16ec50a948a037de3c31a65d48aa0c309929b8ddcec1a0ac3ea8cea25410bf988c2a9c95917b8a797b0a266eadbab97920e5b832657f63c0c98d7291276b798f87a547ce423e47d5a1ebc68c96c226bffc3ddc769f6055a393e380facc9365aa3068ac95f936f797b6607ceb0277d792ce028485d81eeae6c98eb204448e5a8c9cc29e1eba99a433acbe398620d9ed838ce8443e90d32c1ea9d0c711200eced248ecb7e5d491cfa35048b0f5082c313e8fae4ec35db49e29c76571162744aa8c87350747e1b55053534e4aa50b2c88de9b5faa0f777b2ded60988204b222fedb64300c44f3d62508d16316e4fd927007b86d832a589f4334bec17a3feb24d632ad27ef47bd429afe1f4aa31f1b0c5fd236fcfc429f4513c53e2f3832b595b2e77711f59fbbc309718fa59992acb54be8e8cccbcf6df8f837f749ed4fad45d31de59c3339b4797aa2f38eb39ff99449dea73910e8e2a00fd982f6cd396df0aba57d9ea83b43b16adbe89d514f42085203aab7afb18776f136653a7fc88730eda226392fdcae4e629b3a919e24115611a1516ec558fa135f9335477af560bc33db98eb066da7f2d95e6637eb1ae5652e4eda275bff11a426ab57901729e776e841d1ef44162f4aac719181c358eb52544a3e4671713fd65648adcbc1c26c02ee8f813b4f57da4574f15e384fecb9702f12e52ef8300c57ad877b3bd105565589d5812ad7abc67a14493703adb5e587bd2e0f344c54d806aedc51a93862f11d6f1de640402414ab1f9ff4530956ef6f1fac2f31407b6c17290e6be0877481fefc285790d93dbba3896c48e5412d431559ebbc764c16330685a95d82059ba6a4ba304b4294e0414998327e857db4192c6f1bea9490fcc2398c517933dcd361f5f1f1d29cd8e10734339c0c3720d7eb7ab4b124de325c2c93b3850ea18ee8f582c92670a9aa1143235541c5b0d0d3506d58238016ab43d793184af1114f703ac249edad4905781676b4cdff52403774af18fa80a1cb59259f397fe42abdd95b948dd0edb5c0c2801bdc5ec1f9a33d6da512b9d7cceff8e8e6cd71462e14f7382d64bcc2f8d6dfd7c1de2fbe7abac1cd57af64f98fd87ff43242b0c80f9531500b73f1b613c14b931324a428f42933ecb8afed449d4596373d6b815b8effb18fd7a80084619a476444d3d036cc397c2b8066ef666c33cb6839d0177b1373688561f482d4d4f2c40df9a96553e10877b7014b735ab431c36ab899424727a3b06c63c844b90af4f7d4fc7a3f59ed64780e71b7aaa8b86fe56789a637a5bf04f01b629917ee5aa2d662024ea75cd899845e8f27e3b37feb2d9e3c7e16da7078f6656ed487a585817c56572021269467e7e13935ed9f3b5e9518dbe39a59386a7758deb8e86355c1419452ae9bafc8500074314f9aeb30317aee00e892fb645e520f4e456728e3fa90eaec6704c5253f6f41d5c17378b54c2697e7849acf0b4591e14133ddb89ce323717816062320b7ab9f29fe2a47827447701bbe1f3d2514424db4053dce09bf37098c81930ff7af14fd0268bea8eadeb18ccfd7201aa3c0ad3bb097c89bec9166717668a6d49dfe600b7da9de61d743f099551a92157ab4183d4348bb6ab2ddb8ee228e60c7965ed27630fa1b50bf8bbd540a4f53a68937bec305c279f15a584225d50c50112050408321661d50932479efffb875c84c7d9aecb27fab5e7167d9a5dc91ee61ca71255fe20f2e0b1fc83ddf12a892c02c9bc8c33b2ee2ffa5d4b17f4949c6e22097739de97e28fa79d3947d8aa71ef162a6f0689f80f932a924a249a22df32759d8fd76b58f83f72a8bdbfed32fca0bac6346f2ea0dc5dd42138401b71feff28f431499b0d22d0bd691f33d503819e924a0f86f2d883ef8a3af5008ae2db5a3534fbf29747553fe8df02591eb0efdc3459851549ab12e8eb4233547213aa83d5a59d67c5acdc1e41cef614661dab42978429f0ce03955ccd661574a14b6afd01935f9c1070bd07865926aaac586d6afbc358818af9c2717e48ed18175d26586b51e2e4fb5549d7516bcce1b3e560b3fc539fb7a0c97c7d72ceae9c20c75ed744fc8114eb2ae41bc4683cd294e45a963c0e93e52d9c46aa68f3caa7919469ff9bb63ce78caa6bd2297409474560306c12b7fbcb484c321510011e70d9a80729ba49c065832e0042b018b7ece3312f97ac262a1fb2613d3df6786408902346c5dd901416fde19a447f80b24bb44df1b0b6c5ed03ba8944f38f5102c339a308ea34ff2129224e1dcefa28c06072a7a9ae3e683d76751de84384709e53ca3c07b812afe602cdcef56289d0dbb33fbacf052a7613e1ffcdc582b72b6453c3a457561f4f6cabcaf8891166b1167f89ad4eef82126c8211d9c7582a75c399f5679334a904e2c7529406ac8e4070b1f1ed74fd5c168c3562a2ccee000d8fb0c8450a33c09818008c09f579a4bf39f44442bd0b8d99a76d7d3ca499c91ca6a75d0ff49a417655d194c18c28dbb044df37566cd46f9c2158c24be4d0d516b5e9ff6acab15ce7c49d5aa5fdf87aab53ef6b53c813c751dedfe8c7aa685a778a81f0920c28eafd06b6e70ef6313c9da5570f856a4fa386fabbf56273f9d2a99f1a107ae66c3ad82fb1ceb4e7c059758a582551425fe0c588a8f35a0b880ceaaa6e8c5b530c38c9e6631c58c0d2720c2b01ec7bbfbb73bb82823b8dd72a9b7b1e3e42f2a9048aa30f7d1f6336e7bff844db23387e9fdd000d5a91ca348cbae667679ffe5fdba7896f093719f02d13646637883d46660ee30552c738a1fbe38ae01c9ec45864a23a6df80288b3ccf37e667699c56fecc1d311e32c094409a73b8710fcdaf622b8048158499bbad90e7c167550ac52a734ea5a5b71325a15abc4b1063cf559bb1f678aef1799e6244475381ae93ff798388ed17bc780459ab4a42119798567e06cfd50561174bc37427be230f8931212c43470c8554a185457d9b64efa8131978a6769d0083257eac53d583cbbe817532586bda6db4f1b197523b56ed752face7fdae1adf157b52e36c9d886d203d75d4c0ae75918c3305789cb495b1d4f6e4cc7662e62748ab68de16774baa8e7b24479b43b46d0bdd3a96077a5fe6b4a184c54c64c108ff613c8fcccbabb939a256fec852f99e6d9863b01711fe1aaed6206f755d35e6edccb45abfd1488f7010d4a2ea3e64f378ff7348dbcf6b2a2af850a89abd429ce6ecf9b0f3ca6a168af9f78ff836f53a2f4bd43743e4ab2978a69d60d1b6690a96be8c243e6be71f6c1b797c7744299c66657462d43ca18a09e60a401779b789a9b3690a8c050093bd8d15c24a454432cda65d5d231f481aeb1186c39959bf87a07987288cec6fbf112231fc3e8231e7a6e9ebca6fce538998c183c821f7cae6777922b85cee3431a555f2dde714d9a1252d09bd6e0f682650ad37971577ce556f98b5e97b2278b226df2da7bca2baba7baab8ab5511dc6c452be01e44631697b7195779906d70cbeddde8d25add1eacbbd52a0f0b7feb62b26fc0605df13ba61505af28009403acd217117d072a0729f71fb5377471c7ad5b0ac7b87002cd4c509d65748faadd316a8f9331794382cd3b03486b29422cdd8091fbd9298433fd5562b37d7e65efa7c556b1dfed68552bd91de22b0d895770e9f0885b1fdef29778d4974914db9f34c7d7307c4c9fd70f67770cdf0e796545f9e50b89df9be69455e054a8c8e54537280a6870abab1f303f18b368eed3438c918c471f47bf170b3f3c46c7464cfcd0a6c5a0ff899e4b9d985c969c7db14922c463a82a345da7df69c4afc3024b1259c4961ced3e605e7461194d2e33bd9d7c6a3867a96dcf7e1e0148e49470f09ec505eaecf6aee582e217012ccc611d616521a07ed7d173522b0dea0672d06341daa3c5193dfd701726f4a834a5fd63555a3dd4d3c646c6fce97554875c5e63d1d2f21ea00d4a3786f2b517bb8fc9df0dd8651a4b21796ead9ec737aed57dcaf0d550ad5fe0216b746702eb255eabcdc6c8a669451f27db61b8a5f4565ad9632c2de72118a0f695104715cb3378a0f12787b03607f2a612cfc6932a7fbaa986af09742d080d0800219a9b04c6a01fda2bbac1fc42d947e826cec13bd7cbd8a83ab1e515abd8fae6cc13a3aaac4a2ac16398ee854f0698bf58b47905298defb7c123ca9c0474fc390533adc336d7976c14d195279c9dc1db65ebe5865e7bc3e7ef23af444234db78f2b3001ce91cba06ae2cb40b37a2754f7ccec6b783c7e00524cb8339f63158f738e29dde6c72b1ce8f136bf5851c2787575d4f52b7bcd66ab22bc06f9e495ffe6f48062c4fd42e947f6030abc09deff97c00c5c53540e443d52e98905a58abe6807ce4834938c7b3fa5e341a0dc9feb13a5b9bfb0e0570d967ec4aa813f5a3bb4dca7d8267ce5fada5e08e351a44b8a1df2807e4030854cc46317ecb5b7a3b78564a5ef97dd535758bff8e9f5d842d6ea816c2ad50db1963ae76029b08b22dcd3220d8c6a5ff72556aa81c9e428e616a46442f703d1fcd58576fa204e74fb3e5a7383e7ae8eebe494f64f44b05325006755c0ee687a56ffd73c4b00d69e603a8ce48dac3460d0c60faca38ad8fdeab2d3b616e3b59386c3ef54a7bd56b43860f9ee1276cb26d69e1c57b15b2a7d428c1cca7d1cae395f3fc4eaa9e86ed8d05bca0c18aa4946ff18fdb468e19a971331e81265d11d758f11adf9525cc1b398998ee14131daccb8c2c35ba2b501ba30b37616563861960704e88ffa213828f72f744af5f39a98d51ba54ae0e5a0ba2ff4897e94c9fe3f7707b3e8df83496206d7f384acd68f4fc2f279a87f89c11049eb5b4c147957e30fba273a01a49a8c722061d64e28886afb7035139ba6976983847e3a32e603d13ae147a96109eb4fa463f6ea9dd9eaecf969dab2879d0b01ce18b4fcb21e997fd52f428dbacdbe5018bc31fa1b6396e3b1717a6b8d901dd357799e8f191faecbb64919215174895c9368b701dca2ad1b112ee35f9776ea264b834c4cdcb015fc4d4a2b2bdcf39f8f3854fa0bb427b77fcceea52a6046be69606ecd13f885670fddd2a0683179a687c3c3bb26d558446a7bddfc8efa7ae92820f9b84be5a45caff21c9bed19c4e2c2112f60fe93908c051055b8d6da34a93095ac29edc1fc33e89a4d223025acbf27b56a342d4bd9a061e4aed20088056bce3e904a31fd100120fb0b674b0056c5d315be7d156dd3feba046bbc51eef3d867961adff04833f65f756bf068c16cd45fa498409ffa362423b6daa80cdbefc9728f1b2ec655c57b7571a82c224b18aa6b79";
				//responseFinal = ccACrypto.Decrypt(tempResponse, workingKey);

				responseFinal = ccACrypto.Decrypt(responseFromServer, workingKey);
				Console.WriteLine(responseFinal);
			}
			else
			{
				Console.WriteLine("something went wrong while processing with request");
			}

			return responseFinal;
		}
	}
}
