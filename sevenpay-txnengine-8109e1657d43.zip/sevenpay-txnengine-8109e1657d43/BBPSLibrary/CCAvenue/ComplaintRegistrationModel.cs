﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class ComplaintRegistrationModel
	{
		public string resfeenceId { get; set; } 
		public string complaintDesc { get; set; } 
		public string complaintDisposition { get; set; }
	}
}
