﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	public class PaymentChannelInfo
	{
		public string paymentChannelName { get; set; }
		public string minAmount { get; set; }
		public string maxAmount { get; set; }
	}
}
