﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	public class Error
	{

		public string errorCode { get; set; }

		public string errorMessage { get; set; }
	}
}
