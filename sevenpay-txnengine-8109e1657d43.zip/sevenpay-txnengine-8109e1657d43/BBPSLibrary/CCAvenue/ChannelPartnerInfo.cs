﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class ChannelPartnerInfo
	{
		public int userId { get; set; }
		public int orgId { get; set; }
		public int distributorId { get; set; }
		public int superdistributorId { get; set; }
	}
}
