﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class ComplaintTrackingRespMainModel
	{
		public Xml xml { get; set; }
		public ComplaintTrackingResp complaintTrackingResp { get; set; }
	}
}
