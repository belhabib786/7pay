﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBPSLibrary.CCAvenue
{
	public class ComplaintTrackingResp
	{
		public string complaintAssigned { get; set; }
		public string complaintId { get; set; }
		public string complaintRemarks { get; set; }
		public string responseCode { get; set; }
		public string responseReason { get; set; }
		public string complaintStatus { get; set; }
	}
}
