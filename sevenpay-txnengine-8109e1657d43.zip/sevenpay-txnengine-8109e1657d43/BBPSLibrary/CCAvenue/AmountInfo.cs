﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BBPSLibrary.CCAvenue
{
	[XmlRoot(ElementName = "amountInfo")]
	public class AmountInfo
	{
		[XmlElement(ElementName = "amount")]
		public string Amount { get; set; }
		[XmlElement(ElementName = "currency")]
		public string Currency { get; set; }
		[XmlElement(ElementName = "custConvFee")]
		public string CustConvFee { get; set; }
		[XmlElement(ElementName = "amountTags")]
		public string AmountTags { get; set; }
	}
}
