﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace AEPSLibrary.PaySprint
{
	public class RegistartionModel
	{
		public string accessmodetype { get; set; } //string APP OR SITE
		public int adhaarnumber { get; set; } //integer XXXXXXXX1234
		public int mobilenumber { get; set; } //   integer	9900000099
		public double latitude { get; set; } //decimal (2,7)	22.44543
		public double longitude { get; set; } //decimal (2,7)	77.434
		public string referenceno { get; set; } //string	43542343434(unique txn value)
		public string submerchantid { get; set; } //alphanumeric    Merchant code
		public DateTime timestamp { get; set; } //datetime    Timestamp of the request.(Y-m-d H:i:s )
		
		[XmlText]
		public string data { get; set; } //XML Device Data XML
		public string ipaddress { get; set; } //  string	9.9.9.9
}
}
