﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.PaySprint
{
	public class AgentOnboardingResponseModel
	{
		public bool status { get; set; }
		public int response_code { get; set; }
		public string redirecturl { get; set; }
		public int onboard_pending { get; set; }
		public string message { get; set; }
	}
}
