﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.PaySprint
{
	public class AgentRegistrationRequestModel
	{
		public string accessmodetype { get; set; } // string APP OR SITE
		public long adhaarnumber { get; set; } // integer XXXXXXXX1234
		public long mobilenumber { get; set; } //    integer	9900000099
		public double latitude { get; set; } // decimal (2,7)	22.44543
		public double longitude { get; set; } // decimal (2,7)	77.434
		public string referenceno { get; set; } // string	43542343434(unique txn value)
		public string submerchantid { get; set; } // alphanumeric    Merchant code
		public string timestamp { get; set; } // datetime    Timestamp of the request.(Y-m-d H:i:s )
		public string data { get; set; } //XML Device Data XML
		public string ipaddress { get; set; } //   string	9.9.9.9
	}
}
