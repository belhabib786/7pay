﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.PaySprint
{
	public class WithdrawalResponseModel
	{
		public bool status { get; set; }
		public string message { get; set; }
		public int ackno { get; set; }
		public string amount { get; set; }
		public string balanceamount { get; set; }
		public long bankrrn { get; set; }
		public int bankiin { get; set; }
		public int response_code { get; set; }
		public string errorcode { get; set; }
		public string clientrefno { get; set; }
	}
}
