﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.PaySprint
{
	public class WithdrawThreeWayReconRequestModel
	{
		public string reference { get; set; }
		public string status { get; set; }
	}
}
