﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.PaySprint
{
	public class OnboardingCallbackMainResponseModel
	{
		//public OnboardingCallbackResponseModel? param { get; set; }
		//public string param { get; set; }

		public string? @event { get; set; }
		public Param? param { get; set; }
		public string? param_enc { get; set; }
	}
}
