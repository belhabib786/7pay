﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.PaySprint
{
	public static class GenerateAuthToken
	{
		// Demo
		// Define const Key this should be private secret key  stored in some safe place
		private static string key = "UFMwMDE0MjEwNGJhZWE1NDZhNWFjMWE1ZWY0YmQ2ZDU1MmQ2ODgxZA==";
		private static string partnerId = "PS001421";

		public static string GetToken()
		{

			// Create Security key  using private key above:
			// not that latest version of JWT using Microsoft namespace instead of System
			var securityKey = new Microsoft
			   .IdentityModel.Tokens.SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));

			// Also note that securityKey length should be >256b
			// so you have to make sure that your private key has a proper length
			//
			var credentials = new Microsoft.IdentityModel.Tokens.SigningCredentials
							  (securityKey, "HS256");

			//  Finally create a Token
			var header = new JwtHeader(credentials);

			//Some PayLoad that contain information about the  customer
			var payload = new JwtPayload
			{
				{"timestamp", DateTimeOffset.Now.ToUnixTimeMilliseconds()},
				{"partnerId", partnerId },
				{"reqid", Guid.NewGuid().ToString()},
			};

			//
			var secToken = new JwtSecurityToken(header, payload);
			var handler = new JwtSecurityTokenHandler();

			// Token to String so you can use it in your client
			var tokenString = handler.WriteToken(secToken);

			Console.WriteLine(tokenString);

			return tokenString;
		}
	}
}
