﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.PaySprint
{
	public class AgentRegistrationResponseModel
	{
		public int response_code { get; set; } // ": 1,
		public bool status { get; set; } //": true,
		public string message { get; set; } //": "AEPS Aadhaar Registration Success",
		public string errorcode { get; set; } //": "0"
	}
}
