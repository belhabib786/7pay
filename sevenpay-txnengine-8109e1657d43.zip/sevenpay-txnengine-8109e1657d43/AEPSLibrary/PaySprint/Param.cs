﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.PaySprint
{
	public class Param
	{
		public string? merchant_id { get; set; }
		public string? partner_id { get; set; }
		public string? request_id { get; set; }
		public int? amount { get; set; }
	}
}
