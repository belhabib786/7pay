﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.PaySprint
{
	public class AgentOnboardingRequestModel
	{
		public string merchantcode { get; set; }
		public string mobile { get; set; }
		public string is_new { get; set; }
		public string email { get; set; }
		public string firm { get; set; }
		public string callback { get; set; }
	}
}
