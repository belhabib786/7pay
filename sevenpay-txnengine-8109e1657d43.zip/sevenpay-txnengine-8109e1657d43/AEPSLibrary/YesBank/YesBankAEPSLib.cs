﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.YesBank
{
	public class YesBankAEPSLib
	{
		//public string sha256Hash(string data)
		//{
		//    var byteArray = Encoding.UTF8.GetBytes("hello");
		//    var sha = SHA256.Create();
		//    byte[] outputBytes = sha.ComputeHash(byteArray);
		//    var result = BitConverter.ToString(outputBytes).Replace("-", "").ToLower();
		//}

		//txnld+ partnerld+ agentld+ channel+ customerMob
		public string GetHashCode(string txnld, string partnerld, string agentld, string channel, string customerMob)
		{
			var _hashKey = txnld + partnerld + agentld + channel + customerMob;
			return GetEncryptedHashKeyString(_hashKey);
		}

		public string GetMD5HashData(string data)
		{
			//create new instance of md5
			MD5 md5 = MD5.Create();

			//convert the input text to array of bytes
			byte[] hashData = md5.ComputeHash(Encoding.UTF8.GetBytes(data));

			//create new instance of StringBuilder to save hashed data
			StringBuilder returnValue = new StringBuilder();

			//loop for each byte and add it to StringBuilder
			for (int i = 0; i < hashData.Length; i++)
			{
				returnValue.Append(hashData[i].ToString());
			}

			// return hexadecimal string
			return returnValue.ToString();

		}

		public string GetEncryptedHashKeyString(string hashKey)
		{
			StringBuilder sb = new StringBuilder();
			//100119175848 3909 MAX1764147 1 8452978969
			//string text = "1001191758483909MAX176414718452978969";

			MD5 md5 = new MD5CryptoServiceProvider();

			//compute hash from the bytes of text 
			md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(hashKey));

			//get hash result after compute it 
			byte[] result = md5.Hash;

			StringBuilder strBuilder = new StringBuilder();

			for (int i = 0; i < result.Length; i++)
			{
				//change it into 2 hexadecimal digits 
				//for each byte 
				strBuilder.Append(result[i].ToString("x2"));
			}
			Console.WriteLine(strBuilder.ToString());
			return strBuilder.ToString();
		}

		public string GetAuthEncryptedString(string plainText)
		{
			//string text = "3909";

			//public key
			string AesKey256 = "a11b4f86cf186d127caa05db929d6f41"; //

			byte[] strBytes = Encoding.UTF8.GetBytes(AesKey256);

			SHA256 sha2 = new SHA256CryptoServiceProvider();
			byte[] digestOfPassword = sha2.ComputeHash(strBytes);

			Console.WriteLine("DigestofPassword - " + Convert.ToBase64String(digestOfPassword));


			byte[] Key = new byte[24];
			byte[] IV = new byte[16];

			Array.Copy(digestOfPassword, Key, 24);
			Array.Copy(digestOfPassword, IV, 16);

			Console.WriteLine("Key - " + Convert.ToBase64String(Key));
			Console.WriteLine("IV - " + Convert.ToBase64String(IV));

			// AesCryptoServiceProvider
			AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
			aes.BlockSize = 128;
			aes.KeySize = 256;
			aes.IV = IV;
			aes.Key = Key;
			aes.Mode = CipherMode.CBC;
			aes.Padding = PaddingMode.PKCS7;

			// Convert string to byte array
			byte[] src = Encoding.UTF8.GetBytes(plainText);

			// encryption
			using (ICryptoTransform encrypt = aes.CreateEncryptor())
			{
				byte[] dest = encrypt.TransformFinalBlock(src, 0, src.Length);

				// Convert byte array to Base64 strings
				Console.WriteLine(Convert.ToBase64String(dest));

				var response = Convert.ToBase64String(dest);

				return Convert.ToBase64String(dest);
			}
		}

		public string GetEntireEncryptedRequestString(string plainText)
		{
			//string text = "3909";

			//private key
			string AesKey256 = "607a9fda353a0cc03d468402de68ac90"; //

			byte[] strBytes = Encoding.UTF8.GetBytes(AesKey256);

			SHA256 sha2 = new SHA256CryptoServiceProvider();
			byte[] digestOfPassword = sha2.ComputeHash(strBytes);

			Console.WriteLine("DigestofPassword - " + Convert.ToBase64String(digestOfPassword));


			byte[] Key = new byte[24];
			byte[] IV = new byte[16];

			Array.Copy(digestOfPassword, Key, 24);
			Array.Copy(digestOfPassword, IV, 16);

			Console.WriteLine("Key - " + Convert.ToBase64String(Key));
			Console.WriteLine("IV - " + Convert.ToBase64String(IV));

			// AesCryptoServiceProvider
			AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
			aes.BlockSize = 128;
			aes.KeySize = 256;
			aes.IV = IV;
			aes.Key = Key;
			aes.Mode = CipherMode.CBC;
			aes.Padding = PaddingMode.PKCS7;

			// Convert string to byte array
			byte[] src = Encoding.UTF8.GetBytes(plainText);

			// encryption
			using (ICryptoTransform encrypt = aes.CreateEncryptor())
			{
				byte[] dest = encrypt.TransformFinalBlock(src, 0, src.Length);

				// Convert byte array to Base64 strings
				Console.WriteLine(Convert.ToBase64String(dest));

				var response = Convert.ToBase64String(dest);

				return Convert.ToBase64String(dest);
			}
		}

		public string GetEntireDecryptedRequestString(string plainText)
		{
			//string text = "3909";

			string response = string.Empty;

			if (plainText.Contains("Error"))
				return plainText;
			else
				response = plainText.Substring(10, plainText.Length - 12);

			//private key
			string AesKey256 = "607a9fda353a0cc03d468402de68ac90"; //

			byte[] strBytes = Encoding.UTF8.GetBytes(AesKey256);

			SHA256 sha2 = new SHA256CryptoServiceProvider();
			byte[] digestOfPassword = sha2.ComputeHash(strBytes);

			Console.WriteLine("DigestofPassword - " + Convert.ToBase64String(digestOfPassword));


			byte[] Key = new byte[24];
			byte[] IV = new byte[16];

			Array.Copy(digestOfPassword, Key, 24);
			Array.Copy(digestOfPassword, IV, 16);

			Console.WriteLine("Key - " + Convert.ToBase64String(Key));
			Console.WriteLine("IV - " + Convert.ToBase64String(IV));

			// AesCryptoServiceProvider
			AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
			aes.BlockSize = 128;
			aes.KeySize = 256;
			aes.IV = IV;
			aes.Key = Key;
			aes.Mode = CipherMode.CBC;
			aes.Padding = PaddingMode.PKCS7;

			// Convert string to byte array
			byte[] src = Convert.FromBase64String(response);
			//byte[] src = Encoding.ASCII.GetBytes(plainText);

			// decryption
			// Create a decryptor to perform the stream transform.
			ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

			// Create the streams used for decryption.
			using (MemoryStream msDecrypt = new MemoryStream(src))
			{
				using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
				{
					using (StreamReader srDecrypt = new StreamReader(csDecrypt))
					{

						// Read the decrypted bytes from the decrypting stream
						// and place them in a string.
						response = srDecrypt.ReadToEnd();
					}
				}
			}

			return response;
		}

		public string ProcessRequest(string url, string requestdata)
		{
			StringBuilder postData = new StringBuilder();
			string responseFromServer = string.Empty;
			string responseFinal = string.Empty;
			string baseurl = url; // "https://ybluat.transxt.in/dmtaeps-web/api/1.0/enc/fin/cashWithdrawal";
			YesBankAEPSLib yesBankAEPSLib1 = new YesBankAEPSLib();

			try
			{
				//Code To send webRequest
				// Create a request using a URL that can receive a post. 
				var request = (HttpWebRequest)WebRequest.Create(baseurl); //Request procees on Pay World
				Console.WriteLine(baseurl);
				//Set Header
				request.Headers.Add("Auth", "lnnT2faYCRQj8D//qg1zZA==");
				request.Headers.Add("Content-Type", "application/json");
				// Set the Method property of the request to POST.
				request.Method = "POST";
				// Create POST data and convert it to a byte array.
				postData.Append("{ \"eReq\":\"");
				postData.Append(requestdata);
				postData.Append("\"}");
				byte[] byteArray = Encoding.UTF8.GetBytes(postData.ToString());

				// Set the ContentType property of the WebRequest.
				request.ContentType = "application/json"; //charset=utf-8"

				// Set the ContentLength property of the WebRequest.
				request.ContentLength = byteArray.Length;
				// Get the request stream.
				Stream dataStream = request.GetRequestStream();
				// Write the data to the request stream.
				dataStream.Write(byteArray, 0, byteArray.Length);
				// Close the Stream object.
				dataStream.Close();
				// Get the response.
				WebResponse response = request.GetResponse();
				// Display the status.
				//Console.WriteLine(((HttpWebResponse)response).StatusDescription);
				// Get the stream containing content returned by the server.
				dataStream = response.GetResponseStream();
				// Open the stream using a StreamReader for easy access.
				var reader = new StreamReader(dataStream);
				// Read the content.
				responseFromServer = reader.ReadToEnd();
				// Clean up the streams.
				reader.Close();
				dataStream.Close();
				response.Close();
				//End Code To send webRequest
				//Console.WriteLine(responseFromServer);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

			if (!string.IsNullOrEmpty(responseFromServer))
			{
				responseFinal = yesBankAEPSLib1.GetEntireDecryptedRequestString(responseFromServer);
				Console.WriteLine(responseFinal);
			}
			else
			{
				Console.WriteLine("something went wrong while processing with request");
			}

			return responseFinal;
		}

	}
}
