﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.YesBank
{
	public class YesBankBalanceCheckResponseModel
	{
		public string balance { get; set; }
		public string sorTxnId { get; set; }
		public string txnRespCode { get; set; }
		public string referenceNo { get; set; }
		public string transactionStatus { get; set; }
		public string txnErrorMsg { get; set; }
		public string hmac { get; set; }
		public string txnErrorCode { get; set; }
		public string transactionDate { get; set; }
		public string aadharNo { get; set; }
		public string sysTraceNo { get; set; }
	}
}
