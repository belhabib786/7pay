﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.YesBank
{
	public class YesBankAEPSResponse<T>
	{
		public string responseCode { get; set; }
		public string responseMsg { get; set; }
		public string txnId { get; set; }
		public T data { get; set; }
		public List<YesBankAEPSErrorResponse> errorResponse { get; set; }
	}
}
