﻿using CommonLibrary;
using Mapster;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.YesBank
{
	public class YesBankTransaction : IAEPSTransaction
	{
		public string Authentication(dynamic AuthenticationModel)
		{
			throw new NotImplementedException();
		}

		public string BalanceCheck(dynamic balanceCheckModel)
		{
			ResponseModel responseModel = new ResponseModel();
			YesBankAEPSLib yesBankAEPSLib = new YesBankAEPSLib();
			
			YesBankBalanceCheckModel request = System.Text.Json.JsonSerializer.Deserialize<YesBankBalanceCheckModel>(balanceCheckModel);
			//code for pid data
			var _pidData = System.Text.Json.JsonSerializer.Deserialize<Object>(request.biometricData).ToString();
			var yesBankBalanceCheckModel = request.Adapt<YesBankBalanceCheckModel>();
			yesBankBalanceCheckModel.biometricData = _pidData;
			//code for haskey
			//txnld+ partnerld+ agentld+ channel+ customerMob
			var _haskkey = request.txnId + request.partnerId + request.agentId + request.channel + request.customerMob;
			var _hashkeyEnc = yesBankAEPSLib.GetEncryptedHashKeyString(_haskkey);
			yesBankBalanceCheckModel.hashKey = _hashkeyEnc;
			var _jsonData = JsonConvert.SerializeObject(yesBankBalanceCheckModel);
			var requestData = yesBankAEPSLib.GetEntireEncryptedRequestString(_jsonData);
			var response = yesBankAEPSLib.ProcessRequest("https://ybluat.transxt.in/dmtaeps-web/api/1.0/enc/nonfin/balanceEnquiry", requestData);

			if (!string.IsNullOrEmpty(response))
			{
				var _response = System.Text.Json.JsonSerializer.Deserialize<YesBankAEPSResponse<YesBankBalanceCheckResponseModel>>(response);
				if (_response.responseCode != "00")
				{
					responseModel.ResponseCode = _response.responseCode;
					responseModel.Response = _response.errorResponse[0].errorMsg;
					responseModel.Data = null;
				}
				else
				{
					responseModel.ResponseCode = _response.responseCode;
					responseModel.Response = _response.responseMsg;
					responseModel.Data = new CommonBalanceCheckResponseModel { balance = _response.data.balance}; // System.Text.Json.JsonSerializer.Deserialize<Object>(data);
				}
				return System.Text.Json.JsonSerializer.Serialize(responseModel);
			}
			return response;  //response;
		}

		public string CashWithdrawal(dynamic cashWithdrawalModel)
		{
			ResponseModel responseModel = new ResponseModel();
			YesBankAEPSLib yesBankAEPSLib = new YesBankAEPSLib();

			YesBankCashWithdrawalModel request = System.Text.Json.JsonSerializer.Deserialize<YesBankCashWithdrawalModel>(cashWithdrawalModel);
			//code for pid data
			var _pidData = System.Text.Json.JsonSerializer.Deserialize<Object>(request.biometricData).ToString();
			var yesBankCashWithdrawalModel = request.Adapt<YesBankCashWithdrawalModel>();
			yesBankCashWithdrawalModel.biometricData = _pidData;
			//code for haskey
			//txnld+ partnerld+ agentld+ channel+ customerMob
			var _haskkey = request.txnId + request.partnerId + request.agentId + request.channel + request.customerMob;
			var _hashkeyEnc = yesBankAEPSLib.GetEncryptedHashKeyString(_haskkey);
			yesBankCashWithdrawalModel.hashKey = _hashkeyEnc;
			var _jsonData = JsonConvert.SerializeObject(yesBankCashWithdrawalModel);
			var requestData = yesBankAEPSLib.GetEntireEncryptedRequestString(_jsonData);
			var response = yesBankAEPSLib.ProcessRequest("https://ybluat.transxt.in/dmtaeps-web/api/1.0/enc/fin/cashWithdrawal", requestData);


			if (!string.IsNullOrEmpty(response))
			{
				var _response = System.Text.Json.JsonSerializer.Deserialize<YesBankAEPSResponse<YesBankMiniStatementResponseModel>>(response);
				if (_response.responseCode != "00")
				{
					responseModel.ResponseCode = _response.responseCode;
					responseModel.Response = _response.errorResponse[0].errorMsg;
					responseModel.Data = null;
				}
				else
				{
					responseModel.ResponseCode = _response.responseCode;
					responseModel.Response = _response.responseMsg;
					responseModel.Data = _response.data;
				}
				return System.Text.Json.JsonSerializer.Serialize(responseModel);
			}
			return response;
		}

		public string GetMiniStatement(dynamic miniStatementModel)
		{
			ResponseModel responseModel = new ResponseModel();
			YesBankAEPSLib yesBankAEPSLib = new YesBankAEPSLib();
			
			YesBankMiniStatementModel request = System.Text.Json.JsonSerializer.Deserialize<YesBankMiniStatementModel>(miniStatementModel);
			//code for pid data
			var _pidData = System.Text.Json.JsonSerializer.Deserialize<Object>(request.biometricData).ToString();
			var yesBankMiniStatementModel = request.Adapt<YesBankMiniStatementModel>();
			yesBankMiniStatementModel.biometricData = _pidData;
			//code for haskey
			//txnld+ partnerld+ agentld+ channel+ customerMob
			var _haskkey = request.txnId + request.partnerId + request.agentId + request.channel + request.customerMob;
			var _hashkeyEnc = yesBankAEPSLib.GetEncryptedHashKeyString(_haskkey);
			yesBankMiniStatementModel.hashKey = _hashkeyEnc;
			var _jsonData = JsonConvert.SerializeObject(yesBankMiniStatementModel);
			var requestData = yesBankAEPSLib.GetEntireEncryptedRequestString(_jsonData);
			var response = yesBankAEPSLib.ProcessRequest("https://ybluat.transxt.in/dmtaeps-web/api/1.0/enc/nonfin/ministatement", requestData);


			if (!string.IsNullOrEmpty(response))
			{
				var _response = System.Text.Json.JsonSerializer.Deserialize<YesBankAEPSResponse<YesBankMiniStatementResponseModel>>(response);
				if (_response.responseCode != "00")
				{
					responseModel.ResponseCode = _response.responseCode;
					responseModel.Response = _response.errorResponse[0].errorMsg;
					responseModel.Data = null;
				}
				else
				{
					responseModel.ResponseCode = _response.responseCode;
					responseModel.Response = _response.responseMsg;
					responseModel.Data = _response.data.miniStatement;
				}
				return System.Text.Json.JsonSerializer.Serialize(responseModel);
			}
			return response;
		}

		public string Registration(dynamic RegistrationModel)
		{
			throw new NotImplementedException();
		}

		public string StatusCheck(dynamic StatusCheckModel)
		{
			throw new NotImplementedException();
		}

		public string Onboarding(dynamic OnboardingModel)
		{
			throw new NotImplementedException();
		}

		public string WithdrawThreeWayRecon(dynamic WithdrawThreeWayReconModel)
		{
			throw new NotImplementedException();
		}
	}
}
