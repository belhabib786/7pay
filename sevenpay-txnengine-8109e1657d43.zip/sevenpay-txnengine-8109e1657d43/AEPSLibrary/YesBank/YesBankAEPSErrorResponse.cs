﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSLibrary.YesBank
{
	public class YesBankAEPSErrorResponse
	{
		public string errorCode { get; set; }
		public string errorMsg { get; set; }
		public List<string> fieldName { get; set; }
	}
}
