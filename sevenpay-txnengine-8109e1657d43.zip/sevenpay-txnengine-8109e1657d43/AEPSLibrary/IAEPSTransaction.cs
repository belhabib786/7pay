﻿namespace AEPSLibrary
{
	public interface IAEPSTransaction
	{
		string Onboarding(dynamic OnboardingModel);
		string Registration(dynamic RegistrationModel);
		string Authentication(dynamic AuthenticationModel);
		string BalanceCheck(dynamic BalanceCheckModel);
		string GetMiniStatement(dynamic MiniStatementModel);
		string CashWithdrawal(dynamic CashWithdrawalModel);
		string StatusCheck(dynamic StatusCheckModel);
		string WithdrawThreeWayRecon(dynamic WithdrawThreeWayReconModel);
	}
}