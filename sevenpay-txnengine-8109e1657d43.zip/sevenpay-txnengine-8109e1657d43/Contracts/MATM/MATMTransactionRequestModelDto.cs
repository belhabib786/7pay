﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.MATM
{
    public class MATMTransactionRequestModelDto
    {
        public Int16 p_intmatmtxnid { get; set; }
        public Int16 p_intorgid { get; set; }
        public Int16 p_intserviceid { get; set; }
        public Int16 p_intsupplierid { get; set; }
        public Int16 p_intservproviderid { get; set; }
        public double p_dectxnvalue { get; set; }
        public string p_strbluetoothname { get; set; }
        public string p_strimeno { get; set; }
        public string p_strcustomerref1 { get; set; }
        public string p_strcustomerref2 { get; set; }
        public string p_strcustomerref3 { get; set; }
        public string p_strgeotag { get; set; }
        public Int32 p_intuserid { get; set; }
        public Int16 p_inttxnstatus { get; set; }
        public Int16 p_intcreator { get; set; }
        public Int16 p_intdistributorid { get; set; }
        public string p_strmerchantkey { get; set; }
        public string p_strip_address { get; set; }
        public Int16 p_txntype { get; set; }

    }
}
