﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.DMT
{
    public class ValidateReceiverAccountDto
    {
        public string ifsccode { get; set; }
        public string accounntnumber { get; set; } 
        public long senderid {get; set; }
    }
}
