﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.DMT
{
    public class DMTTransactionSlabModel
    {
        public double slab { get; set; }
        public double transactionfee1 { get; set; }
    }
}
