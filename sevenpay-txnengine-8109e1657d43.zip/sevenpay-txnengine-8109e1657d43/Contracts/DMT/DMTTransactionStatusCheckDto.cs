﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.DMT
{
    public class DMTTransactionStatusCheckDto
    {
        public int ResponseCode { get; set; }
        public string MessageString { get; set; }
        public string DisplayMessage { get; set; }
        public string RequestID { get; set; }
        public string ClientUniqueID { get; set; }
        public string ResponseData { get; set; }
    }
}
