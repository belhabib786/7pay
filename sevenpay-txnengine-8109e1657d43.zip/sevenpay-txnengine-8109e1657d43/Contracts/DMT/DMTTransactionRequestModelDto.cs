﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.DMT
{
    public class DMTTransactionRequestModelDto
    {
        public string p_transactiondate { get; set; } // date,
        public long p_retailerid { get; set; } // bigint, 
        public long p_serviceid { get; set; } // bigint,
        public long p_supplierid { get; set; } // bigint, 
        public long p_serviceproviderid { get; set; } // bigint,
        public double p_transactionvalue { get; set; } // numeric, 
        public double p_suppliertransactionvalue { get; set; } // numeric,
        public double p_servicecharge { get; set; } // numeric, 
        public double p_markup { get; set; } // numeric,
        public int p_transactionmode { get; set; } // integer, 
        public int p_transactiontype { get; set; } // integer,
        public string p_transactionnumber { get; set; } // character varying,
        public double p_transactionfee { get; set; } // numeric, 
        public string p_ip_address { get; set; } // character varying,
        public int p_userid { get; set; } // integer,
        public string p_customerref1 { get; set; } // character varying,
        public string p_customerref2 { get; set; } // character varying,
        public string p_customerref3 { get; set; } // character varying,
        public long p_orgtxnid { get; set; } // bigint, 
        public string p_custmobno { get; set; } // character varying, 
        public string p_comments { get; set; } // character varying, 
        public string p_imei { get; set; } // character varying

        //the parameter added by swapnal
        public string p_customername { get; set; }
        public string p_beneifsccode { get; set; }
        public string p_beneaccountno  { get; set; }
        public string p_benname  { get; set; }
    }
}
