﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Errors
{
    public class ErrorCodeEnum
    {
        public enum CommonErrorEnum
        {
            ContactToAdmin = 1001,
            NoInformationFound = 1002,
            DuplicateTransaction = 1003,
        }
        public enum UserManagementErrorEnum
        {
            UserIsInActive = 2001,
            UserIsIsLocked = 2002,
            InvalidUserNamePassword = 2003,
            UserIsDeleted = 2004,
            UserNotFound = 2005,
            UserAlreadyExist = 2006,
            FirstTimeLoginUserNeedToChangeThePassword = 2007,
            UserNeedToChangeThePassword = 2008,
            RecentlyUsedPasword = 2009,
            UnableToFetchWalletBalance = 2010,
            UnableToFetchUserProfile = 2011,
            NoSubUserFound = 2012,
            SomethingWentWrongWhileUpdatingToken = 2013,
            InValidStatus = 2014,
            FacingIssueInFatchingOnboarding = 2015,
            SomeOnboardingDetailsHaveFailed = 2016,
            SomeOnboardingDetailsArePending = 2017,
			SomeOnboardingKYCsArePending = 2018,
			UserBlockedPermanently = 2019
		}

        public enum SettlementBankErrorEnum
        {
            UnableToAddSettlementBank = 3001,
            UnableToFetchSettlementBank = 3002,
            InformationNotFound = 3003,
            SettlementBankVerificationSuccess = 3004,
            SettlementBankStatusChangesSuccess = 3005,
            AlreadyAddedEnableBanks = 3006,
            NewSettleBankAddedAndSetAsPrimaryBank = 3007,
            NewSettleBankAdded = 3008
        }

        public enum LocationErrorEnum
        {
            NoCountryFound = 4001,
            NostateFound = 4002,
            NoCityFound = 4003,
            NoLocationFound = 4004
        }

        public enum TransactionErrorEnum
        {
            NoTelecomServiceProviderFound = 5001,
            NoDthServiceProviderFound = 5002,
            UnableToFetchSenderInformation = 5003,
            SenderOTPGeneratedForVerification = 5004,
            SenderAlreadyExistsVerificationPendingOtpGenerated = 5005,
            UnableToProcessSenderInformation = 5006,
            UnableToFetchBankInformation = 5007,
            UnableToFetchBankInformationTryanotherIFSCCode = 5008,
            TheReceiverInformationAddedSuccessfully = 5009,
            SomethingWentWrongWhileAddingReceiver = 5010,
            NoReceiverFoundPleaseAddOneToContinue = 5011,
            SenderAlreadyExists = 5012,
            TheSenderVerificationOTPVerificationSuccessfullyDone = 5013,
            SomethingWentWrongWhileSenderOTPVerification = 5014,
            UnableToFoundSenderInformation = 5015,
            TheProvidedOTPisNotValid = 5016,
            TheReceiverAccountInformationNotFound = 5017,
            ServiceChargesInformationIsNotFound = 5018,
            SomethingWrongWhileProcessingTransaction = 5019,
            ReceiverRegistrationOTPFailed = 5020,
			ReceiverCountExceeded = 5021,
			ReceiverDuplicateInformation = 5021,
            TransactionInformationNotFound = 5022
		}
        public enum AEPSErrorEnum
        {
            SupplierIsInActive = 6001,
            SupplierIsDeleted = 6002,
            SupplierNotFound = 6003,
            SupplierAlreadyExist = 6004,
            ProblemFromServiceProvider = 6005,
            ErrorResponseFromServiceProvider = 6006,
        }

        public enum PaymentErrorEnum
        {
            NoPaymentModeFound = 7001,
            NoVPAFound = 7002,
            SomethingWentWrongWhileUpdatingVPA = 7003,
            NoPaymentIdFound = 7004,
            NoBanksFound = 7005,
        }
        public enum CpOnBoardErrorEnum
        {
            CpOnBoardIsInActive = 6001,
            CpOnBoardIsDeleted = 6002,
            CpOnBoardNotFound = 6003,
            CpOnBoardAlreadyExist = 6004,

        }
        public enum reportsErrorEnum
        {
            Reportnotfound = 9001

        }
		public enum BBPSErrorEnum
		{
			BBPSAegentNotFound = 9002,
			SupplierPriorityNotFound = 9003,
		}
      

        public enum MATMErrorEnum
        {
            Datanotfound = 10001

        }
        public enum IDType
        {
            Pan = 1,
            Aadhar = 2,
            DrivingLicence = 3,
            VotorID = 4,
            Passport = 5,
            Bank = 6
        }
        public enum TxnStatus
        {
            Pending = 1,
            Success = 2,
            Failed = 3,
            Rejected = 4,
            Reversed = 5,
            MarkforRefund = 6,
            Refunded = 7,
            PartCancellation = 8
        }
        public enum ActiveInActive
        {
            Valid = 2,
            InValid = 1
        }
        public enum OTPErrorCodeEnum
        {
            OTPExpire = 4001,
            InValidOTP = 4002,
        }
    }
}
