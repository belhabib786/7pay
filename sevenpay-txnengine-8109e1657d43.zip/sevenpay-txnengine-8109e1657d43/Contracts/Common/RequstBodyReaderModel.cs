﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Common
{
	public class RequstBodyReaderModel
	{
		public string? HttpVerb { get; set; }
		public string? RequestPath { get; set; }
		public string? RequestRawData { get; set; }
		public string? Message { get; set; }
	}
}
