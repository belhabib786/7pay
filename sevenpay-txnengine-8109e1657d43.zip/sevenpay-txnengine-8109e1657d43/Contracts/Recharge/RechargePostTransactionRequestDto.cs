﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Recharge
{
    public class RechargePostTransactionRequestDto
    {
        /*
         * p_remarks		    text	IN	5	[NULL]
                p_sprefno		    varchar	IN	6	[NULL]
                p_supptxnnumber		varchar	IN	3	[NULL]
                p_txnid			    int8	IN	1	[NULL]
                p_txnstatus		    int4	IN	2	[NULL]
                p_userid		    int8	IN	4	[NULL]
         */
        public long p_userid { get; set; } //  bigint,
        public int p_txnstatus { get; set; } //  integer, 
        public long p_txnid { get; set; } // bigint,
        public string p_supptxnnumber { get; set; } //  character varying, 
        public string p_sprefno { get; set; } //  character varying, 
        public string p_remarks { get; set; } //  text,  
        public string p_ipaddresss { get; set; } //  character varying
    }
}
