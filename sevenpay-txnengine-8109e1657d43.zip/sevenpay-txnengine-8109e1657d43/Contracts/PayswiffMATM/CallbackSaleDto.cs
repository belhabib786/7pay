﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.PayswiffMATM
{
	public class CallbackSaleDto
	{
		public string amount { get; set; }
		public string authCode { get; set; }
		public string cardCountryCode { get; set; }
		public string cardHolderName { get; set; }
		public string cardNumber { get; set; }
		public string cardType { get; set; }
		public string chargeSlip { get; set; }
		public int emiTenure { get; set; }
		public string gatewayResponseCode { get; set; }
		public string gatewayResponseMessage { get; set; }
		public bool isPinVerified { get; set; }
		public string merchantBusinessName { get; set; }
		public int merchantId { get; set; }
		public string merchantMobileNumber { get; set; }
		public string merchantReferenceNumber { get; set; }
		public string merchantUserName { get; set; }
		public string paymentBrand { get; set; }
		public string paymentInstrument { get; set; }
		public string paymentMode { get; set; }
		public int paymentNum { get; set; }
		public string paymentType { get; set; }
		public string rrn { get; set; }
		public string secureHash { get; set; }
		public int terminalId { get; set; }
		public string terminalSerial { get; set; }
		public int transactionNum { get; set; }
		public string transactionStatus { get; set; }
		public string transactionType { get; set; }
		public string transcationDate { get; set; }
		public string txnCurrencyCode { get; set; }
	}
}
