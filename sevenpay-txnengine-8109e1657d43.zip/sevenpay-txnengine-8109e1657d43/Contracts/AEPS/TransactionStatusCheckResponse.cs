﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPS
{
    public class TransactionStatusCheckResponse
    {
        public bool status { get; set; }
        public string txnstatus { get; set; }
        public string message { get; set; }
        public string ackno { get; set; }
        public string amount { get; set; }
        public string bankrrn { get; set; }
        public int response_code { get; set; }
    }
}
