﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPS
{
    public class MiniStatementesponse
    {
        public bool status { get; set; }
        public int ackno { get; set; }
        public string datetime { get; set; }
        public string balanceamount { get; set; }
        public long bankrrn { get; set; }
        public string bankiin { get; set; }
        public string message { get; set; }
        public string errorcode { get; set; }
        public List<MiniStatementEntry> ministatement { get; set; }
        public int response_code { get; set; }
    }
}
