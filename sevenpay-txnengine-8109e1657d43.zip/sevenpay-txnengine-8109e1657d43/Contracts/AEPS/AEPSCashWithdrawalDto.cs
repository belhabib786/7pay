﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPS
{
	public class AEPSCashWithdrawalDto
	{
		public string latitude { get; set; } // string	22.44543
		public string longitude { get; set; } // string	77.434
		public string mobilenumber { get; set; } // string	9900000099
		public string? referenceno { get; set; } // string	43542343434(unique txn value)
		public string? ipaddress { get; set; } // string	122.44.443.00
		public string adhaarnumber { get; set; } // string
		public string? accessmodetype { get; set; } //  string APP OR SITE
		public long nationalbankidentification { get; set; } // number
		public string? requestremarks { get; set; } // string
		public string data { get; set; } //    xml string fingerprint xml data
		public string pipe { get; set; } // string bank2 OR bank3// bank1 work for UAT only
		public string? timestamp { get; set; } // string	2020-01-12 13:00:12
		public string? transactiontype { get; set; } // string BE
		public string submerchantid { get; set; } // alphanumeric	1
		public string is_iris { get; set; } //(Yes in case of iris device)    Yes OR No

		//code added by swapnal
		public string bankIIN { get; set; }
		public string deviceType { get; set; }
		public string deviceModel { get; set; }
		public string deviceMake { get; set; }
		public double amount { get; set; }
    }
}
