﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPS
{
    public class PostPSOnboardingInsertDto
    {
        public int supplierid { get; set; }
        public string supplier_csp_id { get; set; }
        public int onboarding_status { get; set; }
        public int createdby { get; set; }
        public int orgid { get; set; }
        public string refparam1 { get; set; }
        public string refparam2 { get; set; }
        public string refparam3 { get; set; }
    }
}
