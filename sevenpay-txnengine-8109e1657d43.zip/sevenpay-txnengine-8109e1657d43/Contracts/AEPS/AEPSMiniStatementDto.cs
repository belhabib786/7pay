﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPS
{
	public class AEPSMiniStatementDto
	{
        public string aadharNumber { get; set; }
        public string bankIIN { get; set; }
        public dynamic biometricData { get; set; }
        public string deviceType { get; set; }
        public string deviceMake { get; set; }
        public string deviceModel { get; set; }
        public string deviceIp { get; set; }
        public string customerName { get; set; }
        public string customerMob { get; set; }
        public string latitude { get; set; } //: "22.44543",
        public string longitude { get; set; } // ": "77.434",
        public string remarks { get; set; }
        public string submerchantid { get; set; }
        public string is_iris { get; set; }
        public string pipe { get; set; }
        public long nationalbankidentification { get; set; }
    }
}
