﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPS
{
	public class AEPSPostTransactionRequestDto
	{
		public long p_txnid { get; set; } // int8    IN	1	[NULL]
		public int p_txnstatus { get; set; } //int4    IN	2	[NULL]
		public string p_supptxnnumber { get; set; } //varchar IN	3	[NULL]
		public long p_userid { get; set; } //int8    IN	4	[NULL]
		public string p_remarks { get; set; } //text    IN	5	[NULL]
		public string p_sprefno { get; set; } //varchar IN	6	[NULL]

		//p_operationstatus int4    TABLE	7	[NULL]
		//p_operationmessage varchar TABLE	8	[NULL]
		//p_operationlogid int4    TABLE	9	[NULL]
	}
}
