﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPS
{
    public class EnquiryRequestModelDto
    {
        public string latitude { get; set; } // string	22.44543
        public string longitude { get; set; } // string	77.434
        public string mobilenumber { get; set; } // string	9900000099
        public string referenceno { get; set; } // string	43542343434(unique txn value)
        public string ipaddress { get; set; } // string	122.44.443.00
        public string adhaarnumber { get; set; } // string
        public string accessmodetype { get; set; } //  string APP OR SITE
        public long nationalbankidentification { get; set; } // number
        public string requestremarks { get; set; } // string
        public string data { get; set; } //    xml string fingerprint xml data
        public string pipe { get; set; } // string bank2 OR bank3// bank1 work for UAT only
        public string timestamp { get; set; } // string	2020-01-12 13:00:12
        public string transactiontype { get; set; } // string BE
        public string submerchantid { get; set; } // alphanumeric	1
        public string is_iris { get; set; } //(Yes in case of iris device)    Yes OR No
        //public string p_aadharcardnumber { get; set; }
        //public string p_mobilenumber { get; set; }
        //public int p_cardtype { get; set; }
        //public string p_transdatetime { get; set; }
        //public int p_status { get; set; }
        //public int p_paymenttype { get; set; }
        //public int p_createdby { get; set; }
        //public string p_creatoripaddress { get; set; }
        //public long p_orgid { get; set; }
        //public long p_serviceid { get; set; }
        //public long p_supplierid { get; set; }
        //public long p_serviceproviderid { get; set; }
        //public decimal p_servicecharge { get; set; }
        //public decimal p_markup { get; set; }
        //public int p_transactionmode { get; set; }
        //public decimal p_transactionvalue { get; set; }
        //public string p_bankid { get; set; }
        //public int p_savetxn { get; set; }
        //public string p_maskedaadhar { get; set; }
        //public string p_imeino { get; set; }
        //public string p_comment { get; set; }
        //public string p_serialno { get; set; }
        //public string p_csrid { get; set; }
        //public string p_vid { get; set; }
        //public string p_consentlanguage { get; set; }
        //public string p_stanno { get; set; }
        //public string p_devicecode { get; set; }
    }
}
