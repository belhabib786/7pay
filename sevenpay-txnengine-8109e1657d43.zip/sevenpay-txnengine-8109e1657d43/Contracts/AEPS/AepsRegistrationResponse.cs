﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPS
{
    public class AepsRegistrationResponse
    {
        public int response_code { get; set; }
        public int errorcode { get; set; }
        public bool status { get; set; }
        public string message { get; set; }
    }
}
