﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class BillPaymentRequest
    {
        public string agentId { get; set; }
        public string requestId { get; set; }
        public string productId { get; set; }

        public bool billerAdhoc { get; set; }
        public AgentDeviceInfo agentDeviceInfo { get; set; }
        public CustomerInfo customerInfo { get; set; }
        public string billerId { get; set; }
        public InputParam inputParams { get; set; }
        public BillerResponse billerResponse { get; set; }
        public AdditionalInfo additionalInfo { get; set; }
        public AmountInfo amountInfo { get; set; }
        public PaymentMethod paymentMethod { get; set; }
        public PaymentInfo paymentInfo { get; set; }
    }
}
