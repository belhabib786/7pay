﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class BillerResponse
    {
        public AmountOptions amountOptions { get; set; }
        public string billAmount { get; set; }
        public string billDate { get; set; }
        public string billNumber { get; set; }
        public string billPeriod { get; set; }
        public string customerName { get; set; }
        public string dueDate { get; set; }
    }
}
