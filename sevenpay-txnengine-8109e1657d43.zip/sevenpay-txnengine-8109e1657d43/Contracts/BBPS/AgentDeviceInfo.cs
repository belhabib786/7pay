﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class AgentDeviceInfo
    {
        public string ip { get; set; }
        public string initChannel { get; set; }
        public string mac { get; set; }
    }
}
