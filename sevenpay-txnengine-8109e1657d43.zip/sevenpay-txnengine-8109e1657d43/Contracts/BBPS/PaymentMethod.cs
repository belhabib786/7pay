﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class PaymentMethod
    {
        public string paymentMode { get; set; }
        public string quickPay { get; set; }
        public string splitPay { get; set; }
    }
}
