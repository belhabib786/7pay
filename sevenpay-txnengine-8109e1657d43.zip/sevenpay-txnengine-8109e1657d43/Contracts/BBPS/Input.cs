﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class Input
    {
        public string paramName { get; set; }
        public string paramValue { get; set; }
    }
}
