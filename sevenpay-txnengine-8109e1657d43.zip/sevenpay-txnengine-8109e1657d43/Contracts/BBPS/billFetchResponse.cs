﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Contracts.BBPS.billFetchRequest;

namespace Contracts.BBPS
{

    public class billFetchResponse
    {
        public string responseCode { get; set; }

        //code modified by swapnal
        public InputResponseParams inputParam { get; set; }
		public InputParams inputParams { get; set; }

		public BillerResponse billerResponse { get; set; }
        public AdditionalInfo additionalInfo { get; set; }
    }

}
