﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class BillPayResponse
    {
        public int responseCode { get; set; }
        public string responseReason { get; set; }
        public string transactionId { get; set; }
        public string transactionAmount { get; set; }
        public string commissionEarned { get; set; }
        public string txnRefId { get; set; }
        public int serviceCharge { get; set; }
    }
}
