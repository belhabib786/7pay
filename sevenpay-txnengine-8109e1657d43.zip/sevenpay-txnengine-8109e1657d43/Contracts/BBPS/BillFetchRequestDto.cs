﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class BillFetchRequestDto
    {
        public string requestId { get; set; }
        public int orgId { get; set; }
        public int serviceId { get; set; }
        public int supplierId { get; set; }
        public int serviceProviderId { get; set; }
        public string agentId { get; set; }
        public AgentDeviceInfo agentDeviceInfo { get; set; }
        public CustomerInfo customerInfo { get; set; }
        public string billerId { get; set; }
        public InputParam inputParams { get; set; }
    }
}
