﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class AmountInfo
    {
        public int amount { get; set; }
        public int currency { get; set; }
        public int custConvFee { get; set; }
        public string amountTags { get; set; }
    }
}
