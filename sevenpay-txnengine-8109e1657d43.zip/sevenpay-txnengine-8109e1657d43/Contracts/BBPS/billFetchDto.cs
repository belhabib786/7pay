﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class billFetchDto
    {
        public billFetchResponse billFetchResponse { get; set; }
        public string requestId { get; set; }
    }
}
