﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.BBPS
{
    public class AmountOption
    {
        public string amountName { get; set; }
        public string amountValue { get; set; }
    }
}
