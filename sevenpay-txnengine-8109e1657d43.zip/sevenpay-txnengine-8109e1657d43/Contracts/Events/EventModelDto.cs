﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Events
{
    public class EventModelDto
    {
        public string Id { get; set; }
        public DateTime TimeStamp { get; set; }
        //public Guid AggregateIdentifier { get; set; } //code temp commented by swapnal
        //public string AggregateType { get; set; } //code temp commented by swapnal
        public int Version { get; set; }
        public string EventType { get; set; }
        public long TransactionId { get; set; }
        public dynamic EventData { get; set; }
        
        //code temp comments by swapnal
        //public BaseEvent EventData { get; set; }
    }
}
