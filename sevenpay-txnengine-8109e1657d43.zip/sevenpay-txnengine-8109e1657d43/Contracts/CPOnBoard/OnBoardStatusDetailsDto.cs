﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.CPOnBoard
{
    public class OnBoardStatusDetailsDto
    {
        public int orgid { get; set; }
        public int onboardstate { get; set; }
        public int status { get; set; }
    }
}
