﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.CPOnBoard
{
    public class UpdateAdharDetailsWithCpDetails
    {
        public string? dob { get; set; }
        public string? perm_house_no { get; set; }
        public string? perm_road { get; set; }
        public string? perm_dist { get; set; }
        public string? perm_sub_dist { get; set; }
        public string? perm_pincode { get; set; }
        public string? perm_landmark { get; set; }
        public string? gender { get; set; }
        public int orgid { get; set; }
    }
}
