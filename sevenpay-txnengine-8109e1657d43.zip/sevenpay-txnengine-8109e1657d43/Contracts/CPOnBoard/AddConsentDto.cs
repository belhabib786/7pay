﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.CPOnBoard
{
    public class AddConsentDto
    {
        public string consenttype { get; set; }
        public int orgid { get; set; }
        public int creator { get; set; }
        public int status { get; set; }
        public string consentdesc { get; set; }
        public string ref_param1 { get; set; }
        public string ref_param2 { get; set; }
        
    }
}
