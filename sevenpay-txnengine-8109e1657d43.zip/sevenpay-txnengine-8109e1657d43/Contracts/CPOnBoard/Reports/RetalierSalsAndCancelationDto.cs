﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.CPOnBoard.Reports
{
    public class RetalierSalsAndCancelationDto
    {
        public long service_id { get; set; }
        public string p_fromdt { get; set; }
        public string p_todt { get; set; }
        public int statusone { get; set; }
        public int statustwo { get; set; }
    }
}
