﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.CPOnBoard.Reports
{
    public class GetcancelTxnDto
    {
        public long service_id { get; set; }
        public string p_fromdt { get; set; }
        public string p_todt { get; set; }
        public int txn_status { get; set; }
        //public long org_id { get; set; }
    }
}
