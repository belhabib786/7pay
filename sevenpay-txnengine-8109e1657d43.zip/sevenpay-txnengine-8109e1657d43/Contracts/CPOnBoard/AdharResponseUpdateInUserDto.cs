﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.CPOnBoard
{
    public class AdharResponseUpdateInUserDto
    {
        public string? dob { get; set; }
        public string? gender { get; set; }
        public int userid { get; set; }
    }
}
