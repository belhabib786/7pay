﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction
{
    public class ChannelPartnerInfoDto
    {
        [Required (ErrorMessage = "UserId can not be Empty. Please provide valid UserId.")]
        public int userId { get; set; }

        [Required(ErrorMessage = "OrgId can not be Empty. Please provide valid OrgId.")]
        public int orgId { get; set; }

        public int distributorId { get; set; }
        
        public int superdistributorId { get; set; }
    }
}
