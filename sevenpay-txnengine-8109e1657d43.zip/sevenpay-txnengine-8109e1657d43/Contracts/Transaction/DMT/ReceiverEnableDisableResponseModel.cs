﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction.DMT
{
    public class ReceiverEnableDisableResponseModel
    {
        public int responsecode { get; set; } 
        public string o_mobilenumber { get; set; }
    }
}
