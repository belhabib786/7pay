﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction.DMT
{
    public class ActiveDeactivateReceiverOTPValidationDto
    {
        public string p_mobilenumber { get; set; } 
        public int receiverid { get; set; }
        public int otp { get; set; }
        public int p_moduleid { get; set; }
        public int p_status { get; set; }
    }
}
