﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction.DMT
{
    public class ActiveDeactivateReceiverDto
    {
        public long receiverid { get; set; }
        public int p_status { get; set; }
        public int creator { get; set; }
        public string creatoripaddress { get; set; }
    }
}
