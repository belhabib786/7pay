﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction.DMT
{
    public class BeneficiaryModelDto
    {
        public long senderid { get; set; }
        public long receiverid { get; set; }
        public string receivername { get; set; }
        public string receivermobile { get; set; }
        public string ifsccode { get; set; }
        public string accountno { get; set; }
        public int creator { get; set; }
        public int bankid { get; set; }
        public int beneficiaryid { get; set; }
        public string emailid { get; set; }
        public string creatoripaddress { get; set; }
        public string bankname { get; set; }
        public int status { get; set; }
        public int isacctvalidated { get; set; }
        //propert added for bug no 
        public string sendermobile { get; set; }
        public string? otp { get; set; }
        public int? isverified { get; set; }
    }
}
