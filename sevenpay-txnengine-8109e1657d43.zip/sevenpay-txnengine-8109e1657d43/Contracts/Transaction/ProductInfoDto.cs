﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction
{
    public class ProductInfoDto
    {
        [Required(ErrorMessage = "Channel Id can not be Empty. Please provide valid channel id.")]
        public int channelId { get; set; }
        
        [Required(ErrorMessage = "Channel Id can not be Empty. Please provide valid channel id.")] 
        public int productId { get; set; }

        [Required(ErrorMessage = "Channel Id can not be Empty. Please provide valid channel id.")]
        public int serviceId { get; set; }
        
        public int supplierId { get; set; }
        
        public int serviceProviderId { get; set; }
        
        public int serviceSupplierMapping { get; set; }
    }
}
