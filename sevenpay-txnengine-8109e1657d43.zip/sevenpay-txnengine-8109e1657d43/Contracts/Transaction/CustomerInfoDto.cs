﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction
{
    public class CustomerInfoDto
    {
        [Required(ErrorMessage = "Customer mobile number can not be Empty. Please provide valid customer mobile number.")]
        public string mobileNumber { get; set; }

        public string? name { get; set; }
        
        public string? email { get; set; }
    }
}
