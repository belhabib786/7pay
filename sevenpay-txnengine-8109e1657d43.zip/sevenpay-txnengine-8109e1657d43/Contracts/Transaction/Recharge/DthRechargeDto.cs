﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction.Recharge
{
    public class DthRechargeDto
    {
        [Required(ErrorMessage = "Please provide valid ca number.")]
        [StringLength(maximumLength: 15, MinimumLength = 7, ErrorMessage = "Please provide 7 - 15 digits ca number. ")]
        public string caNumber { get; set; }
        [Required(ErrorMessage = "Please provide valid service provider.")]
        public string serviceProvider { get; set; }
    }
}
