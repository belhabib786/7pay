﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction
{
    public class TransactionCommonRequestDto<T>
    {
        public ChannelPartnerInfoDto channelPartnerInfo { get; set; }
        
        public OrderInfoDto order { get; set; }
        
        public ProductInfoDto product { get; set; }
        
        public CustomerInfoDto customer { get; set; }
        
        public LocationInfoDto location { get; set; }
        
        public TransactionInfoDto<T> transactionInfo { get; set; }
    }
}
