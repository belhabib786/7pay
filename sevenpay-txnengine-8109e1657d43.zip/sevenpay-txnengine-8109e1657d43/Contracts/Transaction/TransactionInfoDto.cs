﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction
{
    public class TransactionInfoDto<T>
    {
        public double serviceCharges { get; set; }

        [Required(ErrorMessage = "Transaction amount can not be Empty. Please provide INR as default currency.")]
        public double transactionAmount { get; set; }

        public T transactionData { get; set; }
    }
}
