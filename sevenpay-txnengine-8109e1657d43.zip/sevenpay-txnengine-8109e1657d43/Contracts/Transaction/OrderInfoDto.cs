﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction
{
    public class OrderInfoDto
    {
        [Required(ErrorMessage = "Order Reference Id can not be Empty. Please provide valid Order Reference Id.")]
        public string orderReferenceId { get; set; }
 
        public string orderTimestamp { get; set; }
        [Required(ErrorMessage = "Order amount can not be Empty. Please provide valid order amount.")]
        
        public double orderamount { get; set; }
        
        [Required(ErrorMessage = "Order currency can not be Empty. Please provide INR as default currency.")]
        public string orderCurrency { get; set; }
       
        public string orderCommnet { get; set; }

        [Required(ErrorMessage = "Order payment mode can not be Empty. Please provide order payment mode.")]
        public string orderPaymentMode { get; set; }
      
        public string orderType { get; set; }
        
        public string orderAccountingType { get; set; }
        
        public int orderMarkup { get; set; }
    }
}
