﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Transaction
{
    public class LocationInfoDto
    {
        [Required(ErrorMessage = "IP address can not be Empty. Please provide valid IP address.")]
        public string ip { get; set; }
        
        public string lat { get; set; }
        
        public string lang { get; set; }
        
        public string IMEI { get; set; }
    }
}
