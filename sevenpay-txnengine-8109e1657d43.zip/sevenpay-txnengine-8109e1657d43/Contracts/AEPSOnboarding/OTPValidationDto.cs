﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPSOnboarding
{
    public class OTPValidationDto
    {
        public string mobilenumber { get; set; }
        public string otptoken {get; set;}
        public string otp { get; set;}
        public string agentReferenceId { get; set;}

    }
}
