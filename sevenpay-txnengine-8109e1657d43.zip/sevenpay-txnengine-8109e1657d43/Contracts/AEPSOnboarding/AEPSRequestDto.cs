﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPSOnboarding
{
    public class AEPSRequestDto
    {
        public string RequestType { get; set; }

        public string RequestId { get; set; }
        public string MobileNumber { get; set; }

        public string FullName { get; set; }

        public string CustomerPANNumber { get; set; }

        public string AgentPANNumber { get; set; }



        public DateTime? DateOfBirth { get; set; }

        public string Gender { get; set; }


        public string Email { get; set; }

        public string AgentReferenceId { get; set; }


        public string AgentShopName { get; set; }

        public string CustomerTitle { get; set; }

        public string CustomerPANCard { get; set; }


        public string Form60 { get; set; }

        public long? AgriculturalIncome { get; set; }
        public long? NonAgriculturalIncome { get; set; }

        public string CustomerAddress { get; set; }

        public string OTPToken { get; set; }

        public string OTP { get; set; }
        public string KYCToken { get; set; }
        public string AadhaarNumber { get; set; }

        public string TypeOfAadhaar { get; set; }

        public DateTime? BiometricDeviceCertificateExpDate { get; set; }

        public string DevicePIDXml { get; set; }

        public string FingerData { get; set; }

        public string BiometricDeviceSerialNumber { get; set; }
        public string BiometricDeviceSessionKey { get; set; }

        public string BiometricDeviceType { get; set; }

        public string BiometricDeviceVersionNumber { get; set; }

        public string Consent { get; set; }
        public string KYCType { get; set; }
        public string CapturedTemplate { get; set; }
        public string Purpose { get; set; }

        public string WADHValue { get; set; }

        //code added by swapnal for date of birth
        public int? DayOfBirth { get; set; }
        public int? MonthOfBirth { get; set; }
        public int? YearOfBirth { get; set; }
    }
}
