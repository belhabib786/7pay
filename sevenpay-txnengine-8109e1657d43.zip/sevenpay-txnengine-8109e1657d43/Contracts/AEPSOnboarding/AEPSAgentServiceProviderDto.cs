﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPSOnboarding
{
    public class AEPSAgentServiceProviderDto
    {
        public string code { get;set; }
        public string name { get;set; } 
        public string logoURL { get;set; }
        public bool isEnable { get;set; }
        public string comments { get;set; }
    }
}
