﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.AEPSOnboarding
{
    public class KYCBioMetricDto
    {
        public string otptoken { get; set; }
        public string kyctoken { get; set; }
        public string aadharwadh { get; set; }
        public string aadharNumber { get; set; }
        public string aadhaarType { get; set; }
        public string deviceDataXML { get; set; }
        public string fingerData { get; set; }
        public string deviceSerialNo { get; set; }
        public string bioTimeStamp { get; set; }
        public string deviceType { get; set; }
        public string consent { get; set; }
        public string ekycType { get; set; }
        public string purpose { get; set; }
        public string MobileNumber { get; set;}
        public string AgentReferenceId { get; set; }
    }
}
