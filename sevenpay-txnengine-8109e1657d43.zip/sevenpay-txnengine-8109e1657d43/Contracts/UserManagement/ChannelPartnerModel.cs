﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.UserManagement
{
    public class ChannelPartnerModel
    {
        public int OrgId { get; set; }
        public string OrgCode { get; set; }
        public string OrgName { get; set; }
        public int Orgtype { get; set; }
        public int Status { get; set; }
    }
}
