﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.UserManagement
{
    public class UserProfileModel
    {
        public UserBasicInformationModel userBasicInformationModel { get; set; }
        public ChannelPartnerModel channelPartnerModel { get; set; }
        public ChannelPartnerDetailsModel channelPartnerDetailsModel { get; set; }
        public UserFinancialModel userFinancialModel { get; set; }
    }
}
