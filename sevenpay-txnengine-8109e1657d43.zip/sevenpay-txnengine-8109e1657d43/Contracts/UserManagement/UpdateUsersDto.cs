﻿using Contracts.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.UserManagement
{
    public class UpdateUsersDto
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string LoginId { get; set; }
        public long OrgId { get; set; }
       
        public int DepartmentId { get; set; }
        public string EmailId { get; set; }
        public int DesignationId { get; set; }
        public int ReportsTo { get; set; }
        public int RoleId { get; set; }
        public int Modifier { get; set; }
        public DateTime ModificationDate { get; set; }
        public string IPAddress { get; set; }
       
    }
}
