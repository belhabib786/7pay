﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.UserManagement
{
    public class UserFinancialModel
    {
        public string BankId { get; set; }
        public string IFSCCode { get; set; }
        public string AccountType { get; set; }
        public string AccountNumber { get; set; }
        public string Pancard { get; set; }
        public string Aadharcard { get; set; }
    }
}
