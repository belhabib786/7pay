﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.UserManagement
{
    public class ChannelPartnerDetailsModel
    {
        public string DOB { get; set; }
        public string Perm_House_No { get; set; }
        public string Perm_Road { get; set; }
        public string Perm_Village { get; set; }
        public string Perm_Taluka { get; set; }
        public string Perm_Pincode { get; set; }
        public string Busi_House_No { get; set; }
        public string Busi_Road { get; set; }
        public string Busi_Village { get; set; }
        public string Busi_Taluka { get; set; }
        public string Busi_Pincode { get; set; }
    }
}
