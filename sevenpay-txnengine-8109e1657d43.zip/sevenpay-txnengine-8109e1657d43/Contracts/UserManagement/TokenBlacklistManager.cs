﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.UserManagement
{
    public static class TokenBlacklistManager
    {
        private static readonly List<string> BlacklistedTokens = new List<string>();

        public static void AddToBlacklist(string token)
        {
            lock (BlacklistedTokens)
            {
                BlacklistedTokens.Add(token);
                //BlacklistedTokens.Remove(token);
            }
        }

        public static bool IsTokenBlacklisted(string token)
        {
            lock (BlacklistedTokens)
            {
                return BlacklistedTokens.Contains(token);
            }
        }
    }
}
