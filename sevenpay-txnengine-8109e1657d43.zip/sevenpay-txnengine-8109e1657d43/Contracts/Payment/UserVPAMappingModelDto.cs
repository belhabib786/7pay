﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Payment
{
    public class UserVPAMappingModelDto
    {
        public long id { get; set; }
        public long orgId { get; set; }
        public string vpa { get; set; }
        public int status { get; set; }
    }
}
