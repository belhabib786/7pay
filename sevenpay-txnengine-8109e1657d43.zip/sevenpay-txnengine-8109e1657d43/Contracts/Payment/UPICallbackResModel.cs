﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Payment
{
    public class UPICallbackResModel
    {
        public long UPITxnID { get; set; }
        public string OrderNo { get; set; }  //Merchant Ref No
        public string Type { get; set; }
        public double Amount { get; set; }
        public string TransactionAuthDate { get; set; }
        public string Status { get; set; }
        public string StatusDescription { get; set; }
        public string ResponseCode { get; set; }
        public string ErrorCode { get; set; }
        public string ApprovalNumber { get; set; }
        public string PayerVirtualAddress { get; set; }
        public string NPCIUPITrnxID { get; set; }
        public long ReferenceID { get; set; }
        public string PayerMobileNo { get; set; }
        public string PayeeMobileNo { get; set; }
        public string PayerNote { get; set; }
        public long CustRefID { get; set; }
        public long PayerAccountNo { get; set; }
        public string PayerIFSCCode { get; set; }
        public string PayerAccountName { get; set; }
        public string PayeeVirtualAddress { get; set; }
        public string PayeeIFSC { get; set; }
        public string PayeeAccountNumber { get; set; }
        public string PayeeAADHAAR { get; set; }
        public string PayeeName { get; set; }
        public string AdditionalField1 { get; set; }
        public string AdditionalField2 { get; set; }
        public string AdditionalField3 { get; set; }
        public string AdditionalField4 { get; set; }
        public string AdditionalField5 { get; set; }
        public string AdditionalField6 { get; set; }
        public string AdditionalField7 { get; set; }
        public string AdditionalField8 { get; set; }
        public string AdditionalField9 { get; set; }
        public string AdditionalField10 { get; set; }
    }
}
