﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts.Payment
{
    public class UploadPaymentReceiptModelDto
    {
        public long? id { get; set; }
        public string fileData { get; set; }
        public string? filePath { get; set; }
        public long orgId { get; set; }
        public DateTime? updateOn { get; set; }
    }
}
