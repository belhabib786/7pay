﻿
using Confluent.Kafka;

namespace Accounting
{
    class Program
    {
        private static readonly object LockObject = new object();

        private static readonly IEnumerable<KeyValuePair<string, string>> cConfig = new ConsumerConfig
        {
            BootstrapServers = "uat-kafka.bankify.internal:9092", //"localhost:9092",
            //SaslMechanism = SaslMechanism.Plain,
            //SecurityProtocol = SecurityProtocol.SaslSsl,
            //SaslUsername = "xxxxxxx",
            //SaslPassword = "xxxxx+",
            GroupId = "recharge",
            AutoOffsetReset = AutoOffsetReset.Earliest
        };

        private static readonly IEnumerable<KeyValuePair<string, string>> pubConfig = new ProducerConfig
        {
            BootstrapServers = "uat-kafka.bankify.internal:9092", //"localhost:9092",
            //SaslMechanism = SaslMechanism.Plain,
            //SecurityProtocol = SecurityProtocol.SaslSsl,
            //SaslUsername = "xxxxxxx",
            //SaslPassword = "xxxxx+",
        };

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World from Accounting");

            var _request = @"{
              ""channelPartnerInfo"": {
                ""userId"": 0,
                ""orgId"": 0,
                ""distributorId"": 0,
                ""superdistributorId"": 0
              },
              ""order"": {
                ""orderReferenceId"": ""string"",
                ""orderTimestamp"": ""string"",
                ""orderamount"": 0,
                ""orderCurrency"": ""string"",
                ""orderCommnet"": ""string"",
                ""orderPaymentMode"": ""string"",
                ""orderType"": ""string"",
                ""orderAccountingType"": ""string"",
                ""orderMarkup"": 0
              },
              ""product"": {
                ""channelId"": 0,
                ""productId"": 0,
                ""serviceId"": 0,
                ""supplierId"": 0,
                ""serviceProviderId"": 0,
                ""serviceSupplierMapping"": 0
              },
              ""customer"": {
                ""mobileNumber"": ""string"",
                ""name"": ""string"",
                ""email"": ""string""
              },
              ""location"": {
                ""ip"": ""string"",
                ""lat"": ""string"",
                ""lang"": ""string"",
                ""imei"": ""string""
              },
              ""transactionInfo"": {
                ""serviceCharges"": 0,
                ""transactionAmount"": 0,
                ""transactionData"": {
                  ""p_transactiondate"": ""2023-02-14"",
                  ""p_retailerid"": 3,
                  ""p_serviceid"": 6,
                  ""p_supplierid"": 9,
                  ""p_serviceproviderid"": 10,
                  ""p_transactionvalue"": 100,
                  ""p_suppliertransactionvalue"": 100,
                  ""p_servicecharge"": 0,
                  ""p_markup"": 0,
                  ""p_transactionmode"": 2,
                  ""p_transactiontype"": 2,
                  ""p_transactionnumber"": """",
                  ""p_transactionfee"": 15,
                  ""p_ip_address"": ""string"",
                  ""p_userid"": 6,
                  ""p_customerref1"": ""6"",
                  ""p_customerref2"": ""9"",
                  ""p_customerref3"": ""string"",
                  ""p_orgtxnid"": 0,
                  ""p_custmobno"": ""9892144614"",
                  ""p_comments"": ""string"",
                  ""p_imei"": ""string"",
                  ""p_customername"": ""Swapnal R Chonkar"",
                  ""p_beneifsccode"": ""HDFC0000398"",
                  ""p_beneaccountno"": ""03981370001214"",
                  ""p_benname"": ""Swapnal R Chonkar""
                }
              }
            }";

            TransactionsQueueReceiveCompleted(_request);

            Console.ReadKey();
        }

        static void TransactionsQueueReceiveCompleted(string message)
        {
            Console.WriteLine("Hey Delegate called !!!!!!!!!!!!!!!!");
            try
            {
                lock (LockObject)
                {
                    //Thread.Sleep(5);

                    using (var _publish = new ProducerBuilder<Null, string>(pubConfig).Build())
                    {
                        try
                        {
                            //var _message = _publish.ProduceAsync("DMTPostTransaction", new Message<Null, string> { Value = message });
                            //_publish.Produce("DMTPostTransaction", new Message<Null, string> { Value = message }, null);
                            //Console.WriteLine($"Delivered '{_message.Result.Value}' to '{_message.Result.TopicPartitionOffset}'");
                            //_publish.Flush();
                            //Thread.Sleep(50000);
                            Console.WriteLine("We are out of sleep - Thread.Sleep(50000)");
                        }
                        catch (ProduceException<Null, string> e)
                        {
                            Console.WriteLine($"Delivery failed: {e.Error.Reason}");
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine("ERROR " + exception.Message);
            }
        }
    }
}
