﻿using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;


namespace EmailNotificationLibrary
{
    public class SendGridEmailNotification : IEmailNotification
    {
        public async Task SendEmail(string emailAddress, string name, string subject, string body, bool isHtml)
        {
            try
            {
                //var apiKey = Environment.GetEnvironmentVariable("NAME_OF_THE_ENVIRONMENT_VARIABLE_FOR_YOUR_SENDGRID_KEY");
                var client = new SendGridClient("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");
                var from = new EmailAddress("noreply@sevenpay.in", "seven pay");
                //code commented by swapnal
                //var subject = "Sending with SendGrid is Fun";
                var to = new EmailAddress(emailAddress, name);
                //var plainTextContent = "and easy to do anywhere, even with C#";
                var htmlContent = body;
                var msg = MailHelper.CreateSingleEmail(from, to, subject, String.Empty, htmlContent);
                var response = await client.SendEmailAsync(msg);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
