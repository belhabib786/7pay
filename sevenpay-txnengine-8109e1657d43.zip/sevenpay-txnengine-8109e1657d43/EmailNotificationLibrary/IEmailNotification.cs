﻿namespace EmailNotificationLibrary
{
    public interface IEmailNotification
    {
        Task SendEmail(string emailAddress, string name, string subject, string body, bool isHtml);
    }
}