﻿using AEPSAgentOnboardingLibrary.YesBank.Enitity.Common;
using AEPSAgentOnboardingLibrary.YesBank.Enitity.RequestEntity;
using Logger;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank
{
    public class APIHandler
    {
        readonly string ProviderURL;
        readonly HeaderEntity _requestHeader;
        readonly SecurityMiddleware securityMiddleware;
        readonly ResponseHandler _responseHandler;
        //logger 
        readonly ICustomLogger _logger;

        public APIHandler()
        {
            ProviderURL = ConfigurationManager.AppSettings[ConfigurationManager.AppSettings["Environment"]];
            _requestHeader = new HeaderEntity();
            securityMiddleware = new SecurityMiddleware();
            _responseHandler = new ResponseHandler(securityMiddleware);
            _logger = new CustomLogger("AEPSAgentOnboardingLog");
        }

        public T ProcessRequest<T>(BaseRequest request)
        {
            try
            {
              
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(ProviderURL);
                httpWebRequest.Method = "POST";
           

                var jsonRequest = Newtonsoft.Json.JsonConvert.SerializeObject(request);
                _logger.LogInfo(jsonRequest);


                _requestHeader.AppendHeader(httpWebRequest, jsonRequest, securityMiddleware);
                var requestDataToProceed = request.ToEncryptedBody(securityMiddleware);            

                byte[] byteArray = Encoding.UTF8.GetBytes(requestDataToProceed);

                httpWebRequest.ContentType = "application/json"; //charset=utf-8"
                httpWebRequest.ContentLength = byteArray.Length;

                Stream dataStream = httpWebRequest.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);
                dataStream.Close();
                WebResponse response = httpWebRequest.GetResponse();

                dataStream = response.GetResponseStream();
                var reader = new StreamReader(dataStream);
                // Read the content.
                string responseString = reader.ReadToEnd();

                // Clean up the streams.
                reader.Close();
                dataStream.Close();
                response.Close();

                string decriptedResponse = _responseHandler.DecryptResponse(responseString);

                //End Code To send webRequest
                Console.WriteLine($"encrypted response: {responseString}");
                Console.WriteLine($"decrypted response: {decriptedResponse}");

                var responseObject = JsonSerializer.Deserialize<T>(decriptedResponse);
                _logger.LogInfo(responseString);
                return responseObject;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
