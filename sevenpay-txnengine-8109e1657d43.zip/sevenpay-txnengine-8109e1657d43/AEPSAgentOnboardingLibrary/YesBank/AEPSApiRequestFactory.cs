﻿using AEPSAgentOnboardingLibrary.YesBank.Enitity.Common;
using AEPSAgentOnboardingLibrary.YesBank.Enitity.Model;
using AEPSAgentOnboardingLibrary.YesBank.Enitity.RequestEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank
{
    public class AEPSApiRequestFactory
    {
        AESPRequestType _aESPRequestType;
        public AEPSApiRequestFactory(AESPRequestType aESPRequestType)
        {
            _aESPRequestType = aESPRequestType;
        }

        public BaseRequest GetRequest(AEPSRequestModel aEPSRequestModel)
        {
            switch (_aESPRequestType)
            {
                case AESPRequestType.AGENTCREATION:
                    {
                        return GetAgentCreationRequest(aEPSRequestModel);
                    }
                case AESPRequestType.CUSTOMERCREATION:
                    {
                        return GetCustomerCreationRequest(aEPSRequestModel);
                    }
                case AESPRequestType.OTPVALIDATION:
                    {
                        return GetValidateOTPRequest(aEPSRequestModel);
                    }
                case AESPRequestType.AADHAARWADH:
                    {
                        return GetAadhaarWadhRequest(aEPSRequestModel);
                    }
                case AESPRequestType.BIOMETRICKYC:
                    {
                        return GetAadhaarBiometricKYCRequest(aEPSRequestModel);
                    }
            }
            throw new NotImplementedException();
        }

        public AgentCreationRequest GetAgentCreationRequest(AEPSRequestModel aEPSRequestModel)
        {

            return new AgentCreationRequest()
            {
                requestId = aEPSRequestModel.RequestId,
                p1 = aEPSRequestModel.MobileNumber,
                p2 = aEPSRequestModel.FullName,
                p3 = aEPSRequestModel.AgentPANNumber,
                //p4 = $"{aEPSRequestModel.DateOfBirth.Value.Day}/{aEPSRequestModel.DateOfBirth.Value.Month > 9 ? aEPSRequestModel.DateOfBirth.Value.Month : "0"+ aEPSRequestModel.DateOfBirth.Value.Month}/{aEPSRequestModel.DateOfBirth.Value.Year}",
                p4 = (aEPSRequestModel.DateOfBirth.Value.Day > 9 ? aEPSRequestModel.DateOfBirth.Value.Day : "0" + aEPSRequestModel.DateOfBirth.Value.Day) + "/" + 
                      (aEPSRequestModel.DateOfBirth.Value.Month > 9 ? aEPSRequestModel.DateOfBirth.Value.Month : "0"+ aEPSRequestModel.DateOfBirth.Value.Month ) + "/" + 
                      aEPSRequestModel.DateOfBirth.Value.Year,
                p5 = aEPSRequestModel.Gender,
                p6 = aEPSRequestModel.Email,
                p7 = aEPSRequestModel.AgentReferenceId,
                p8 = aEPSRequestModel.AgentShopName,
            };
        }

        CustomerCreationRequest GetCustomerCreationRequest(AEPSRequestModel aEPSRequestModel)
        {

            return new CustomerCreationRequest()
            {
                requestId = aEPSRequestModel.RequestId,
                p1 = aEPSRequestModel.MobileNumber,
                p2 = aEPSRequestModel.CustomerTitle,
                p3 = aEPSRequestModel.FullName,
                p4 = aEPSRequestModel.CustomerPANCard,
                //p4 = aEPSRequestModel.DateOfBirth.Value.ToString("dd/MM/yyyy"),
                p6 = aEPSRequestModel.AgriculturalIncome.Value.ToString(),
                p7 = aEPSRequestModel.NonAgriculturalIncome.ToString(),
                p8 = aEPSRequestModel.DateOfBirth.Value.ToString("dd/MM/yyyy"),
                p9 = aEPSRequestModel.Gender,
                p10 = aEPSRequestModel.Email,
                p11 = aEPSRequestModel.AgentReferenceId,
                p12 = aEPSRequestModel.CustomerAddress,
                p13 = aEPSRequestModel.AgentPANNumber
            };
        }

        ValidateOTPRequest GetValidateOTPRequest(AEPSRequestModel aEPSRequestModel)
        {

            return new ValidateOTPRequest()
            {
                requestId = aEPSRequestModel.RequestId,
                p1 = aEPSRequestModel.MobileNumber,
                p2 = aEPSRequestModel.OTPToken,
                p3 = aEPSRequestModel.OTP,

            };
        }


        AadhaarWadhRequest GetAadhaarWadhRequest(AEPSRequestModel aEPSRequestModel)
        {

            return new AadhaarWadhRequest()
            {
                requestId = aEPSRequestModel.RequestId,
                p1 = aEPSRequestModel.MobileNumber,
                p2 = aEPSRequestModel.KYCToken,
                p3 = aEPSRequestModel.AgentReferenceId,

            };
        }

        AadhaarBiometricKYCRequest GetAadhaarBiometricKYCRequest(AEPSRequestModel aEPSRequestModel)
        {

            return new AadhaarBiometricKYCRequest()
            {
                requestId = aEPSRequestModel.RequestId,
                p1 = aEPSRequestModel.MobileNumber,
                p2 = aEPSRequestModel.KYCToken,
                p3 = aEPSRequestModel.AgentReferenceId,
                p4 = aEPSRequestModel.AadhaarNumber,

                p5 = aEPSRequestModel.TypeOfAadhaar,
                p7 = aEPSRequestModel.DevicePIDXml,
                p8 = aEPSRequestModel.FingerData,
                p9 = aEPSRequestModel.BiometricDeviceSerialNumber,
                p12 = aEPSRequestModel.BiometricDeviceType,
                p14 = "Y",
                p15 = aEPSRequestModel.KYCType,
                p16 = "Null",
                p17 = aEPSRequestModel.Purpose,
                p18 = aEPSRequestModel.WADHValue
            };
        }
    }
}
