﻿using AEPSAgentOnboardingLibrary.YesBank.Enitity.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank.Enitity.RequestEntity
{
    /// <summary>
    /// P1 - Mobile Number of agent for registration
    /// P2 - Agent FullName
    /// P3 - Agent PAN number
    /// P4 - Agent DOB
    /// P5 - Agent Gender
    /// P6 - Agent Email Address
    /// P7 - Agent Reference Id
    /// P8 - Agent Shop name
    /// </summary>
    public class AgentCreationRequest : BaseRequest
    {
        public override string actionName { get => AEPSConstant.AGENT_CREATION; }

      //  public override string actionName => throw new NotImplementedException();

        //public string requestId { get; set; }
        //public string partnerKey => ConfigurationManager.AppSettings["AEPSPartnerKey"];

        //public string p1 { get; set; }
        //public string p2 { get; set; }
        //public string p3 { get; set; }
        //public string p4 { get; set; }
        //public string p5 { get; set; }

        //public string p6 { get; set; }
        //public string p7 { get; set; }

        //public string p8 { get; set; }

        //public override string ToString()
        //{
        //    return Newtonsoft.Json.JsonConvert.SerializeObject(this);
        //}
        //public string ToEncryptedBody(SecurityMiddleware securityMiddleware)
        //{
        //    string encryptedString = securityMiddleware.EncryptRequest(this.ToString());
        //    if (ConfigurationManager.AppSettings[ConfigurationManager.AppSettings["UATEncryption"]] == "Y")
        //        return "{body: \"" + encryptedString + "\"}";
        //    else
        //        return encryptedString;

        //}

    }
}
