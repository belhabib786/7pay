﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank.Enitity.RequestEntity
{
    public abstract class BaseRequest
    {
        public abstract string actionName { get; }
        public string requestId { get; set; }
        public string partnerKey => ConfigurationManager.AppSettings["AEPSPartnerKey"];

        public string p1 { get; set; }
        public string p2 { get; set; }
        public string p3 { get; set; }
        public string p4 { get; set; }
        public string p5 { get; set; }

        public string p6 { get; set; }
        public string p7 { get; set; }

        public string p8 { get; set; }
        public string p9 { get; set; }
        public string p10 { get; set; }
        public string p11 { get; set; }
        public string p12 { get; set; }
        public string p13 { get; set; }
        public string p14 { get; set; }
        public string p15 { get; set; }
        public string p16 { get; set; }
        public string p17 { get; set; }
        public string p18 { get; set; }

        public override string ToString()
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(this);
        }

        public string ToEncryptedBody(SecurityMiddleware securityMiddleware)
        {
            string encryptedString = securityMiddleware.EncryptRequest(this.ToString());
            if (ConfigurationManager.AppSettings[ConfigurationManager.AppSettings["EncryptionRequire"]] == "true")
                return "{body: \"" + encryptedString + "\"}";
            else
                return encryptedString;
            
        }

    }
}
