﻿using AEPSAgentOnboardingLibrary.YesBank.Enitity.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank.Enitity.RequestEntity
{
    /// <summary>
    /// P1 - Mobile Number of agent for registration
    /// P2 - Agent FullName
    /// P3 - Agent PAN number
    /// P4 - Agent DOB
    /// P5 - Agent Gender
    /// P6 - Agent Email Address
    /// P7 - Agent Reference Id
    /// P8 - Agent Shop name
    /// </summary>
    public class CustomerCreationRequest : BaseRequest
    {
        public override string actionName { get => AEPSConstant.CUSTOMER_CREATION; }
     
    }
}
