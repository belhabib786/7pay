﻿using AEPSAgentOnboardingLibrary.YesBank.Enitity.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank.Enitity.ResponseEntity
{
    public class AadhaarWadhResponse : APIResponseEnity
    {
        public string wadh { get; set; }

        //code added by swapnal 
        public string kycToken { get; set; }
    }
}
