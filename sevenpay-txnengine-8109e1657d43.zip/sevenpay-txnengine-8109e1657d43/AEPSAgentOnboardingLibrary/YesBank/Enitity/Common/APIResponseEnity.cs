﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank.Enitity.Common
{
    public class APIResponseEnity
    {
        public string requestId { get; set; }
        public string status { get; set; }
        public string responseCode { get; set; }
        public string responseMessage { get; set; }

    }
}
