﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank.Enitity.Common
{
    public class AEPSConstant
    {
       public const string AGENT_CREATION = "CREATE_YM_AGENT";
       public const string CUSTOMER_CREATION = "CREATE_YM_CUSTOMER";
       public const string VALIDATE_OTP = "VALIDATE_OTP";
       public const string GET_AADHAAR_WADH = "GET_AADHAAR_WADH";
       public const string BIOMETRIC_KYC = "BIOMETRIC_KYC";


    }
}
