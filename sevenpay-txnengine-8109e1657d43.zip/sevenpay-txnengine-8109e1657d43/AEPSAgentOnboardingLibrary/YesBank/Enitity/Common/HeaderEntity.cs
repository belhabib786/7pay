﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace AEPSAgentOnboardingLibrary.YesBank.Enitity.Common
{
    public class HeaderEntity
    {
        public string token => ConfigurationManager.AppSettings["Token"];
        public string key => ConfigurationManager.AppSettings["AEPSAPIKey"];
        public string partner => ConfigurationManager.AppSettings["AEPSPartnerKey"];
        public string iv => ConfigurationManager.AppSettings["AEPSIV"];
        public bool isApiRequestEncrypted => true;

        public HttpWebRequest AppendHeader(HttpWebRequest httpWebRequest, string plainRequestJson, SecurityMiddleware singatureHelper)
        {


            httpWebRequest.Headers.Add("token", singatureHelper.GetHeaderToken(plainRequestJson));
            httpWebRequest.Headers.Add("key", singatureHelper.GetHeaderKey());
            httpWebRequest.Headers.Add("partner", singatureHelper.GetHeaderPartnerKey());
            httpWebRequest.Headers.Add("iv", singatureHelper.GetIV());            
            httpWebRequest.Headers.Add("isApiRequestEncrypted", ConfigurationManager.AppSettings[ConfigurationManager.AppSettings["EncryptionRequire"]]);
            return httpWebRequest;
        }

    }
}
