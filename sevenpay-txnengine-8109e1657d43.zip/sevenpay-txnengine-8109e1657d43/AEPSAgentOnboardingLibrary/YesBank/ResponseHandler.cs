﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank
{
    public class ResponseHandler
    {
        SecurityMiddleware _securityMiddleware;
        public ResponseHandler(SecurityMiddleware securityMiddleware)
        {
            _securityMiddleware = securityMiddleware;
        }
        public string DecryptResponse(string response)
        {
            return _securityMiddleware.DecryptString(response);
        }
    }
}
