﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank
{
    public class SecurityMiddleware
    {
        private readonly string isEncryptionRequire;
        private readonly string privateKey;
        private readonly string yblPublicKey;
        private readonly string partnerKey;
        private readonly string ivValue;
        private readonly string keyValue;
        private Random RNG = new Random();
        private static HashSet<string> Results = new HashSet<string>();
        AesManaged aesManaged;

        public SecurityMiddleware()
        {
            ivValue = Create16DigitString();
            keyValue = Create16DigitString();
            aesManaged = new AesManaged();
            aesManaged.KeySize = 128;
            aesManaged.Mode = CipherMode.CBC;
            aesManaged.Padding = PaddingMode.PKCS7;
            var _privateKeyPath = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory + @"..\..\..\", "Keys\\sevenpay_rsa_private_uat.cer");
            privateKey = File.ReadAllText(_privateKeyPath);
            aesManaged.IV = Encoding.UTF8.GetBytes(ivValue);
            aesManaged.Key = Encoding.UTF8.GetBytes(keyValue);

            isEncryptionRequire = ConfigurationManager.AppSettings[ConfigurationManager.AppSettings["EncryptionRequire"]];
            var _publicKeyPath = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory + @"..\..\..\", "Keys\\YBL_PUBLIC_KEY.cer");
            yblPublicKey = File.ReadAllText(_publicKeyPath);
            partnerKey = ConfigurationManager.AppSettings["AEPSPartnerKey"];

        }

        public string GetIV()
        {
            return ivValue;
        }

        public string GetKey()
        {
            return Convert.ToBase64String(aesManaged.Key);
        }

        public string GetHeaderToken(string data)
        {
            //string encrypted;
            //if (string.Equals(isEncryptionRequire, "Y"))
            //{
            //using (var rsa = RSA.Create())
            //{
            //    byte[] exponent = { 1, 0, 1 };
            //    var rsaParameters = new RSAParameters();
            //    rsaParameters.Modulus = Encoding.UTF8.GetBytes(privateKey);

            //    rsaParameters.Exponent = exponent;
            //    rsa.ImportParameters(rsaParameters);


            //    var dataToSign = Encoding.UTF8.GetBytes(data);
            //    var signature = rsa.SignData(dataToSign, HashAlgorithmName.SHA1, RSASignaturePadding.Pkcs1);
            //    return Convert.ToBase64String(signature);


            //}
            using (var rsa = new RSACryptoServiceProvider(1024))
            {
                rsa.FromXmlString(privateKey);
                var dataToSign = Encoding.UTF8.GetBytes(data);
                var signedData = rsa.SignData(dataToSign, SHA256.Create());
                var base64signedData = Convert.ToBase64String(signedData);
                return base64signedData;

            }
            //}
            //else
            //{
            //    encrypted = data;
            //}
            // Return encrypted data    
            //return encrypted;
        }

        public string GetHeaderKey()
        {


            using (var rsa = new RSACryptoServiceProvider(1024))
            {

                rsa.FromXmlString(yblPublicKey);
                var dataToSign = Encoding.UTF8.GetBytes(keyValue);
                var signedData = rsa.Encrypt(dataToSign, RSAEncryptionPadding.Pkcs1);
                var base64signedData = Convert.ToBase64String(signedData);
                return base64signedData;

            }


        }

        public string GetHeaderPartnerKey()
        {


            using (var rsa = RSA.Create())
            {
                rsa.FromXmlString(yblPublicKey);

                var keyToEncrypt = Encoding.UTF8.GetBytes(partnerKey);
                var encryptedKeyBytes = rsa.Encrypt(keyToEncrypt, RSAEncryptionPadding.Pkcs1);
                return Convert.ToBase64String(encryptedKeyBytes);
            }


        }






        public string EncryptRequest(string plainText)
        {
            string encryptedText;
            byte[] array;

            if (string.Equals(isEncryptionRequire, "true"))           
            {
                 

                ICryptoTransform encryptor = aesManaged.CreateEncryptor(this.aesManaged.Key, aesManaged.IV);

                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                        {
                            streamWriter.Write(plainText);
                        }

                        array = memoryStream.ToArray();
                        encryptedText = Convert.ToBase64String(array);
                    }
                }
            }
            else
            {
                encryptedText = plainText;
            }

            return encryptedText;
        }

        public string DecryptString(string cipherText)
        {
            string plainText;
            byte[] array;

            if (string.Equals(isEncryptionRequire, "true"))
            {
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                byte[] aesIV = UTF8Encoding.UTF8.GetBytes(ivValue);
                byte[] aesKey = UTF8Encoding.UTF8.GetBytes(keyValue);
                ICryptoTransform decryptor = aesManaged.CreateDecryptor(aesKey, aesIV);
                using (MemoryStream ms = new MemoryStream(cipherBytes))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    using (StreamReader reader = new StreamReader(cs))
                        plainText = reader.ReadToEnd();
                }
            }
            else
            {
                plainText = cipherText;
            }


            return plainText;
        }
        private string Create16DigitString()
        {
            var builder = new StringBuilder();
            while (builder.Length < 16)
            {
                builder.Append(RNG.Next(10).ToString());
            }
            return builder.ToString();
        }

    }
}
