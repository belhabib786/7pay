﻿using AEPSAgentOnboardingLibrary.YesBank.Enitity.Common;
using AEPSAgentOnboardingLibrary.YesBank.Enitity.Model;
using AEPSAgentOnboardingLibrary.YesBank.Enitity.ResponseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEPSAgentOnboardingLibrary.YesBank
{
    public class AEPSRequestProcessor
    {
        APIHandler apiHandler;
        public AEPSRequestProcessor()
        {
            apiHandler = new APIHandler();
        }
        public APIResponseEnity ProcessRequest(AEPSRequestModel request)
        {

            return Process(request);

        }

        APIResponseEnity Process(AEPSRequestModel requestModel)
        {
            Enum.TryParse(requestModel.RequestType, true, out AESPRequestType requestType);

            AEPSApiRequestFactory requestFactory = new AEPSApiRequestFactory(requestType);

            switch (requestType)
            {
                case AESPRequestType.AGENTCREATION:
                    {

                        var responseObject = apiHandler.ProcessRequest<AgentCreationResponse>(requestFactory.GetRequest(requestModel));
                        return responseObject;
                    }
                case AESPRequestType.CUSTOMERCREATION:
                    {

                        return apiHandler.ProcessRequest<CustomerCreationResponse>(requestFactory.GetRequest(requestModel));
                    }
                case AESPRequestType.OTPVALIDATION:
                    {

                        return apiHandler.ProcessRequest<ValidateOTPResponse>(requestFactory.GetRequest(requestModel));
                    }
                case AESPRequestType.AADHAARWADH:
                    {

                        return apiHandler.ProcessRequest<AadhaarWadhResponse>(requestFactory.GetRequest(requestModel));
                    }
                case AESPRequestType.BIOMETRICKYC:
                    {

                        return apiHandler.ProcessRequest<AadhaarBiometricKYCResponse>(requestFactory.GetRequest(requestModel));
                    }
            }

            throw new NotImplementedException(); ;
        }
    }
}
