﻿using AEPSAgentOnboardingLibrary.YesBank.Enitity.Common;
using AEPSAgentOnboardingLibrary.YesBank;
using AEPSAgentOnboardingLibrary.YesBank.Enitity.Model;
using AEPSAgentOnboardingLibrary.YesBank.Enitity.ResponseEntity;
using System.Text.Json.Nodes;
using Newtonsoft.Json;
using System.Globalization;

namespace AEPSAgentOnboardingLibrary
{
    public class AEPSFactory
    {
        public string InitOnboarding(AEPSRequestModel entity)
        {
            try
            {
                var _dob = entity.DateOfBirth.ToString().Split('/');

                AEPSRequestProcessor aEPSRequestProcessor = new AEPSRequestProcessor();
                AEPSRequestModel aepsRequestModel = new();

                aepsRequestModel.RequestType = "AGENTCREATION";
                aepsRequestModel.RequestId = Guid.NewGuid().ToString();// "65881153687949350";
                aepsRequestModel.MobileNumber = entity.MobileNumber; // "8080607324";
                aepsRequestModel.FullName = entity.FullName; // "VISHAL SHARMA";
                aepsRequestModel.AgentPANNumber = entity.AgentPANNumber; // "OLKKP1393O";

                /*
                aepsRequestModel.DateOfBirth = new DateTime(int.Parse(entity.YearOfBirth.ToString()),
                                            entity.MonthOfBirth.ToString().Length == 2 ? int.Parse(entity.MonthOfBirth.ToString()) : int.Parse(entity.MonthOfBirth.ToString()), 
                                            int.Parse(entity.DayOfBirth.ToString())); //_dob[2]), int.Parse(_dob[1]), int.Parse(_dob[0]) //1985, 11, 12
                
                */

                //aepsRequestModel.DateOfBirth = DateTime.Parse(entity.DateOfBirth.Value.ToString("d", new CultureInfo("ja-JP"))); //datetime.ToString("d", new CultureInfo("ja-JP")); //new DateTime(1985, 11, 12);
                aepsRequestModel.DateOfBirth = new DateTime((int)entity.YearOfBirth,
                                                            (int)entity.MonthOfBirth,
                                                            (int)entity.DayOfBirth);

                aepsRequestModel.Email = entity.Email; // "testemailID@gmail.com";
                aepsRequestModel.AgentReferenceId = entity.AgentPANNumber; // "AGENT0011";
                aepsRequestModel.AgentShopName = entity.AgentShopName; // "ShopName01";
                aepsRequestModel.Gender = "M";
                aepsRequestModel.CustomerTitle = "Mr";
                aepsRequestModel.CustomerPANNumber = entity.AgentPANNumber; //"OLKKP1393O";
                aepsRequestModel.NonAgriculturalIncome = 9999;
                aepsRequestModel.CustomerAddress = entity.CustomerAddress; // "Test Address";

                APIResponseEnity agentCreationResponse = aEPSRequestProcessor.ProcessRequest(aepsRequestModel);
                var agentCreationMappedResponse = (agentCreationResponse as AgentCreationResponse);
                return JsonConvert.SerializeObject(agentCreationMappedResponse);
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
        }

        public string OTPValidation(AEPSRequestModel entity)
        {
            try
            {
                AEPSRequestProcessor aEPSRequestProcessor = new AEPSRequestProcessor();
                AEPSRequestModel aepsRequestModel = new();

                //aepsRequestModel.RequestType = "AGENTCREATION";
                //aepsRequestModel.RequestId = "65881153687949350";
                aepsRequestModel.MobileNumber = entity.MobileNumber; // "9853855529"; // "8080607324";
                //aepsRequestModel.FullName = "VISHAL SHARMA";
                //aepsRequestModel.AgentPANNumber = "OLKKP1393O";
                //aepsRequestModel.DateOfBirth = new DateTime(1985, 11, 12);
                //aepsRequestModel.Email = "testemailID@gmail.com";
                //aepsRequestModel.AgentReferenceId = "AGENT0011";
                //aepsRequestModel.AgentShopName = "ShopName01";
                //aepsRequestModel.Gender = "M";
                //aepsRequestModel.CustomerTitle = "Mr";
                //aepsRequestModel.CustomerPANNumber = "OLKKP1393O";
                //aepsRequestModel.NonAgriculturalIncome = 9999;
                //aepsRequestModel.CustomerAddress = "Test Address";

                aepsRequestModel.RequestType = "OTPVALIDATION";
                aepsRequestModel.RequestId = Guid.NewGuid().ToString();  //"65881153687949351";
                aepsRequestModel.OTPToken = entity.OTPToken; //agentCreationMappedResponse.otpToken;
                aepsRequestModel.OTP = entity.OTP; // "111111";

                APIResponseEnity validateOTPResponse = aEPSRequestProcessor.ProcessRequest(aepsRequestModel);

                //code added by swapnal to check the errors
                if(validateOTPResponse.status == "ERROR")
                {
                    return JsonConvert.SerializeObject(validateOTPResponse);
                }

                var _validateOTPResponse = (validateOTPResponse as ValidateOTPResponse);

                //code for aadhaarwadh
                aepsRequestModel.RequestType = "AADHAARWADH";
                //code added by swapnal as missing parameter
                aepsRequestModel.MobileNumber = entity.MobileNumber; // "9853855529"; // "8080607324";
                aepsRequestModel.RequestId = Guid.NewGuid().ToString();  //"65881153687949352";
                aepsRequestModel.KYCToken = _validateOTPResponse.kycToken;
                aepsRequestModel.AgentReferenceId = entity.AgentReferenceId;

                var wadhResponse = aEPSRequestProcessor.ProcessRequest(aepsRequestModel);
                Console.WriteLine(wadhResponse);
                if (wadhResponse.status == "ERROR")
                {
                    return JsonConvert.SerializeObject(wadhResponse);
                }

                var _wadhResponse = (wadhResponse as AadhaarWadhResponse);
                _wadhResponse.kycToken = _validateOTPResponse.kycToken;

                return JsonConvert.SerializeObject(_wadhResponse);
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
        }

        public string BioMetricValidation(AEPSRequestModel entity)
        {
            try
            {
                AEPSRequestProcessor aEPSRequestProcessor = new AEPSRequestProcessor();
                AEPSRequestModel aepsRequestModel = new();

                //code for biometric validation using pidblock
                aepsRequestModel.RequestId = Guid.NewGuid().ToString();  //"65881153687949353";
                aepsRequestModel.RequestType = "BIOMETRICKYC";

                //code added by swapnal
                aepsRequestModel.AgentReferenceId = entity.AgentReferenceId; 
                aepsRequestModel.MobileNumber = entity.MobileNumber; 

                aepsRequestModel.AadhaarNumber = entity.AadhaarNumber; // "219767542082"; // "883036357157";
                aepsRequestModel.TypeOfAadhaar = "0";

                aepsRequestModel.BiometricDeviceSerialNumber = entity.BiometricDeviceSerialNumber; // "3284642";
                aepsRequestModel.FingerData = entity.FingerData; // "6";
                aepsRequestModel.WADHValue = entity.WADHValue; // _wadhResponse.wadh;
                aepsRequestModel.BiometricDeviceType = "6";
                aepsRequestModel.Consent = "Y";
                aepsRequestModel.KYCType = "EKYC";
                aepsRequestModel.CapturedTemplate = "null";
                aepsRequestModel.Purpose = "Authentication";

                //code added by swapnal for bio metric pid block
                var _biometricxml = @"<Data type=""X"">MjAyMy0wMy0xNlQxODozNjo0NmzXvRZHlbdhdkRrJ8n3ZtgdMPxVN/68VeFzC4yZ9LXB8yVk/HFf8Lc653URCXdqQ3FoX6IifPyT68k4FkdZqyfuuWN7KcJAaNxyLMmIkq5hnaHQuf+ZNTQ545RElBF8grjwug4VQEBtJey2gJvMYFBw2aJ3STv2hiFItxCGB4buCoPA6qelgJ6bHDvfkB6+96QiiVc5eB/WvjWIbk9F2vNXcMSQkwCE7WUAn2oimFl5Tu/5iZd+jqT2X5v3p5t9YBIb3xB67UQJ2dJPyEHeLdjzT+yTmUir93GdjayKMixM+T+coqz2o/SlfxPQdq9jCZYGfPgqDbTKnF3Fu+neh3svvN7KTOVrdIecGiquku9Y9X4i9s8kEHfzFHcu1Ced3b0LmAhwiN/W+TSjc/ZCP8cDRXZ5c1UQeuXGWk78ZKZzhFiTI3yVu4igmMNjPGpL9LQ4LWn7yw874RKoo7Hwg+MDFsBamEG2DNCd7qg0v+vk8PLpUZdyVpWuG8wbmZmHGLdJU2/spPzgu/R6Al4UEJMdjUDwxycemlhWRg0ivQ5GwyJ6SetE/XhCVTcVIwYQItVHVCT/EYBsks5LMHGqbUa22t9xH4G1paL4cgB40jgX3bezPR3XDLvZy4INKeLNIRvUTtHzXfxKX5sP7nCNc/YrTiDvOQowUTUlWBRLDUZs8Rv/MFAvyHfBD9INYXEmdfF/uZWqorZikIqYER5nqlqNSsJi0XhcikFP0e6eGNXlSSWJ1JvS7OKgs0tyGmxZJSdVHeEyHlnJzg4cQ0a091CnLjPH/kxtiyOYZkTHpJqvrlCngK1BABkT30x7s5SuG3WHB6/cqXW04EVV4f+83vHomeHx6Zh9oqMdKQ3rLHw8O3rPe7MsE/5zAaP1cW5kvHWNJey1Ze6AKXNbqD048oAPBuk6KPTlb16ofSZJVg5FOmIgKPUDSmyRfrFirYVQZAdJgWLA8W580n4yxnQg+5beCbpGpd55JOQg9kn6syWLqpiLkg4fqn4IaAFAeizvQnOml5bBB3Z4e1EkUzBp3Y0yIebahFYy4sFJ19MZEoKWJE5z+FBq+9YB6PPAvg+e1e1NU1Q+kmtu1SeJkZfftLZJXQd9IUTZJrCuwW5UYSssnyoxabssWhbfy3QaKF0L9o7IgO62y0snniF90m9frarwHh2TdfuVSEVdjPjR2N6U1Na1itehv6rR4wcTMLhv928DgQxf0EYJQbH2FQGlqU6Y1Jaqj9xouS2/rmDkPtE/O4Ocfk1NeTcHuj1f0LZntxx7zla1eRsSNuFgNcyIBuATu1zJ6naAZQYoyfY4ZRTFDas3AZ9dNAVCu9OtJAOK7fL8X/ETZIt24cEur8u6SXtkTVmhuEBsNz3zxReBD/D6Bo+pyEfL2b1C/lUQ28KATzb6O3g668cuY1KA6z+yZGOo54R06vjpXpkJFY2frt3LfTdqS8N/rYy0TIEq+KoU5sShA+LhrCjXCp8zZdYlLIb3HJMm7Y+kxlcUVLj/ycEeU67KBuK3nFiVEwonbgMaHCe6bLyvo9HbEDUwPujnJa0HnqT8H6J8i5SY6L7DgnpdpH2q1Z/fC10RyWAy5A28KmSXIxoIsCry+UHPnkNibJjMBBYfjKFbJMLxJS258AlMCv7bBIWvzgykKbMDZrkAfdr+IGxzQ3a7+qsEnDjLXrgtoEdF1rBUzrcm2R2EpUPSNPwoWu66HY0Q3sBP6LQIC35DjmB8wrrTy9E0NWsWTDEbu26HOmXjnhZ34RVZvx5wqSpyzkShkmek8xvNE6GfMPgAOr6c987MsevFL5gBUEm5E/x377s8t3Fm9G+sF0AucxOQ/bi071OX1fIqiil397+R0l3+vbXtLLpOLc57+ZugTcp6XaPXpR68MRAnwS4w26ZE4OJ/9grrc4KICOLW70gaMu2DbP3ye5N+BW1hMpwRZy7oGI/yJwmUpBMGjR57VZqYT4G4yxI48C15D0HcjX1HMEZeosf4xWP0VIMspiTVoGK4pxZOUTwoL/kuUHSSv2slNN1vHJFpsJyDqNUQmnnA7ETxK3OAx0enHGiFl5bgfDtdyhrdqCqaV3CUOACnvSU2ZlJZ9kvqV6ndlA+Kw6WSVf7RHPwtWGKcEoQfs/QqqFiuaHQnUw2SWEfKnJew0chgeARRNbPPAJCT8scPe2yTYPWBYbdn21ND45uO8ZODwLw1VLo2/pPQmPG7UJFcFJoHTLYrMnGIcIcFq1GsvRdJ6+cja2J/pkv8r362js4yXlJgPN0Zeji+46lqQIo9NrnRRR4v1oVlRoG+IOMWO3pCF9CJJlIS+zUx6bNiP4LCMFR8wzrrwg9pZ77+Y98WpChuJPrFYZtAtxycJHyizITafurvbBhevMFe+dIzzupzUk1fZKuHeyzr1Y6wfQ0HGByIsXEfqQWs5z+0/SQZLfk6DLKkadXGj9FwlqgLs962sw+X7lvDpbXkHf7TbmamA+S7O0vZzYqw62Atojn+JgvwrPb2IMov+7+R2wei6qy4fFV4qWtnAMOPGDqHPwzR/zUy8bBBg3Uxm4hLoRdt1xe9SRexBs7jPXhP314NS+oXVbfFEaGYg0sfC7Ws4z1FV5NqqcD8U28ug0n/jCwF4+sE69pZdfwZ0bLLucq42O+Ic3O7oGJWiu5XCK2wugQtGohwOTDOhblddyMK8FfwPn6g4cWIJ/3QGx0xuGyK2zH3lf/7VBD/KmzcyUlHKjCy5xc5RTr4ufQUTyWmE6UGhrcRdXkjzpeIOxTeJrCxM5Anjk9UyVBpAJzq1fnPcYw5/w9BqdlhyonpjJx4TH97LDxCAGufNnb4VaZiY7aN+cOScJbryJqUhI5rPkYBB+TsCe2+szkWA8t2Vr9zP6no+PGZ0DCgZGnA7Ws5n+h6M7V/MdWP1HjsQCu5xQSA+1+r54ftF2zVAF+BzO70J7sKyeMhdOT1oDmzue8KFRlk1gMjPpcQMPDo5AB+XJu7hNMecKoGvxFpYSKl/h2B+tQ6P6SQQXs7626V0s3PiUFUm4irUNMJgmGdu8hfInYMmOo3Iwr/f555OxPfC8dLC8KQZNGV/eWLC5Oc0PSSQ9gac9WHYN3Dd/oN36zcGezA8+jmEq+YsW5N/nKvppdw/Vf4xdSPfOc8YsKcg2d1ZuanWLJJ1BNDAqhhikH+sFKSlyoiaAT11kL1OAM/Qzlx8vOYAwDZyNiLgzUA01f1eF2szpz8v0ASvWJ39EArtX5IGVTflHjVCd6L3kFJL34v3BEak/RpFYdiMfj1GMzHwggu+k43Ztb+oTBtBSN1hu7i7V3mFWP49sg8AdoqP0/GrhvHH/d/tyhiVGQ+WymkeC8TFj4khW9i4rtkbG/5WUHubYzM9QwToTzbIEwuB89Xu5W0gx4TNVPkP/o10qH4ku9MPGPfISJY1peYuTtd2UEOODqrZ9RAWQb29grzJQLCD4tW3mv6GMiha48Us31v2G00cv5u2UXvSIQIiN2kiPYap7vHquiFYTC8yftsazEqBpZ0brCZiluB6VnZYeCpq96nMhowbwJzPHNjU5ia6KBw7wZJtTEgRAFovn9OkAQxRoBzg1VejDdrKRN08RzflyWyX3EK+Y+BUrOc8G92g8/szdhhADyyCj6Sx9EnaNrIlt53PMsQ+fY2cvMvVc1Me6DAF+AOwMJeuEQsTfA/02syPLnTNlcA2kDbytFI2p+6BE+ZSCHa7lVnYlhO6uCpvuQ08cgrPdL+tu3kZ70DDT2h8xzpKmjn2EqMY9qswAv/6pn8AQ6MMxw4UYK6H8Q+uZgb7l7uF1TLeKmROTk+iMt2X4N5BOR1EiQn2/Bikcds7Kh5og2rgux9jnzY+DJH2x9fnFddEUdX3tf57+edYR0i2gLUO3mI/hc/TYFd8JlsDqMI41QherdTJzRghjNS0rEmMdyGl+aHEtcDonQKcR5keRI5WGWHzwiEsqEytf1agEpekdPNrRH6CrXlp
E/resultData:    <DeviceInfo dc=""f71bf494-9938-43df-99ac-40f11bb68fc7"" dpId=""MANTRA.MSIPL"" mc=""MIIEGjCCAwKgAwIBAgIGAYbp2zFfMA0GCSqGSIb3DQEBCwUAMIHqMSowKAYDVQQDEyFEUyBNYW50cmEgU29mdGVjaCBJbmRpYSBQdnQgTHRkIDcxQzBBBgNVBDMTOkIgMjAzIFNoYXBhdGggSGV4YSBvcHBvc2l0ZSBHdWphcmF0IEhpZ2ggQ291cnQgUyBHIEhpZ2h3YXkxEjAQBgNVBAkTCUFobWVkYWJhZDEQMA4GA1UECBMHR3VqYXJhdDEdMBsGA1UECxMUVGVjaG5pY2FsIERlcGFydG1lbnQxJTAjBgNVBAoTHE1hbnRyYSBTb2Z0ZWNoIEluZGlhIFB2dCBMdGQxCzAJBgNVBAYTAklOMB4XDTIzMDMxNjA5NDMyMVoXDTIzMDQxNTA5NTgyMVowgbAxJDAiBgkqhkiG9w0BCQEWFXN1cHBvcnRAbWFudHJhdGVjLmNvbTELMAkGA1UEBhMCSU4xEDAOBgNVBAgTB0dVSkFSQVQxEjAQBgNVBAcTCUFITUVEQUJBRDEOMAwGA1UEChMFTVNJUEwxHjAcBgNVBAsTFUJpb21ldHJpYyBNYW51ZmFjdHVyZTElMCMGA1UEAxMcTWFudHJhIFNvZnRlY2ggSW5kaWEgUHZ0IEx0ZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKqC5ENiv/cdgv2rttgXvpLDr5BTYMNyZa0/HcqgcLxh/RrjndBgdf/UcG89chxzNfMlks8grqXeUg8wY2yfJGxd+5/iHUOXicyBA4xy8yN6WBqEkYuyojEUwPllKeyawlRTYWCtdZyRkebDEZD9xOJs4oFP9QfDQDMFer+wWMGnG7JVHrBkoiewCgXDvOFAjHzzL5i9Jz54Tt+dL7ZOeaHAB1YFjH38NQPnKVFGKuqwDGHwd/aF7rIcb1RwE31Se2atddGY0cKOHgGSKihlaEN20HADqX9VwsxhTAsPvicTcyyQE/fRuWEq3ZExRk0YfehhUdQ4gxka+ecMpZWtf38CAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAPRW1dxGdChkKb0CWV/mTWP2WnvJ4QcVSxbHeDIv1EIh3I/HCJ3rcPALeGacqjg3bQi7HY3c+tMRosr3KJQyIypJCE5DmNMgg6+g2DYWSuLakhccoQtplSTjREXHc8qTM90HHVErNjTLuapqPSdDtv8amx/PIi73xobc+c8/fg7huUT/ndP7uStqFo73hhFyfGrDisv3BcRAcuLOq/L3HIb7vZWCXrewX3c+1/5f32fjjEw/EGVn7Fe5HScPdkIv1V/57QKX+RKJvl6J/Wag4OyVo1GQqYQlThNMHXqg6CWdOgPcGxTCyVN/lDhAhjkJ/fIPH7nGwzH2tXOCM/1ggIA=="" mi=""MFS100"" rdsId=""MANTRA.AND.001"" rdsVer=""1.0.8""><additional_info><Param name=""srno"" value=""3284642""/><Param name=""sysid"" value=""7cb4092666f43c30""/><Param name=""ts"" value=""2023-03-16T18:36:48+05:30""/></additional_info></DeviceInfo><Hmac>sqyHVv3pzyV6GOQe557EtqG3jyFV55DtVjn5zulyzaeOl4MHfIoMH7x0bUeERned</Hmac><Resp errCode=""0"" errInfo=""Capture Success"" fCount=""1"" fType=""2"" iCount=""0"" iType=""0"" nmPoints=""44"" pCount=""0"" pType=""0"" qScore=""87""/><Skey ci=""20250923"">afQYErKvKcI38wmR7SLCqXTnv/DyIpDwWgid9TTD+IPtLlx6FgYRlTxxXkEGqWI25hJHw/zzPl1FtIFAHltaETyRihZ3oGdHhK3kwteXVIcFY28ur6IZEbmSezb4j83F9kydXHjLT0K/Zbp5mip+Bv8xKB048YGVmAoliMRPVjsF0havN8502fkHWTBc0OkiglY/8qfg3cI5He1vzPSFNNgs/lPf3nLSSOiFsizD11TWGYXkDOU54bYdGD//cs8x04IfQ+gH+kp3oqT5o9t4hGD8wjaBhUkabDPPTTknAAeRj9js3xLqaRsEzbVfjSFK7jkjLv3TT7YsuPQfi8wAAg==</Skey></PidData>";

                //Byte[] buffer = System.Text.Encoding.Unicode.GetBytes(_biometricxml); //Convert.ToBase64String(_biometricxml);

                //aepsRequestModel.DevicePIDXml = Convert.ToBase64String(buffer);
                aepsRequestModel.DevicePIDXml = _biometricxml; //entity.DevicePIDXml; //


                //aepsRequestModel.WADHValue = response.

                aepsRequestModel.KYCToken = entity.KYCToken; // _validateOTPResponse.kycToken;

                var bioResponse = aEPSRequestProcessor.ProcessRequest(aepsRequestModel);
                //Console.WriteLine(bioResponse);
                return JsonConvert.SerializeObject(bioResponse);
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
        }
    }
}