﻿using Confluent.Kafka;
using DMTLibrary.Fino;
using DMTLibrary.ZoopOne;
using Engine.Events.DMT;
using Logger;
using Mapster;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using System.Text.Json;

namespace DMT
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World from DMT");

            var serviceProvider = new ServiceCollection()
                // Add your services here..
                .AddSingleton<ICustomLogger, CustomLogger>()
                .BuildServiceProvider();
            // Now get Your Services like this
            var demoService = serviceProvider.GetRequiredService<ICustomLogger>();

            //code to read the configuration from appsetting.json
            IConfiguration config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.UAT.json")
                .AddEnvironmentVariables()
                .Build();

            // Get values from the config, given their key and their target type.
            ProducerConfig pconfig = config.GetRequiredSection("ProducerConfig").Get<ProducerConfig>();
            ConsumerConfig cconfig = config.GetRequiredSection("ConsumerConfig").Get<ConsumerConfig>();
            

            DMTProcess dMTProcess = new DMTProcess(pconfig, cconfig);
            dMTProcess.Init();

        }
    }

    public class DMTProcess
    {
        private static ProducerConfig _pconfig;
        private static ConsumerConfig _cconfig;
        //logger 
        private readonly ICustomLogger _logger;

        public DMTProcess(ProducerConfig pconfig, ConsumerConfig cconfig)
        {
            _cconfig = cconfig;
            _pconfig = pconfig;
            _logger = new CustomLogger("PreDMT");
        }

        public void Init()
        {
			//code added by swapnal and running on different thread for health checkup
			Task.Factory.StartNew(() => new HealthCheckService(), TaskCreationOptions.PreferFairness);

			//DMT queue init );
			using (var _consumer = new ConsumerBuilder<Ignore, string>(_cconfig).Build())
            {
                _consumer.Subscribe("DMTPreTransaction");

                CancellationTokenSource cts = new CancellationTokenSource();
                Console.CancelKeyPress += (_, e) => {
                    e.Cancel = true; // prevent the process from terminating.
                    cts.Cancel();
                };

                try
                {
                    while (true)
                    {
                        try
                        {
                            var _message = _consumer.Consume(cts.Token);
                            Console.WriteLine($"Consumed message '{_message.Message.Value}' at: '{_message.TopicPartitionOffset}'.");
                            _consumer.Commit(_message);
                            _logger.LogInfo("Request : " + _message.Message.Value);
                            //code to write the logs

                            //code commented by swapnal
                            //var _dmtModel = _message.Message.Value;
                            var _dmtModel = JsonSerializer.Deserialize<DMTPreTransactionCreatedEvent>(_message.Message.Value);

                            Console.WriteLine(_dmtModel);

                            if (_dmtModel == null) return;

                            //code to process the request via fino
                            FinoPaymentRequestModel finoPaymentRequestModel = new FinoPaymentRequestModel
                            {
                                ClientUniqueID = _dmtModel.TransactionId.ToString(),
                                CustomerMobileNo = long.Parse(_dmtModel.request.transactionInfo.transactionData.p_custmobno),
                                CustomerName = _dmtModel.request.transactionInfo.transactionData.p_customername,
                                BeneIFSCCode = _dmtModel.request.transactionInfo.transactionData.p_beneifsccode,
                                BeneAccountNo = _dmtModel.request.transactionInfo.transactionData.p_beneaccountno,
                                BeneName = _dmtModel.request.transactionInfo.transactionData.p_benname,
                                Amount = int.Parse(_dmtModel.finalrequest.p_transactionvalue.ToString()),
                                RFU1 = string.Empty,
                                RFU2 = string.Empty,
                                RFU3 = string.Empty
                            };

							_logger.LogInfo("fino Request : " + JsonSerializer.Serialize(finoPaymentRequestModel));

							FinoDMTProcess finoDMTProcess = new FinoDMTProcess();
                            var response = finoDMTProcess.ProcessPaymentRequest(_dmtModel.request.transactionInfo.transactionData.p_transactiontype, finoPaymentRequestModel);

                            _logger.LogInfo("fino Response : " + response);

                            Console.WriteLine("");
                            Console.WriteLine("");
                            Console.WriteLine("");
                            Console.WriteLine("");
                            Console.WriteLine("****** Response from fino *************");
                            Console.WriteLine(response);


                            if (!string.IsNullOrEmpty(response))
                            {
                                var _responseModel = JsonSerializer.Deserialize<FinoTransactionResponseModel>(response);

                                var dMTPreTransactionUpdatedEvent = _dmtModel.Adapt<DMTPreTransactionUpdatedEvent>();

                                dMTPreTransactionUpdatedEvent.responseModel = JsonSerializer.Deserialize<FinoTransactionResponseModel>(response);

                                //dMTPreTransactionUpdatedEvent.responseModel = new FinoTransactionResponseModel();
                                //dMTPreTransactionUpdatedEvent.responseModel.ResponseCode = _responseModel.ResponseCode;
                                //dMTPreTransactionUpdatedEvent.responseModel.MessageString = _responseModel.MessageString;
                                //dMTPreTransactionUpdatedEvent.responseModel.DisplayMessage = _responseModel.DisplayMessage;
                                //dMTPreTransactionUpdatedEvent.responseModel.RequestID = _responseModel.RequestID;
                                //dMTPreTransactionUpdatedEvent.responseModel.ClientUniqueID = _responseModel.ClientUniqueID;
                                //dMTPreTransactionUpdatedEvent.responseModel.ResponseData = _responseModel.ResponseData;


                                dMTPreTransactionUpdatedEvent.UpdateedDate = DateTime.Now;
                                dMTPreTransactionUpdatedEvent.MobileToken = _dmtModel.MobileToken;


								var _updatedEventResponse = JsonSerializer.Serialize(dMTPreTransactionUpdatedEvent);

                                //code commented by swapnal need to add post transaction method
                                TransactionsQueueReceiveCompleted(_updatedEventResponse);
                            }
                        }
                        catch (ConsumeException ex)
                        {
							//code added by swapnal
							_logger.LogInfo("Exception:" + ex.Message.ToString());
							Console.WriteLine($"Error occured: {ex.Error.Reason}");
                        }
                    }
                }
                catch (OperationCanceledException ex)
                {
					//code added by swapnal
					_logger.LogInfo("Exception:" + ex.Message.ToString());
					// Close and Release all the resources held by this consumer
					Console.WriteLine("Error " + ex.Message.ToString());
                    _consumer.Close();
                }
            }
            //End Code Accounting queue init

            while (Console.ReadKey().Key != ConsoleKey.Q)
            {
                //Console.WriteLine("Transaction Processing Engine exits gracefully.......");
            }
        }

        private void TransactionsQueueReceiveCompleted(string message)
        {
            object LockObject = new object();


            Console.WriteLine("Hey Delegate called !!!!!!!!!!!!!!!!");
            try
            {
                lock (LockObject)
                {
                    //Thread.Sleep(5);

                    using (var _publish = new ProducerBuilder<Null, string>(_pconfig).Build())
                    {
                        try
                        {
                            Console.WriteLine(message);
                            //var _message = _publish.ProduceAsync("DMTPostTransaction", new Message<Null, string> { Value = message });
                            _publish.Produce("DMTPostTransaction", new Message<Null, string> { Value = message }, null);
                            //Console.WriteLine($"Delivered '{_message.Result.Value}' to '{_message.Result.TopicPartitionOffset}'");
                            _publish.Flush();
                            //Thread.Sleep(50000);
                            Console.WriteLine("We are out of sleep - Thread.Sleep(50000)");
                        }
                        catch (ProduceException<Null, string> e)
                        {
							//code added by swapnal
							_logger.LogInfo("Exception:" + e.Message.ToString());
							Console.WriteLine($"Delivery failed: {e.Error.Reason}");
                        }
                    }
                }
            }
            catch (Exception exception)
            {
				//code added by swapnal
				_logger.LogInfo("Exception:" + exception.Message.ToString());
				Console.WriteLine("ERROR  { QueueReceiveCompleted }-> " + exception.Message);
            }
        }
    }
}

