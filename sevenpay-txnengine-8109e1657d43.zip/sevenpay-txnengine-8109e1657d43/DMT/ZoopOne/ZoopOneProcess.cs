﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DMT.ZoopOne
{
    public class ZoopOneProcess
    {
        
        public string ProcessRequest(string url, string requestdata)
        {
            try
            {
                //code added by swapnal to deal with https request
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Ssl3 | (SecurityProtocolType)0x00000C00;

                //code by swapnal to process with http request
                WebRequest request = WebRequest.Create(url); //"https://test.zoop.one/api/v1/in/financial/bav/lite" 
                                                          // Set the Method property of the request to POST.
                request.Method = "POST";

                request.Headers.Add("api-key", "9KBMVY3-8VF4CN2-G7CGP42-TY9Z8FE");
                request.Headers.Add("app-id", "6318bb8c3e37b5001d871f00");


                byte[] byteArray = Encoding.UTF8.GetBytes(requestdata);
                //request.ContentLength = byteArray.Length;

                // Set the ContentType property of the WebRequest.
                request.ContentType = "application/json";

                // Get the request stream.
                Stream dataStream = request.GetRequestStream();

                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);

                // Close the Stream object.
                dataStream.Close();

                // Get the response.
                WebResponse response = request.GetResponse();

                // Display the status.
                Console.WriteLine(((HttpWebResponse)response).StatusDescription);

                // Get the stream containing content returned by the server.
                dataStream = response.GetResponseStream();

                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);

                // Read the content.
                string responseFromServer = reader.ReadToEnd();

                // Display the content.
                Console.WriteLine(responseFromServer);

                // Clean up the streams.
                reader.Close();
                dataStream.Close();

                //code added by swapnal
                return responseFromServer;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                throw;
            }
        }
    }
}
