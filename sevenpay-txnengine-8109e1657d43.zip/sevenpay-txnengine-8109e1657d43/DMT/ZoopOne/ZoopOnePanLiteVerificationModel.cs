﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMT.ZoopOne
{
    public class ZoopOnePanLiteVerificationModel
    {
        public string customer_pan_number { get; set; }
        public string consent { get; set; }
        public string consent_text { get; set; }
    }
}
