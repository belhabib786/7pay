﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace DMT.Fino
{
    public class FinoDMTProcess
    {
        private readonly string baseurl = "http://103.1.112.205:8024/PaymentBankDMTPublic/UIService.svc/FinoMoneyTransactionApi/";

        public string ProcessPaymentRequest(int paymentType, FinoPaymentRequestModel model)
        {
            try
            {
                string response = string.Empty;
                var _model = JsonSerializer.Serialize(model);
                Console.WriteLine(_model);
                var _encRequest = EncryptDecrypt.OpenSSLEncrypt(_model, "aac77ecb-3325-4226-9977-32ffadb2e5e1");

                switch (paymentType)
                {
                    case 2:
                        Console.WriteLine(_encRequest);
                        response =  Process("neftrequest", "\"" + _encRequest + "\"");
                        break;
                    case 3:
                        Console.WriteLine(_encRequest);
                        response = Process("impsrequest", "\"" + _encRequest + "\"");
                        break;
                }
                return response;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public string ProcessRequest(FinoStatusCheckModel model)
        {
            string response = string.Empty;
            try
            {
                var _model = JsonSerializer.Serialize(model);
                Console.WriteLine(_model);
                var _encRequest = EncryptDecrypt.OpenSSLEncrypt(_model, "aac77ecb-3325-4226-9977-32ffadb2e5e1");
                response = Process("txnstatusrequest", "\"" + _encRequest + "\"");
                return response;
            }
            catch (Exception)
            {
                return response;
            }
        }

        private string GenerateHeader()
        {
            var jsonHeader = new FinoJsonHeader();
            Console.WriteLine(JsonSerializer.Serialize(jsonHeader));

            string _encHeader = string.Empty;
            var _plainHeader = JsonSerializer.Serialize(jsonHeader);
            _encHeader = EncryptDecrypt.OpenSSLEncrypt(_plainHeader, "982b0d01-b262-4ece-a2a2-45be82212ba1");

            //var _decHeader = DecryptText(_encHeader, "982b0d01-b262-4ece-a2a2-45be82212ba1");

            Console.WriteLine(_encHeader);
            //Console.WriteLine(_decHeader);
            return _encHeader;
        }

        private string Process(string requestType, string transaction_request)
        {
            string responseFromServer = string.Empty;
            string _baseURL = baseurl + requestType;
            Console.WriteLine(baseurl + _baseURL);
            try
            {
                //Code To send webRequest
                // Create a request using a URL that can receive a post. 
                var request = (HttpWebRequest)WebRequest.Create(_baseURL); //Request procees on Pay World
                //Set Header
                var _headerdata = GenerateHeader();
                request.Headers.Add("Authentication", _headerdata);
                request.Headers.Add("Content-Type", "application/json");
                // Set the Method property of the request to POST.
                request.Method = "POST";
                // Create POST data and convert it to a byte array.
                string postData = transaction_request;
                byte[] byteArray = Encoding.UTF8.GetBytes(postData);

                // Set the ContentType property of the WebRequest.
                request.ContentType = "application/json"; //charset=utf-8"

                // Set the ContentLength property of the WebRequest.
                request.ContentLength = byteArray.Length;
                // Get the request stream.
                Stream dataStream = request.GetRequestStream();
                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.
                dataStream.Close();
                // Get the response.
                WebResponse response = request.GetResponse();
                // Display the status.
                //Console.WriteLine(((HttpWebResponse)response).StatusDescription);
                // Get the stream containing content returned by the server.
                dataStream = response.GetResponseStream();
                // Open the stream using a StreamReader for easy access.
                var reader = new StreamReader(dataStream);
                // Read the content.
                responseFromServer = reader.ReadToEnd();
                // Clean up the streams.
                reader.Close();
                dataStream.Close();
                response.Close();
                //End Code To send webRequest
                Console.WriteLine(responseFromServer);
                return responseFromServer;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return responseFromServer;
        }
    }
}
