﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMT.Fino
{
    public class FinoJsonHeader
    {
        public int ClientId { get; set; } = 185;
        public Guid AuthKey { get; set; } = Guid.Parse("0f2dbdc5-a924-4d2d-b5e6-fdb42c1ae7da");
    }
}
