﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheManagement
{
	public interface ICacheHelper
	{
		public bool PushData(string key, string value);
		public string PullData(string key);
		public bool RemoveData(string key);
	}
}
