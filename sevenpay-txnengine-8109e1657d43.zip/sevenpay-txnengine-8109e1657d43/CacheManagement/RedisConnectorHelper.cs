﻿using StackExchange.Redis;

namespace CacheManagement
{
	public class RedisConnectorHelper : ICacheHelper
	{
		private Lazy<ConnectionMultiplexer> lazyConnection;
		public RedisConnectorHelper()
		{
			lazyConnection = new Lazy<ConnectionMultiplexer>(() =>
			{
				//"endpoint,password=password,ConnectTimeout=10000"
				return ConnectionMultiplexer.Connect("uat-redis.tech-sevenpay.com:6379,password=HamW4WfXrB82UaFq,ConnectTimeout=10000");
			});
		}

		private ConnectionMultiplexer Connection
		{
			get
			{
				return lazyConnection.Value;
			}
		}

		public bool PushData(string key, string value)
		{
			try
			{
				if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(value))
					return false;

				var cache = Connection.GetDatabase();
				cache.StringSet(key, value);
				return true;
			}
			catch (Exception ex)
			{
				return false;
			}
		}

		public string PullData(string key)
		{
			try
			{
				if (string.IsNullOrEmpty(key))
					return string.Empty;

				var cache = Connection.GetDatabase();
				var value = cache.StringGet(key);
				return value;
			}
			catch (Exception ex)
			{
				return string.Empty;
			}
		}

		public bool RemoveData(string key)
		{
			try
			{
				if (string.IsNullOrEmpty(key))
					return false;

				var cache = Connection.GetDatabase();
				return cache.KeyDelete(key);
			}
			catch (Exception ex)
			{
				return false;
			}
		}
	}
}