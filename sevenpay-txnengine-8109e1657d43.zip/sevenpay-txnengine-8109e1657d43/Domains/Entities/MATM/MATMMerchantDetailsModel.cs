﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.MATM
{
    public class MATMMerchantDetailsModel
    {
        public string deviceserialno { get; set; }
        public int supplierid { get; set; }
        public string merchantkey { get; set; }
        public string refparam1 { get; set; }
        public string refparam2 { get; set; }
        public string refparam3 { get; set; }
    }
}
