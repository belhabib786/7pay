﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.MATM
{
    public class MATMPostTransactionRequestModel
    {

        public Int16 p_intmatmtxnid { get; set; }
        public string p_strsupptxnnumber { get; set; }
        public Int16 p_intuserid { get; set; }
        public int p_inttxnstatus { get; set; }
        public string p_strresdatetime { get; set; }
        public string p_strresponsecode { get; set; }
        public string p_strresponsemessage { get; set; }
        public string p_strrrn { get; set; }
        public string p_strtransactionstatus { get; set; }
        public string p_strcardbrand { get; set; }
        public string p_strcardholdername { get; set; }
        public string p_strcardnumber { get; set; }
        public string p_strcardtype { get; set; }
        public string p_strcurrentbalance { get; set; }
        public string p_strledgerbalance { get; set; }
        public string p_strmerchantid { get; set; }
        public string p_strmarchantrefno { get; set; }
        public string p_strpaymentmethod { get; set; }
        public string p_strterminalserialno { get; set; }
        public string p_strtransationdatentime { get; set; }
        public string p_strreferenceno { get; set; }
        public string p_strdeviceserialno { get; set; }
        public string p_strmerchantkey { get; set; }
        public int p_intcreator { get; set; }
        public string p_strip_address { get; set; }
    }
}
