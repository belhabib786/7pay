﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Common
{
    public class BaseEntity
    {
        public string? TransactionId { get; set; }
        public string? IPAddress { get; set; }
        //public DateTime CreatedOn { get; set; }
        //public DateTime UpdatedOn { get; set; }
        public int UserCode { get; set; }
    }
}
