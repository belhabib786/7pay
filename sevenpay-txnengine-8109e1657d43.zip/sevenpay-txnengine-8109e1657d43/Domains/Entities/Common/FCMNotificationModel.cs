﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Common
{
    public class FCMNotificationModel
    {
        public string to { get; set; }
        public TransactionNotificationModel data { get; set; }
    }
}
