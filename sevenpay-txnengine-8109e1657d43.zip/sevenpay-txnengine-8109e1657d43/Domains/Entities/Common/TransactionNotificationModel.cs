﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Common
{
    public class TransactionNotificationModel
    {
        public long transactionId { get; set; }
        public string responseCode { get; set; }
        public string serviceName { get; set; }
        public string header { get; set; }
        public double amount { get; set; } 
        public string logourl { get; set; } 
        public string operatorReferenceId { get; set; }
        public string message { get; set; }
        public DateTime updatedOn { get; set; }
		//code added by swapnal to deal with mobile notification
		public string MobileToken { get; set; }
	}
}
