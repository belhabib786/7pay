﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Dashboard
{
    public class DashboardBannerModel
    {
        public int id { get; set; }
        public string imageurl { get; set; }
        public string clicktoactionurl { get; set; }    
    }
}
