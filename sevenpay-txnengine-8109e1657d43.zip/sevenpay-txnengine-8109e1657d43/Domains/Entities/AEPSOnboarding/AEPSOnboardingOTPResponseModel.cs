﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPSOnboarding
{
    public class AEPSOnboardingOTPResponseModel
    {
        public object otpToken { get; set; }
        public object requestId { get; set; }
        public string status { get; set; }
        public string responseCode { get; set; }
        public string responseMessage { get; set; }
        //code added by swapnal
        public string agentReferenceId { get; set; }

    }
}
