﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPSOnboarding
{
    public class AEPSOnboardingOTPValidationResponseModel
    {
        public string requestId { get; set; }
        public string status { get; set; }
        public string responseCode { get; set; }
        public string responseMessage { get; set; }
        public string kycToken { get; set; }
    }
}
