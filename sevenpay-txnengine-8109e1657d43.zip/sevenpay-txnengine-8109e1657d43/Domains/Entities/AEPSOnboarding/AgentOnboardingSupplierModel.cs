﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPSOnboarding
{
    public class AgentOnboardingSupplierModel
    {
        public int serviceid { get; set; }
        public int supplierid { get; set; }
        public string supplierdesc { get; set; }
        public string serviceproviderid { get; set; }
        public int onboarding_status { get; set; }
        public string logourl { get; set; }
    }
}
