﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPSOnboarding
{
    public class AgentCreationModel
    {
        public string RequestType = "AGENTCREATION";
        public string RequestId { get; set; } //= "65881153687949350";
        public string MobileNumber { get; set; } // = "8080607324";
        public string FullName { get; set; } // = "VISHAL SHARMA";
        public string AgentPANNumber { get; set; } // = "OLKKP1393O";
        public DateTime DateOfBirth { get; set; } // = new DateTime(1985, 11, 12);
        public string Email { get; set; } // = "testemailID@gmail.com";
        public string AgentReferenceId { get; set; } // = "AGENT0011";
        public string AgentShopName { get; set; } // = "ShopName01";
        public string Gender { get; set; } // = "M";
        public string CustomerTitle { get; set; } // = "Mr";
        public string CustomerPANNumber { get; set; } // = "OLKKP1393O";
        public double NonAgriculturalIncome { get; set; } // = 9999;
        public string CustomerAddress { get; set; } // = "Test Address";
    }
}
