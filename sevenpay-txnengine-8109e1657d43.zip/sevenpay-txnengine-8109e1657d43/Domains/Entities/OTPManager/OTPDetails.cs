﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.OTPManager
{
    public class OTPDetails
    {
        public string? LoginId { get; set; }

        public string? OTP { get; set; }
        public string? MobileNumber { get; set; }
        public string? Email { get; set; }
        public string? PanNo { get; set; }
        public string? AdharCardNo { get; set; }
        public string? ZoopRefarenceNo { get; set; }
        public int? Status { get; set; }

        public int? ModuleId { get; set; }

        public int? ExpiredTimeInSecond { get; set; }

        public long? Creator { get; set; }
        public DateTime? CreationDate { get; set; }
        public string? IPAddress { get; set; }
        public string? ImeiNo { get; set; }
    }
}
