﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPSS
{
    public class TransactionStatusResponse
    {
        public string responseCode { get; set; }
        public string responseReason { get; set; }
        public TxnList txnList { get; set; }
    }
}
