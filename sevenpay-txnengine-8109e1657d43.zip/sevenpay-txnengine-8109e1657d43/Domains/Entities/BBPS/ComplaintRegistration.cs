﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPSS
{
    public class ComplaintRegistration
    {
        public object xml { get; set; }
        public ComplaintRegistrationResponse complaintRegistrationResp { get; set; }
    }
}
