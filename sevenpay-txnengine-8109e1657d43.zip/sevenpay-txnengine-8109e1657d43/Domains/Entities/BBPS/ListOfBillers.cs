﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class ListOfBillers
    {
        public string billerid { get; set; }
        public string billername { get; set; }
        public string coverage { get; set; }
        public string billeramountoptions { get; set; }
        public int serviceproviderid { get; set; }
        public int bbps_biller_id { get; set; }
        public int adhocpayment { get; set; }
        public int fetchrequirement { get; set; }
        public int paymentexactness { get; set; }
        public int supportbillvalidation { get; set; }
        public int supportpendingstatus { get; set; }
        public int supportdeemed { get; set; }
        public int status { get; set; }
        public int supplierid { get; set; }
    }
}
