﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class OperationResult
    {
        public int p_operationstatus { get; set; }
        public string p_operationmessage { get; set; }
        public int p_operationlogid { get; set; }
        public int p_responsecode { get; set; }
        public string p_responsereason { get; set; }
        public int p_transactionid { get; set; }
        public double p_transactionamount { get; set; }
        public double p_commissionearned { get; set; }
        public string p_txnrefid { get; set; }
    }
}
