﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class BBSSTransactionHistory
    {
        public int orgId { get; set; }
        public string orgName { get; set; }
        public int txnid { get; set; }
        public string txnamount { get; set; }
        public DateTime TxnDate { get; set; }
        public string ConvFees { get; set; }
        public string supptxnnumber { get; set; }
        public int txnstatus { get; set; }
        public string BillerId { get; set; }
        public string BillerName { get; set; }
        public string customermobile { get; set; }
        public string customername { get; set; }
        public string billdate { get; set; }
        public string billperiod { get; set; }
        public string duedate { get; set; }
        public int billamount { get; set; }
        public string paymentmode { get; set; }
        public string requestid { get; set; }
        public int retcommpayout { get; set; }

        public string bbpsctid { get; set; }
        public string inputparam1 { get; set; }
        public string inputparam2 { get; set; }
        public string inputparam3 { get; set; }
        public string inputparam4 { get; set; }

    }
}
