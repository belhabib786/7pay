﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class getTransactionStatus
    {
        public int transactionid { get; set; }
        public int txnvalue { get; set; }
        public int commrecb { get; set; }
        public int retcommpayout { get; set; }
        public int servicecharge { get; set; }
    }
}
