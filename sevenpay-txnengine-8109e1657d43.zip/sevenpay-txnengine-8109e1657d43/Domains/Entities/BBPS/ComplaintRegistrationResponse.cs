﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPSS
{
    public class ComplaintRegistrationResponse
    {
        public string complaintAssigned { get; set; }
        public string complaintId { get; set; }
        public string responseCode { get; set; }
        public string responseReason { get; set; }
    }
}
