﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class TransactionRequest
    {
        public long p_retailerid { get; set; }
        public long p_serviceid { get; set; }
        public long p_supplierid { get; set; }
        public long p_serviceproviderid { get; set; }
        public double p_transactionvalue { get; set; }
        public double p_suppliertransactionvalue { get; set; }
        public double p_service_charge { get; set; }
        public double p_markup { get; set; }
        public int p_transactionmode { get; set; }
        public int p_transactiontype { get; set; }
        public string p_transactionnumber { get; set; }
        public double p_transactionfee { get; set; }
        public string p_ip_address { get; set; }
        public int p_userid { get; set; }
        public string p_customerref1 { get; set; }
        public string p_customerref2 { get; set; }
        public string p_customerref3 { get; set; }
        public string p_billdate { get; set; }
        public string p_billperiod { get; set; }
        public string p_duedate { get; set; }
        public double p_latepayment { get; set; }
        public double p_fixedcharges { get; set; }
        public string p_additonalcharges { get; set; }
        public int p_paymentmode { get; set; }
        public int p_quickpay { get; set; }
        public int p_splitpay { get; set; }
        public long p_orgtxnid { get; set; }
        public string p_custmobno { get; set; }
        public string p_comments { get; set; }
        public string p_billerid { get; set; }
        public string p_inputparam1 { get; set; }
        public string p_inputparam2 { get; set; }
        public string p_inputparam3 { get; set; }
        public string p_inputparam4 { get; set; }
        public string p_cunsumername { get; set; }
        public string p_creatoripaddress { get; set; }
        public long p_creator { get; set; }
        public string p_imei { get; set; }
    }
}
