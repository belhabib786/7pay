﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPSS
{
    public class ComplaintTrackingResponse
    {
        public string ComplaintAssigned { get; set; }
        public string ComplaintId { get; set; }
        public string ComplaintRemarks { get; set; }
        public string ResponseCode { get; set; }
        public string ResponseReason { get; set; }
        public string ComplaintStatus { get; set; }
    }
}
