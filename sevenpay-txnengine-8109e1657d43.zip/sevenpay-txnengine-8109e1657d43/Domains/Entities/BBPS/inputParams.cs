﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPSS
{
    public class inputParams
    {
        public string paramName { get; set; }
        public string paramValue { get; set; }
    }
}
