﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class TransactionUpdateRequest
    {
        public long p_txnid { get; set; }
        public int p_txnstatus { get; set; }
        public string p_supptxnnumber { get; set; }
        public long p_userid { get; set; }
        public string p_remarks { get; set; }
        public string p_sprefno { get; set; }
        public string p_apprefno { get; set; }
        public string p_custref5 { get; set; }
        public string p_modifieripaddress { get; set; }
    }
}
