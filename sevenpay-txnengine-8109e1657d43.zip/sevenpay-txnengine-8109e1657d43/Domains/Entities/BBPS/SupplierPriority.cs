﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class SupplierPriority
    {
        public int supplierid { get; set; }
        public int priority { get; set; }
        public int serviceproviderid { get; set; }
    }
}
