﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class ComplaintModelBbps
    {
        public string billerid { get; set; }
        public string suppliertxnid { get; set; }
        public string complaintdisposition { get; set; }
        public string complaintdesc { get; set; }
        public int status { get; set; }
        public string complaintassigned { get; set; }
        public string refparam1 { get; set; }
        public string refparam2 { get; set; }
        public string refparam3 { get; set; }
        public int createdby { get; set; }
        public string transactionid { get; set; }
        public string complaintid { get; set; }
        public string complainttype { get; set; }
        
    }
}
