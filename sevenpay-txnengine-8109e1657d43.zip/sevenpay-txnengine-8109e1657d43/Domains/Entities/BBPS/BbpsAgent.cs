﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class BbpsAgent
    {
        public string agentId { get; set; }
        public string agentName { get; set; }
        public string GeoCode { get; set; }
        public string MobileNumber { get; set; }
        public string pincode { get; set; }
    }
}
