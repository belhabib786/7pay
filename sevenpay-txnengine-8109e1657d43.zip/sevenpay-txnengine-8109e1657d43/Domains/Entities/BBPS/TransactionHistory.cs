﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPS
{
    public class TransactionHistory
    {
        public int orgid { get; set; }
        public int txnid { get; set; }
        public string requestid { get; set; }
        public string billername { get; set; }
        public string servicename { get; set; }
        public DateTime txndate { get; set; }
        public string billerid { get; set; }
        public int crmid { get; set; }
        public int biller_transaction_id { get; set; }
        public int billamount { get; set; }
        public int transactionfee { get; set; }
        public int status { get; set; }
        public string billdate { get; set; }
        public string duedate { get; set; }
        public string paymentmode { get; set; }
    }
}
