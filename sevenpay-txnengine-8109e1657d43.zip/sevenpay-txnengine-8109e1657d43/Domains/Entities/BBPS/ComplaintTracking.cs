﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.BBPSS
{
    public class ComplaintTracking
    {
        public object Xml { get; set; }
        public ComplaintTrackingResponse ComplaintTrackingResp { get; set; }
    }
   
}
