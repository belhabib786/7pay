﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Services
{
    public class ServiceModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int ServiceId { get; set; }
        public string ServiceName { get; set; }
        public int SupplierId { get; set; }
        public string SupplierName { get; set; }
        public int ServiceProviderId { get; set; }
    }
}
