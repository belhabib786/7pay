﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Transaction
{
    public class TransactionCommonResponse
    {
        public string TransactionId { get; set; }
        public DateTime TransactionDateTime { get; set; } = DateTime.Now;
    }
}
