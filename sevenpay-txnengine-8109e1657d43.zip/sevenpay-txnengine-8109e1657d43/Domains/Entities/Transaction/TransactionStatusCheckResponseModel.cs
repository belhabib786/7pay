﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Transaction
{
	public class TransactionStatusCheckResponseModel
	{
		/*
		 *{"systemReference":"12152","transactionReference":"","status":"3","message":"Ignore Duplicate Message"}
		 */

		public string systemReference { get; set; } // ":"12152",
		public string transactionReference { get; set; } // ":"",
		public string status { get; set; } // ":"3","
		public string message { get; set; } // ":"Ignore Duplicate Message"}
	}
}
