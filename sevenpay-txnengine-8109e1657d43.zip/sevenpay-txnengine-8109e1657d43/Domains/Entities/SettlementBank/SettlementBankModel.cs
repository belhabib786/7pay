﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.SettlementBank
{
    public class SettlementBankModel
    {
        public int OrgId { get; set; } 
        public int PayoutBankId { get; set; } 
        public int BankId { get; set; }
        //code added by swapnal on 17.04.2023
        public string BankName { get; set; }
        public string Ifsc { get; set; }
        public string AccountNumber { get; set; }
        public string AccountholderName { get; set; }
        public int Status { get; set; }
        public int IsPrimary { get; set; }
        public int isdefault { get; set; }
        public int Creator { get; set; }
    }
}
