﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class GetListOfAEPSbank
    {
        public string BankName { get; set; }
        public string SupplierBankId { get; set; }
        public int BankId { get; set; }
    }
}
