﻿using Domains.Entities.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class TransactionInputParameters
    {
        public string p_aadharcardnumber { get; set; }
        public string p_mobilenumber { get; set; }
        public int p_cardtype { get; set; }
        public string p_transdatetime { get; set; }
        public int p_status { get; set; }
        public int p_paymenttype { get; set; }
        public int p_createdby { get; set; }
        public string p_creatoripaddress { get; set; }
        public long p_orgid { get; set; }
        public long p_serviceid { get; set; }
        public long p_supplierid { get; set; }
        public long p_serviceproviderid { get; set; }
        public decimal p_servicecharge { get; set; }
        public decimal p_markup { get; set; }
        public int p_transactionmode { get; set; }
        public double p_transactionvalue { get; set; }
        public string p_bankid { get; set; }
        public int p_savetxn { get; set; }
        public string p_maskedaadhar { get; set; }
        public string p_imeino { get; set; }
        public string p_comment { get; set; }
        public string p_serialno { get; set; }
        public string p_csrid { get; set; }
        public string p_vid { get; set; }
        public string p_consentlanguage { get; set; }
        public string p_stanno { get; set; }
        public string p_devicecode { get; set; }        
	}
}
