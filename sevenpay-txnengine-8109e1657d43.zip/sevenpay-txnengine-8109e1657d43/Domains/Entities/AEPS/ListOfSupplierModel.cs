﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class ListOfSupplierModel
    {
        public int Id { get; set; }
        public int SupplierId { get; set; }
        public int Priority { get; set; }
        public int Status { get; set; }
        public string SupplierName { get; set; }
    }
}
