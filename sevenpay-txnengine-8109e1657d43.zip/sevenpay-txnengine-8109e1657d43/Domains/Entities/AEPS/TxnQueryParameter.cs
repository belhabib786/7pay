﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class TxnQueryParameter
    {
        public int userId { get; set; }
        public int orgId { get; set; }
        public int serviceId { get; set; }
        public int spId { get; set; }
        public int suppId { get; set; }
        public int searchTypeId { get; set; }
        public int searchTypeValue { get; set; }
        public DateTime fromDate { get; set; }
        public DateTime toDate { get; set; }
        public int pageNo { get; set; }
        public int pageSize { get; set; }
    }
}
