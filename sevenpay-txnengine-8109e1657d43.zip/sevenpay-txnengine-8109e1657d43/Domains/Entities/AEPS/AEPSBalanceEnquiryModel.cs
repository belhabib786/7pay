﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class AEPSBalanceEnquiryModel
    {
		public string txnId { get; set; }
		public string orderId { get; set; }
		public string hashKey { get; set; }
		public string agentId { get; set; }
		public string partnerId { get; set; }
		public string channel { get; set; }
		public string aadharNumber { get; set; }
		public bool isVid { get; set; }
		public string bankIIN { get; set; }
		public dynamic biometricData { get; set; }
		public int customerConsent { get; set; }
		public string latitude { get; set; }
		public string longitude { get; set; }
		public string appVersion { get; set; }
		public string appId { get; set; }
		public string agentName { get; set; }
		public string agentAddress { get; set; }
		public string agentPincode { get; set; }
		public string agentDistrict { get; set; }
		public string agentState { get; set; }
		public string agentCountry { get; set; }
		public string terminalId { get; set; }
		public string deviceType { get; set; }
		public string deviceMake { get; set; }
		public string deviceModel { get; set; }
		public string deviceIp { get; set; }
		public string customerName { get; set; }
		public string customerMob { get; set; }
		public string aggregatorCode { get; set; }
	}
}
