﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class TransactionResponseParameters
    {
        public int p_operationstatus { get; set; }
        public string p_operationmessage { get; set; }
        public int p_operationlogid { get; set; }
        public string v_iin { get; set; }
        public int p_txnoperationstatus { get; set; }
        public string p_txnoperationmessage { get; set; }
        public int p_txnoperationlogid { get; set; }
        public string p_stan { get; set; }
        public string p_pincode { get; set; }
        public string p_location { get; set; }
        public string v_finobankname { get; set; }
        public string p_latitude { get; set; }
        public string p_longitude { get; set; }
        public string p_merchantid { get; set; }
        public string p_custname { get; set; }
    }
}
