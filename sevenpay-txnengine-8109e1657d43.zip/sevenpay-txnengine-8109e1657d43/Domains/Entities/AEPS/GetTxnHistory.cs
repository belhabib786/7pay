﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class GetTxnHistory
    {
        public string txnid { get; set; }
        public DateTime txndate { get; set; }
        public string maskedaadhaar { get; set; }
        public string vid { get; set; }
        public string mobilenumber { get; set; }
        public double amount { get; set; }
        public string bankname { get; set; }
        public string suppliername { get; set; }
        public double retcommpayout { get; set; }
        public string txnnumber { get; set; }
        public string supptxnnumber { get; set; }
    }
}
