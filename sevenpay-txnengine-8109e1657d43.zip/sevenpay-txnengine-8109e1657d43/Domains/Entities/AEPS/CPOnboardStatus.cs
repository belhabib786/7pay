﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class CPOnboardStatus
    {
        public int cpbconboardId { get; set; }
        public int serviceid { get; set; }
        public int supplierid { get; set; }
        public int serviceproviderid { get; set; }
        public int onboarding_status { get; set; }
        public string supplierdesc { get; set; }
        public string logourl { get; set; }
        public string refparam1 { get; set; }
        public string refparam2 { get; set; }
        public string refparam3 { get; set; }
    }
}
