﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class AepsAgentRegistrationModel
    {
        
        public int p_modifiedby { get; set; }
        public string p_refparam1 { get; set; }
        public string p_refparam2 { get; set; }
        public string p_refparam3 { get; set; }
        public int p_cpbconboardid { get; set; }
    }
}
