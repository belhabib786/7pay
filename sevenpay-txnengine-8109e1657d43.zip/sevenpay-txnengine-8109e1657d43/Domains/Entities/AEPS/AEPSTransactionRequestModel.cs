﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.AEPS
{
    public class AEPSTransactionRequestModel
    {
		public string p_aadharcardnumber { get; set; } // character varying,
		public string p_mobilenumber { get; set; } //  character varying, 
		public int p_cardtype  { get; set; } // integer,
	    public string p_transdatetime { get; set; } //  character varying,
	    public int p_status  { get; set; } // integer, 
        public int p_paymenttype  { get; set; } // integer,
        public int p_createdby { get; set; } // integer, 
		public string p_creatoripaddress { get; set; } //  character varying, 
		public long p_orgid { get; set; } // bigint,
		public long p_serviceid { get; set; } // bigint, 
		public long p_supplierid { get; set; } // bigint,
		public long p_serviceproviderid { get; set; } // bigint, 
		public double p_servicecharge { get; set; } // numeric,
		public double p_markup { get; set; } // numeric, 
		public int p_transactionmode { get; set; } // integer,
		public double p_transactionvalue { get; set; } // numeric,
		public string p_bankid { get; set; } //  character varying, 
		public int p_savetxn { get; set; } // integer,
		public string p_maskedaadhar { get; set; } //  character varying,
		public string p_imeino { get; set; } //  character varying,
		public string p_comment { get; set; } //  character varying,
		public string p_serialno { get; set; } //  character varying,
		public string p_csrid { get; set; } //  character varying,
		public string p_vid { get; set; } //  character varying,
		public string p_consentlanguage { get; set; } //  character varying,
		public string p_stanno { get; set; } //  character varying
        public string p_devicecode { get; set; }


		/*
        public string p_transactiondate { get; set; } //date    IN	1	[NULL]
        public long p_retailerid { get; set; } //int8    IN	2	[NULL]
        public long p_serviceid { get; set; } //int8    IN	3	[NULL]
        public long p_supplierid { get; set; } //int8    IN	4	[NULL]
        public long p_serviceproviderid { get; set; } //int8    IN	5	[NULL]
        public double p_transactionvalue { get; set; } //numeric IN	6	[NULL]
        public double p_suppliertransactionvalue { get; set; } //numeric IN	7	[NULL]
        public double p_servicecharge { get; set; } //numeric IN	8	[NULL]
        public double p_markup { get; set; } //numeric IN	9	[NULL]
        public int p_transactionmode { get; set; } //int4    IN	10	[NULL]
        public int p_transactiontype { get; set; } //int4    IN	11	[NULL]
        public string p_transactionnumber { get; set; } //varchar IN	12	[NULL]
        public double p_transactionfee { get; set; } //numeric IN	13	[NULL]
        public string p_ip_address { get; set; } //varchar IN	14	[NULL]
        public int p_userid { get; set; } //int4    IN	15	[NULL]
        public string p_customerref1 { get; set; } //varchar IN	16	[NULL]
        public string p_customerref2 { get; set; } //varchar IN	17	[NULL]
        public string p_customerref3 { get; set; } //varchar IN	18	[NULL]
        public long p_orgtxnid { get; set; } //int8    IN	19	[NULL]
        public string p_custmobno { get; set; } //varchar IN	20	[NULL]
        public string p_comments { get; set; } //varchar IN	21	[NULL]
        public string p_imei { get; set; } //varchar IN	22	[NULL]
        */
	}
}
