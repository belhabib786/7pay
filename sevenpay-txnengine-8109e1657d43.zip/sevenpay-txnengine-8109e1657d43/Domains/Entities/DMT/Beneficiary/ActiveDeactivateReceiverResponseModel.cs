﻿using Domains.Entities.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Beneficiary
{
    public  class ActiveDeactivateReceiverResponseModel
    {
        public int responsecode { get; set; } 
        public string outmobilenumber { get; set; }
        public string otp { get; set;  }
    }
}
