﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Beneficiary
{
	public class BeneficiaryAccountValidationRequestModel
	{
		public string accounntnumber { get; set; }
		public string ifsccode { get; set; }
		public int receiverid { get; set; }
	}
}
