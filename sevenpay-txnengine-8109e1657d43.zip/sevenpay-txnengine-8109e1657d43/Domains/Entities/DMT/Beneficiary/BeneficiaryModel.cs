﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Domains.Entities.DMT.Beneficiary
{
    public class BeneficiaryModel
    {
        public long senderid { get; set; }
        public long receiverid {get; set; }
        public string receivername { get; set; }
        public string receivermobile { get; set; }
        public string ifsccode { get; set; }
        public string accountno { get; set; }
        public int creator { get; set; }
        public int bankid { get; set; }
        public int beneficiaryid { get; set; }
        public string emailid { get; set; }
        public string creatoripaddress { get; set; }
        public string bankname { get; set; }
        public int status { get; set; }
        public int isacctvalidated { get; set; }
        public int? isverified { get; set; }
    }
}
