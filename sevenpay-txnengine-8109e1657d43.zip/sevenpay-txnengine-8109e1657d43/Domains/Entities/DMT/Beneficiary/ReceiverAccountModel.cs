﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Beneficiary
{
    public class ReceiverAccountModel
    {
        public string receiver_name { get; set; }
        public string details { get; set; }
        public string comments { get; set; }    
    }
}
