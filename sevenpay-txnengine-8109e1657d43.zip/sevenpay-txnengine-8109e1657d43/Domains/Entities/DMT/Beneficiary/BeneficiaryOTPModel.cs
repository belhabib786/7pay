﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Domains.Entities.DMT.Beneficiary
{
    public class BeneficiaryOTPModel
    {
        [Required]
        [StringLength(20, ErrorMessage = "102|Please enter valid transaction Id.", MinimumLength = 2)]
        [Display(Name = "TransactionId")]
        public string TransactionId { get; set; }

        [Required]
        [StringLength(10, ErrorMessage = "107|Please enter valid Mobile Number.", MinimumLength = 10)]
        [Display(Name = "Mobile Number")]
        public string MobileNo { get; set; }

        [Required]
        [StringLength(5, ErrorMessage = "108|OTP Validation Failed", MinimumLength = 5)]
        [Display(Name = "Random OTP")]
        public string RandomOTP { get; set; }

        [Required]
        public DateTime CreatedOn { get; set; }

        [Required]
        public DateTime ValidUpto { get; set; }
    }
}
