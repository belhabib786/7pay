﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Common
{
    public class BankModel
    {
        public int bankid { get; set; }
        public string bankname { get; set; }
        public string bankcode { get; set; }
        public int impsenabled { get; set; }
        public string acclength { get; set; } = "0";
        public int status { get; set; }
        public int activegateway { get; set; }
        public int isifscrequired { get; set; }
        public string defaultifsc { get; set; }
        public int mmidenabled { get; set; }
        public string iin { get; set; }
    }
}
