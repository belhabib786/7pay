﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Domains.Entities.DMT.Transaction
{
    public class DMTTransactionModel
    {
        [Required]
        [StringLength(20, ErrorMessage = "102|Please enter valid transaction Id.", MinimumLength = 2)]
        [Display(Name = "TransactionId")]
        public string TransactionId { get; set; }

        [Required(ErrorMessage = "103|Please eneter valid Partner transaction Id..")]
        [StringLength(50, ErrorMessage = "103|Please eneter valid Partner transaction Id..", MinimumLength = 7)]
        [Display(Name = "PartnerRefId")]
        public string PartnerRefId { get; set; }

        [Required(ErrorMessage = "104|API key is not Valid")]
        [StringLength(16, ErrorMessage = "104|API key is not Valid", MinimumLength = 16)]
        [Display(Name = "APIKey")]
        public string APIKey { get; set; }

        [Required(ErrorMessage = "107|Please enter valid Mobile Number.")]
        [StringLength(10, ErrorMessage = "107|Please enter valid Mobile Number.", MinimumLength = 10)]
        [Display(Name = "Mobile Number")]
        public string SenderMobile { get; set; }

        [Required(ErrorMessage = "124|Please Enter Valid Beneficiary Mobile Number.")]
        [StringLength(10, ErrorMessage = "124|Please Enter Valid Beneficiary Mobile Number.", MinimumLength = 10)]
        [Display(Name = "Beneficiary Mobile")]
        public string BeneficiaryMobile { get; set; }

        public string Currency { get; set; }

        public string BeneficiaryCode { get; set; }

        [Required(ErrorMessage = "123|Please Enter Beneficiary Name.")]
        [StringLength(50, ErrorMessage = "123|Beneficiary Name is not valid.", MinimumLength = 4)]
        [Display(Name = "Beneficiary Name")]
        public string BeneficiaryName { get; set; }

        [Required(ErrorMessage = "115|Please enter valid Bank IFSC Code.")]
        public string BankIFSCCode { get; set; }

        [Required(ErrorMessage = "116|Please enter Bank Account Number.")]
        public string BankAccountNumber { get; set; }

        [Required(ErrorMessage = "125|Please Enter transaction amount.")]
        [Range(1, 5000, ErrorMessage = "125|Value for {0} must be between {1} and {2}.")]
        [Display(Name = "Transaction Amount")]
        public double Amount { get; set; }

        public string RoutingType { get; set; }

        //[Required(ErrorMessage = "128|Please enter valid Bank Transaction Id.")]
        //public string BankTransactionId { get; set; }

        //[Required(ErrorMessage = "129|Invalid response code")]
        //public string ResponseCode { get; set; }

        //[Required(ErrorMessage = "129|Invalid response code")]
        //public string Response { get; set; }

        //public string Beneficiary { get; set; }

        [Required(ErrorMessage = "127|Please Enter Business Identification code")]
        [Display(Name = "Business Identificatin Code")]
        public string IdentificationCode { get; set; }

        public string Comments { get; set; }
        public string Filler1 { get; set; }
        public string Filler2 { get; set; }
        public string Filler3 { get; set; }
        public string Filler4 { get; set; }
        public string Filler5 { get; set; }
    }
}
