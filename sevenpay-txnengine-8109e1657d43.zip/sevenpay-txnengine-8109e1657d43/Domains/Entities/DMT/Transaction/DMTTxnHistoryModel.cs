﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using System.Transactions;

namespace Domains.Entities.DMT.Transaction
{
    public class DMTTxnHistoryModel
    {
        public long totalcount { get; set; } 
        public long txnid { get; set; } 
        public DateTime txndate { get; set; }
        public long orgid { get; set; }
        public long distributorid { get; set; }
        public long channelid { get; set; }
        public int servicemixid { get; set; }
        public int suppspmapid { get; set; }
        public long serviceid { get; set; }
        public long supplierid { get; set; }
        public long serviceproviderid { get; set; }
        public double txnvalue { get; set; }
        public double supptxnvalue { get; set; }
        public double servicecharge { get; set; }
        public double markup { get; set; }
        public int paymentmode { get; set; }
        public int txnmode { get; set; }
        public int txntype { get; set; }
        public string txnnumber { get; set; }
        public string supptxnnumber { get; set; }
        public string originaltxnid { get; set; }
        public string custref1 { get; set; }
        public string custref2 { get; set; }
        public string ip_address { get; set; }
        public int txnstatus { get; set; }
        public string remarks { get; set; }
        public int status { get; set; }
        public int creator { get; set; }
        public DateTime creationdate { get; set; }
        public int modifier { get; set; }
        public DateTime modificationdate { get; set; }
        public double transactionfee { get; set; }
        public DateTime success_date { get; set; }
        public DateTime reverse_date { get; set; }
        public string mobilenumber { get; set; }
        public string firstname { get; set; }
        public string middlename { get; set; }
        public string lastname { get; set; }
        public string receivername { get; set; }
        public string bankname { get; set; }
        public string accountno { get; set; }
        public int bankid { get; set; }
    }
}
