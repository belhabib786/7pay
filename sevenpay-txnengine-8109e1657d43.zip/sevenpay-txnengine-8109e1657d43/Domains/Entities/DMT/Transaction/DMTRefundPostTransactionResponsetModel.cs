﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Transaction
{
	public class DMTRefundPostTransactionResponsetModel
	{
		public long p_loginid { get; set; }             
		public string p_ref_param2 { get; set; }
	}
}
