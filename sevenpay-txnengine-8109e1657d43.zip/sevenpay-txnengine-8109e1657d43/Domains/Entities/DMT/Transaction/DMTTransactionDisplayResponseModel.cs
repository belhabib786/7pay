﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Transaction
{
    public class DMTTransactionDisplayResponseModel
    {
        public int p_recbcommtype { get; set; }
        public int p_recbbaseparam { get; set; }
        public int p_slabcount { get; set; }
        public double p_transactionfee1 { get; set; }
        public double p_transactionfee2 { get; set; }
        public double p_transactionfee3 { get; set; }
        public double p_transactionfee4 { get; set; }
        public double p_transactionfee5 { get; set; }
        public double p_slab1 { get; set; }
        public double p_slab2 { get; set; }
        public double p_slab3 { get; set; }
        public double p_slab4 { get; set; }
        public double p_slab5 { get; set; }
        public int p_commtype { get; set; }
        public int p_baseparam { get; set; }
        public double p_retailershare { get; set; }
        public double p_distshare { get; set; }
        public double p_bankifyshare { get; set; }
        public int p_crid { get; set; }
        public int p_distid { get; set; }
        public long p_suppspmapid { get; set; }
        public long p_svcoffid { get; set; }
        public int p_operationstatus { get; set; }
        public string p_operationmessage {get;set; }
        public int p_operationlogid { get; set; }

    }
}
