﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Transaction
{
    public class DMTTransactionDisplayRequestModel
    {
        /*
         * sample values
         * select "transaction".stp_fino_getpretxnchargemodeldisplay(cast(current_date as date),3,6,9,10,7000.00,7000.00,0,0,2,2,6,'192.168.44.76','6','7','');

         */
        public string p_transactiondate { get; set; }  //cast(current_date as date)
        public int p_retailerid { get; set; } //3
        public int p_serviceid { get; set; } //6
        public int p_supplierid { get; set; } //9
        public int p_serviceproviderid { get; set; } //10
        public double p_transactionvalue { get; set; } //7000.00
        public double p_suppliertransactionvalue { get; set; } //7000.00
        public double p_servicecharge { get; set; } //0
        public double p_markup { get; set; } //0
        public int p_transactionmode { get; set; } //2
        public int p_transactiontype { get; set; } //2
        public int p_userid { get; set; } //6
        public string p_ip_address { get; set; } //'192.168.44.76'
        public string p_custref1 { get; set; } //6
        public string p_custref2 { get; set; } //7
        public string p_custref3 { get; set; } //''
    }
}
