﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Transaction
{
    public class DMTPostTransactionRequestModel
    {
        public long p_txnid { get; set; } // bigint,
        public int p_txnstatus { get; set; } //  integer, 
        public string p_supptxnnumber { get; set; } //  character varying, 
        public long p_userid { get; set; } //  bigint,
        public string p_remarks { get; set; } //  text, 
        public string p_sprefno { get; set; } //  character varying, 
        public string p_finoremarks { get; set; } //  character varying, 
        public string p_benename { get; set; } //  character varying, 
        public string p_trndes { get; set; } //  character varying, 
        public string p_acctcode { get; set; } //  character varying, 
        public string p_ipaddresss { get; set; } //  character varying
    }
}
