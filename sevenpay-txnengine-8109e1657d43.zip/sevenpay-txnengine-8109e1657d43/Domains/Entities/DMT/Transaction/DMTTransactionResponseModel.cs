﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Transaction
{
    public class DMTTransactionResponseModel
    {
        public int p_operationstatus { get; set; } // integer, 
        public string p_operationmessage { get; set; } //character varying, 
        public int p_operationlogid { get; set; } // integer, 
        public string p_transactiontime { get; set; } // character varying
    }
}
