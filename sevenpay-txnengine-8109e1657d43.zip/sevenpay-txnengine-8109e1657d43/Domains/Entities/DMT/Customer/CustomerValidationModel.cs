﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Domains.Entities.DMT.Customer
{
    public class CustomerValidationModel
    {
        [Required(ErrorMessage = "102|Please enter valid transaction Id.")]
        [StringLength(20, ErrorMessage = "102|Please enter valid transaction Id.", MinimumLength = 2)]
        [Display(Name = "TransactionId")]
        public string TransactionId { get; set; }

        [Required(ErrorMessage = "103|Please eneter valid Partner transaction Id..")]
        [StringLength(50, ErrorMessage = "103|Please eneter valid Partner transaction Id..", MinimumLength = 7)]
        [Display(Name = "PartnerRefId")]
        public string PartnerRefId { get; set; }

        [Required(ErrorMessage = "107|Please enter valid Mobile Number.")]
        [StringLength(10, ErrorMessage = "107|Please enter valid Mobile Number.", MinimumLength = 10)]
        [Display(Name = "Mobile Number")]
        public string MobileNo { get; set; }

        [Required(ErrorMessage = "108|OTP Validation Failed")]
        [StringLength(5, ErrorMessage = "108|OTP Validation Failed", MinimumLength = 5)]
        [Display(Name = "Customer OTP")]
        public string CustomerOTP { get; set; }

        [Required(ErrorMessage = "104|API key is not Valid")]
        [StringLength(16, ErrorMessage = "104|API key is not Valid", MinimumLength = 16)]
        [Display(Name = "APIKey")]
        public string APIKey { get; set; }


        public string UpdateOn { get; set; }
    }
}
