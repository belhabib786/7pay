﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.DMT.Customer
{
    public class CustomerOTPVerificationModel
    {
        public string mobilenumber { get; set; } 
        public string otp { get; set; }
        public int moduleid { get; set; }
    }
}
