﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Domains.Entities.DMT.Customer
{
    public class CustomerBalanceModel
    {
        [Required]
        [StringLength(20, ErrorMessage = "102|Please enter valid transaction Id.", MinimumLength = 2)]
        [Display(Name = "TransactionId")]
        public string TransactionId { get; set; }

        [Required]
        [StringLength(10, ErrorMessage = "107|Please enter valid Mobile Number.", MinimumLength = 10)]
        [Display(Name = "Mobile Number")]
        public string MobileNo { get; set; }

        [Required]
        public string Balance { get; set; }

        public string UpdateOn { get; set; }
    }
}
