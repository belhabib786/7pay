﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Domains.Entities.DMT.Customer
{
    /*
    CreateCustomer
        {
        "rrn":12345678912345678912,
         "orgId":12,
         "spId":23,
         "supplierId":23,
         "customerMob":"7776940888",
         "kycStatus":"0","
         "pancardStatus":"0",
         "cardStatus":"0",**************
         "lname":"",
         "name":"Kriti",
         "mname":"",
         "dateOfBirth":"02/03/2020",
         "laddress":"Mumbai", **************
         "lcityId":"Mumbai", *************
         "lstateId":"Maharashtra", ************* 
         "lpincode":"400925", *************
         "pcityId":"Mumbai", *************
         "pstateId":"Maharashtra", *************
         "ppincode":"400925", *************
         "paddress":"Mumbai", *************
         "alternateMobNo":"",
         "email":"",
         "gender":"F",
         "identityDocType":"0",
         "identityDocNo":"BgQkkDrhg4g4KF52pwD4Lt0",
         "addressDocType":"0",
         "addressDocNo":"dBgQ2khg6540rdd5Dd5p4dws",
         "isOTPValidated":"0",
         "channelType":"1", *************
         "udf1":"",
         "udf2":"",
         "udf3":"",
         "udf4":"","
         "udf5":"","
         "userId":"" *************
        }
        }


    (mobilenumber, sendername, dob, curraddress1, curraddress2, currcityareaid, currpincode, 
    permaddress1, permaddress2, permcityareaid, perpincode, kycstatus, sameascurradd, 
    isotpverified, status, creator, creationdate, modifier, modificationdate, declraccptedby, 
    declraccptedon, remitterid, creatoripaddress, isimported, imeino)



    */
    public class CustomerModel
    {
        public long SenderId { get; set; }
        public string Title { get; set; }

        [Required(ErrorMessage = "105|Please eneter valid First Name.")]
        [StringLength(50, ErrorMessage = "105|Please eneter valid First Name.", MinimumLength = 3)]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        public string MiddleName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        public string Gender { get; set; }

        [Required(ErrorMessage = "107|Please enter valid Mobile Number.")]
        [StringLength(10, ErrorMessage = "107|Please enter valid Mobile Number.", MinimumLength = 10)]
        [Display(Name = "Mobile Number")]
        public string mobilenumber { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string CurrentAddress1 { get; set; }
        public string CurrentAddress2 { get; set; }
        public int CurrentCityAreaId { get; set; }
        public int CurrentPinCode { get; set; }
        public string PermAddress1 { get; set; }
        public string PermAddress2 { get; set; }
        public int PermCityAreaId { get; set; }
        public int PermPinCode { get; set; }
        [Required]
        [Display(Name = "Is KYC Updated")]
        public int kycStatus { get; set; } = 0;
        public int sameasCurradd { get; set; } = 0;
        [Required]
        [Display(Name = "Is Validate")]
        public int IsOtpVerified { get; set; } = 0;
        public int status { get; set; } = 0;

        public int creator { get; set; }
        //public DateTime creationDate { get; set; }
        public int modifier { get; set; }
        //public DateTime modificationDate { get; set; }
        //public int declraccptedBy { get; set; }
        //public DateTime declraccptedOn { get; set; }
        //public int remitterId { get; set; }
        public string creatorIPaddress { get; set; }
        //public string isimported { get; set; }
        //public string imeino { get; set; }
        public string Filler1 { get; set; }
        public string Filler2 { get; set; }
        public string Filler3 { get; set; }
        public string Filler4 { get; set; }
        public string Filler5 { get; set; }
        
        /*
        public string AlternateMobileNumber { get; set; }
        public int IdentityDocType { get; set; }
        public string IdentityDocNo { get; set; }
        public int IaddressDocType { get; set; }
        public string AddressDocNo { get; set; }
        public string Balance { get; set; }
        public string AadhaarNo { get; set; }
        */
    }
}
