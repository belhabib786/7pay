﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.UserManagement
{
    public class UpdateMobileNo
    {
        public string mobilenumber { get; set; }
        public int userid { get; set; }
    }
}
