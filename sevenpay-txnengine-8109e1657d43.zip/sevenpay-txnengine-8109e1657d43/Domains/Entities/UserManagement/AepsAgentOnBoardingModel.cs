﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.UserManagement
{
    public class AepsAgentOnBoardingModel
    {
        public string mobilenumber { get; set; }
        public string firstname { get; set; }
        public string middlename { get; set; }
        public string lastname { get; set; }
        public string emailid { get; set; }
        public string dob { get; set; }
        public string gender { get; set; }
        public string AgentReferenceId { get; set; }
        public string AgentShopName { get; set; }
        public string pancard { get; set; }
        public string perm_dist { get; set; }
        public string bcPincode { get; set; }
        public string bcDistrict { get; set; }
        public string busi_district { get; set; }
        public string busi_sub_district { get; set; }
        public string perm_house_no { get; set; }
        public string perm_road { get; set; }
    }
}
