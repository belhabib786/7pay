﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.UserManagement
{
    public class UserProfileModel
    {
        public string FirstName { get; set; } 
        public string MiddleName { get; set; } 
        public string LastName { get; set; } 
        public string LoginId { get; set; } 
        public string EmailId { get; set; } 
        public string MobileNumber { get; set; } 
        public string AlternateNumber { get; set; } 
        public int OrgId { get; set; } 
		public string OrgCode { get; set; } 
        public string OrgName { get; set; } 
        public int Orgtype { get; set; } 
		public int Status { get; set; }
		public string DOB { get; set; } 
        public string Perm_House_No { get; set; } 
        public string Perm_Road { get; set; } 
        public string Perm_Village { get; set; } 
        public string Perm_Taluka { get; set; } 
        public string Perm_Pincode { get; set; }
        public string Busi_House_No { get; set; } 
        public string Busi_Road { get; set; } 
        public string Busi_Village { get; set; } 
        public string Busi_Taluka { get; set; } 
        public string Busi_Pincode { get; set; } 
        public string BankId { get; set; } 
        public string IFSCCode { get; set; } 
        public string AccountType { get; set; } 
        public string AccountNumber { get; set; } 
        public string Pancard { get; set; } 
        public string Aadharcard { get; set; } 
    }
}
