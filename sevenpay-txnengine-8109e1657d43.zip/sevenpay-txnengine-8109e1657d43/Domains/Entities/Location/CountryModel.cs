﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Location
{
    public class CountryModel
    {
        public int CountryId { get; set; }
        public string ConuntryName { get; set; }
        public string Status { get; set; }
        public string CountryCode { get; set; }
    }
}
