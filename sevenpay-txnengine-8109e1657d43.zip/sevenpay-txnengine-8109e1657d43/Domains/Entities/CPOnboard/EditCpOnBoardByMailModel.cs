﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.CPOnboard
{
    public class EditCpOnBoardByMailModel
    {
        public int orgid { get; set; }
        public string? ref_param1 { get; set; }
        public string? otp { get; set; }
    }
}
