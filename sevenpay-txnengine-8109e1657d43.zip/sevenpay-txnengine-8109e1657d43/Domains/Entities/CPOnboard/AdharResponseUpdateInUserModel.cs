﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.CPOnboard
{
    public class AdharResponseUpdateInUserModel
    {
        public string? dob { get; set; }
        public string? gender { get; set; }
        public int userid { get; set; }
    }
}
