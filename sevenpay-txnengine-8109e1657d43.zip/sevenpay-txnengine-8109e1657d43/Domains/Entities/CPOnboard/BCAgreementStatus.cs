﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.CPOnboard
{
    public class BCAgreementStatus
    {
        public int Status { get; set; }
        public int orgid { get; set; }
        public DateTime CreateData { get; set; }
        public string consenttype { get; set; }
    }
}
