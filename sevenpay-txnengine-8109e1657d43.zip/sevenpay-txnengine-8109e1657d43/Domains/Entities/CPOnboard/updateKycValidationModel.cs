﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.CPOnboard
{
    public class updateKycValidationModel
    {
        public string sevenpayrefno { get; set; }
        public string zooponerefno { get; set; }
        public int status { get; set; }
        public long sr_no { get; set; }
    }
}
