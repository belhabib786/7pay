﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.CPOnboard
{
    public class AddKycServiceModel
    {
        public int p_idtype { get; set; }
        public int p_creator { get; set; }
        public int p_serviceid { get; set; }
        public int p_supplierid { get; set; }
        public int p_serviceproviderid { get; set; }
        public double p_servicecharge { get; set; }
        public int p_status { get; set; }
    }
}
