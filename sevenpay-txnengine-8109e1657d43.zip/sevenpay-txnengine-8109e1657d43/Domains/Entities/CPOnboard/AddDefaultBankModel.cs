﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.CPOnboard
{
    public class AddDefaultBankModel
    {
        public int orgid { get; set; }
        public int bankid { get; set; }
        public string accountnumber { get; set; }
        public string ifsc { get; set; }
        public string accountholdername { get; set; }
    }
}
