﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.CPOnboard
{
    public class AddKycVerificationModel
    {
        public int p_kycidtype { get; set; }
        public string p_kycno { get; set; }
        public string p_sevenpayrefno { get; set; }
        public string p_zooponerefno { get; set; }
        public int p_orgid { get; set; }
        public int p_status { get; set; }
    }
}
