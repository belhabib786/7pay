﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.CPOnboard
{
    public class AdharMessagingresponse
    {
        public string request_id { get; set; }
        public string is_otp_sent { get; set; }
        public string is_number_linked { get; set; }
        public string is_aadhaar_valid { get; set; }
    }
}
