﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.CPOnboard
{
    public class CheckKycStatus
    {
        public int KYCdetailsStatus { get; set; }
        public int KYCdetailsOnBoard { get; set; }
        public int channelpartnersStatus { get; set; }
        public int channelpartnersOnBoard { get; set; }
        public int onBoardStatus { get; set; }
    }
}
