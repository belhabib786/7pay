﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Payments
{
    public class PaymentModeModel
    {
        public int paymentCode { get; set; }
        public string paymentMode { get; set; }
        public int status { get; set; }
    }
}
