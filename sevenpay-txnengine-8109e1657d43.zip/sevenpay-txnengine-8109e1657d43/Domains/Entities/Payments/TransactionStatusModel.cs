﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Payments
{
    public class TransactionStatusModel
    {

        public long paymentid { get; set; }
        public string instrumentnumber { get; set; }      
        public int status { get; set; }

    }
}
