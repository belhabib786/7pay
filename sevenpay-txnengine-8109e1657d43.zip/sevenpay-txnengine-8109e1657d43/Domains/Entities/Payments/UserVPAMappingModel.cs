﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Payments
{
    public class UserVPAMappingModel
    {
        public long id { get; set; }
        public long orgId { get; set; }  
        public string vpa { get; set; } 
        public int status { get; set; } 
    }
}
