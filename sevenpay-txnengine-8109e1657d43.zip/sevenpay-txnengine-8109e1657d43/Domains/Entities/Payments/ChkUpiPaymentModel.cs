﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Payments
{
    public class ChkUpiPaymentModel
    {      
        public string paymentId { get; set; }
        public int status { get; set; }
    }
}

