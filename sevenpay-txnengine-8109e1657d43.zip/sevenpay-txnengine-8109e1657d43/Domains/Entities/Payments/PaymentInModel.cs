﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Payments
{
    public class PaymentInModel
    {
        /*
             * CREATE OR REPLACE FUNCTION payments.func_acc_addpayments(
             *  p_orgid bigint, p_paymentmode integer, p_paymentdate date, 
             *  p_amount numeric, p_bankid integer, p_pgid integer, 
             *  p_bankaccount character varying, p_status integer, 
             *  p_remark character varying, p_issueingbankid integer, 
             *  p_creator integer, p_bankpayinslip character varying, 
             *  p_instrumentnumber character varying, 
             *  p_issuingifsccode character varying, p_vpa character varying)
                RETURNS TABLE(p_operationstatus integer, 
                p_operationmessage character varying, 
                p_operationlogid integer, p_paymentid bigint)
             */

        public long p_orgid { get; set; }
        public int p_paymentmode { get; set; } // integer, 
        //public string p_paymentdate { get; set; } //  date, 
        public double p_amount { get; set; } //  numeric, 
        public int p_bankid { get; set; } //  integer, 
        public int p_pgid { get; set; } //  integer,
        public string p_bankaccount { get; set; } //  character varying, 
        public int p_status { get; set; } //  integer,
        public string p_remark { get; set; } //  character varying, 
        public int p_issueingbankid { get; set; } //  integer,
        public int p_creator { get; set; } //  integer
        public string p_bankpayinslip { get; set; } //  character varying,
        public string p_instrumentnumber { get; set; } //  character varying, 
        public string p_issuingifsccode { get; set; } //  character varying, 
        public string p_vpa { get; set; } //  character varying

        //Add By Anurag
        public string? p_fileFormat { get; set; }
        public string p_depositDate { get; set; }
        public string p_depositTime { get; set; }

    }
}
