﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Payments
{
    public class PayOutModel
    {
        public long p_orgid { get; set; }
		public long p_operationlogid { get; set; }
		public int p_type { get; set; }
        public int p_userid { get; set; }
        public int p_status { get; set; }
        public double p_transferamount { get; set; }
        public string p_ipaddress { get; set; }
        public string p_imeino { get; set; }
        public int p_txnpaymode { get; set; }
        public double p_transactioncharge { get; set; }
        public double p_gstcharge { get; set; }
        public int p_isrealtime { get; set; }
        public int p_bankid { get; set; }
        public string p_accountno { get; set; }
        

    }
}
