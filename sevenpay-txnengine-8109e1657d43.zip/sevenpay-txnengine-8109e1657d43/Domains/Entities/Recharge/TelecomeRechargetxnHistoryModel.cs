﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Recharge
{
    public class TelecomeRechargetxnHistoryModel
    {
        public long txnCount { get; set; }
        public long transactionid { get; set; }
        public DateTime txndate { get; set; }
        public double suppliertxnvalue { get; set; }
        public string txntype { get; set; }
        public string firstname { get; set; }
        public string orgname { get; set; }
        public double retcommpayout { get; set; }
        public double distcommpayout { get; set; }
        public double commrecb { get; set; }
        public string servicecode { get; set; }
        public string servicename { get; set; }
        public double txnvalue { get; set; }
        public string supptxnnumber { get; set; }
        public string orgcode { get; set; }
        public string suppliercode { get; set; }
        public string suppliername { get; set; }
        public string serviceprovidername { get; set; }
        public string remarks { get; set; }
        public DateTime creationdate { get; set; }
        public string mobilenumber { get; set; }
        public string status { get; set; }
    }
}
