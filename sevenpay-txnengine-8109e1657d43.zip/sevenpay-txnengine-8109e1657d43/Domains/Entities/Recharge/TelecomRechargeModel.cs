﻿using Domains.Entities.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Recharge
{
    public class TelecomRechargeModel
    {
        public string mobileNumber { get; set; }
        [Required(ErrorMessage = "Please provide valid service provider.")]
        public string serviceProvider { get; set; }
        public string rechargeType { get; set; }
        public string isSpecial { get; set; }
    }
}
