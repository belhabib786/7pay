﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Recharge
{
    public class TelecomServiceProviderModel
    {
        public int serviceprovider { get; set; }
        public string supplierCode { get; set; }    
        public string supplierName { get; set; }
        public string serviceid { get; set; }
        public string supplierid { get; set; }
        public string logourl { get; set; }
    }
}