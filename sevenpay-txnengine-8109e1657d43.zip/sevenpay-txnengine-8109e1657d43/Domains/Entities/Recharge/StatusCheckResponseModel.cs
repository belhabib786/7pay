﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Recharge
{
	//{"systemReference":"32879","transactionReference":"","status":"3","message":"Ignore Duplicate Message"}
	public class StatusCheckResponseModel
    {
        public string? systemReference { get; set; }
        public string? transactionReference { get; set; }
        public string? status { get; set; }
        public string? message { get; set; }
        //public string? RechargeRequestDateTime { get; set; }
    }
}
