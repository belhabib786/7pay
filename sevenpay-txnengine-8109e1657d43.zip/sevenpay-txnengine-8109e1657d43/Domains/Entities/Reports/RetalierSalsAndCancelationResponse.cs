﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Reports
{
    public class RetalierSalsAndCancelationResponse
    {
        public string Retailer { get; set; }
        public long txn_count { get; set; }
        public double Value { get; set; }
        public long cancellation_count { get; set; }
        public double cancellation_value { get; set; }
    }
}
