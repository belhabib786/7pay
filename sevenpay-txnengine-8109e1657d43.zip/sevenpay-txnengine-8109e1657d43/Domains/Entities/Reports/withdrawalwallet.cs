﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Reports
{
    public class withdrawalwallet
    {
        
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public long p_orgid { get; set; }
        public int p_offsetrows { get; set; }
        public int p_fetchrows { get; set; }
    }
}
