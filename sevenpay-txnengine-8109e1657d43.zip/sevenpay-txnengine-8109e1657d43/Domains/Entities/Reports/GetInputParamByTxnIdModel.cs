﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Reports
{
	public class GetInputParamByTxnIdModel
	{
		public string suppliertxnno { get; set; }
		public string sprefno { get; set; }
		public int userid { get; set; }
		public string p_remarks { get; set; }
	}
}
