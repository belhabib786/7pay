﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.Entities.Reports
{
    public class withdrawalwalletdetails
    {
        public long totalCount { get; set; }
        public string OrgCode { get; set; }
        public long PaymentId { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal TransferAmount { get; set; }
        public decimal TransactionCharge { get; set; }
        public decimal DebitedAmount { get; set; }
        public string PaymentType { get; set; }
        public string Status { get; set; }
        public string AccountNo { get; set; }
        public string IFSCCode { get; set; }
        public string BankReferenceNumber { get; set; }
        public string Remarks { get; set; }
    }
}
