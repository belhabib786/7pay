﻿using Domains.Entities.MATM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IMATMRepository
    {
        Task<IEnumerable<MATMSupplierPriorityModel>> GetMATMSupplierPriority(int serviceId, int productId, CancellationToken cancellationToken = default);
        Task<MATMMerchantDetailsModel> GetMATMMerchantDetails(int orgid, CancellationToken cancellationToken = default);
        Task<MATMTransactionResponseModel> InitMATM(MATMTransactionRequestModel entity, CancellationToken cancellationToken = default);
        Task<MATMTransactionResponseModel> PostInitMATM(MATMPostTransactionRequestModel entity, CancellationToken cancellationToken = default);
    }
}
