﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IRepositoryManager
    {
        public IUsersRepository usersRepository { get; }
        public IAepsRepository aepsRepository { get; }
        public ICPOnboardRepository cPOnboardRepository { get; }
        public IOTPRepository otpRepository { get; }
        public ISettlementBankRepository settlementBankRepository { get; }
        public ILocationRepository locationRepository { get; }
        public IDashboardRepository dashboardRepository { get; }
        public ITelecomRechargeRepository telecomRechargeRepository { get; }
        public IDthRechargeRepository dthRechargeRepository { get; }
        public IDMTTransactionRepository dmttransactionRepository { get; }
        public IPaymentRepository paymentRepository { get; }
        public IAEPSOnboardingRepository aepsOnboardingRepository { get; }
        public IReportsRepository reportsRepository { get; }
        public IBBPSRepository bBPSRepository { get; }
        public IMATMRepository matmRepository { get; }
    }
}
