﻿using Domains.Entities.Payments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IPaymentRepository
    {
        Task<IEnumerable<PaymentModeModel>> GetPaymentMode(CancellationToken cancellationToken = default);
        Task<int> UpdateVPA(UserVPAMappingModel model, CancellationToken cancellationToken = default);
        Task<IEnumerable<UserVPAMappingModel>> GetVPA(long orgid, CancellationToken cancellationToken = default);
        Task<int> UpdateVPAStatus(long orgid, int status, CancellationToken cancellationToken = default);
        Task<PaymentInResponseModel> InitiatePayment(PaymentInModel paymentInModel, CancellationToken cancellationToken = default);
        Task<PaymentInResponseModel> UpdatePayment(PaymentUpdateInModel paymentUpdateInModel, CancellationToken cancellationToken = default);
        Task<IEnumerable<ChkUpiPaymentModel>> CheckUpiPaymentStatus(long paymentid, int paymentmode, CancellationToken cancellationToken = default);
        Task<IEnumerable<GetSevenPayBankListModel>> GetSevenPayBankList(long orgid, CancellationToken cancellationToken = default);
        Task<PaymentInResponseModel> UPIUpdatePayment(UPIPostTransactionRequestModel upiPostTransactionRequestModel, CancellationToken cancellationToken = default);
        Task<PaymentInResponseModel> UPIPayOutPayment(PayOutModel payOutModel, CancellationToken cancellationToken = default);
        //Task<IEnumerable<TransactionStatusModel>> TransactionStatus(long paymentId, CancellationToken cancellationToken = default);
        Task<TransactionStatusModel> TransactionStatus(long paymentId, CancellationToken cancellationToken = default);


    }
}
