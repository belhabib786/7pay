﻿using Domains.Entities.CPOnboard;
using Domains.Entities.Reports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IReportsRepository
    {
        Task<IEnumerable<txndetailsresponse>> GetTxnreportDetails(gettxndetailsreports entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<GetretailerledgerResponse>> GetledgerDetails(Getretailerledger entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<GetretailerledgerResponse>> GetwithdrawalledgerDetails(cashwithdrawalledgerRequest entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<AllpaymentdetailsResponse>> GetAllpaymentdetails(Getallpaymentdetails entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<GetPaymentHistoryResponse>> GetAllPaymentHistory(GetPaymentHistory entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<GetcancelTxnResponse>> GetTxnCancelOrSsucsessDetails(GetcancelTxn entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<RetalierSalsAndCancelationResponse>> GetRetalierSalsAndCancelation(RetalierSalsAndCancelation entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<withdrawalwalletdetails>> getwithdrawalwalletdetails(withdrawalwallet entity, CancellationToken cancellationToken = default);
        Task<GetInputParamByTxnIdModel> GetInputParamByTxnId(long p_transactionid, CancellationToken cancellationToken = default);

	}
}
