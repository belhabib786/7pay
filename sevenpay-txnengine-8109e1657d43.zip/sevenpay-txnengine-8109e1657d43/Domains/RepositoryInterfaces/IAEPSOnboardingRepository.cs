﻿using Domains.Entities.AEPS;
using Domains.Entities.AEPSOnboarding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IAEPSOnboardingRepository
    {
        Task<IEnumerable<AgentOnboardingSupplierModel>> GetListOfSupplierAsync(long orgid, CancellationToken cancellationToken = default);
    }
}
