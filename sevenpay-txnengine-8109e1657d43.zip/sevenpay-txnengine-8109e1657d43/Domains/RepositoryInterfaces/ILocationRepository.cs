﻿using Domains.Entities.Location;
using Domains.Entities.UserManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface ILocationRepository
    {
        Task<IEnumerable<CountryModel>> GetCountryList(CancellationToken cancellationToken = default);
        Task<CountryModel> GetCountryById(int countryId, CancellationToken cancellationToken = default);
        Task<IEnumerable<StateModel>> GetStateList(CancellationToken cancellationToken = default);
        Task<IEnumerable<StateModel>> GetStateByCountryId(int countryId, CancellationToken cancellationToken = default);
        Task<IEnumerable<CityModel>> GetCityList(CancellationToken cancellationToken = default);
        Task<IEnumerable<CityModel>> GetCityBystateId(int stateId, CancellationToken cancellationToken = default);
        Task<IEnumerable<CityAreaModel>> GetCityAreaByPinCode(int PinCode, CancellationToken cancellationToken = default);
        Task<CityAreaModel> GetCityAndStateByPinCode(int PinCode, CancellationToken cancellationToken = default);
    }
}
