﻿using Domains.Entities.Common;
using Domains.Entities.Recharge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface ITransactionGenericRepository
    {
        Task<TelecomRechargeTransactionResponseModel> ProcessRequest(T entity, CancellationToken cancellationToken = default);
        //Task<ResponseModel> StatusCheck(T entity, CancellationToken cancellationToken = default);
        //Task<ResponseModel> ProcessRefund(T entity, CancellationToken cancellationToken = default);
    }
}
