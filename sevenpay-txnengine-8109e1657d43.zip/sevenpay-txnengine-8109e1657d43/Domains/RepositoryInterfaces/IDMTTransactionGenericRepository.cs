﻿using Domains.Entities.DMT.Transaction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IDMTTransactionGenericRepository<T>
    {
        Task<DMTTransactionResponseModel> ProcessRequest(T entity, CancellationToken cancellationToken = default);
        Task<DMTStatusCheckResponseModel> StatusCheck(T entity, CancellationToken cancellationToken = default);
        Task<DMTRefundResponseModel> ProcessRefund(T entity, CancellationToken cancellationToken = default);
    }
}
