﻿using Domains.Entities.SettlementBank;
using Domains.Entities.UserManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface ISettlementBankRepository
    {
        Task<int> AddAsync(SettlementBankModel entity, CancellationToken cancellationToken = default);
        Task<SettlementBankModel> GetAsync(int orgId, int payoutBankId, CancellationToken cancellationToken = default);
        Task<IEnumerable<SettlementBankModel>> ListAsync(int orgId, CancellationToken cancellationToken = default);
        Task<int> EnableDisableAsync(int orgId, int payoutBankId, CancellationToken cancellationToken = default);
        Task<int> EnableDisablePostAsync(int orgId, int payoutBankId, CancellationToken cancellationToken = default);
        Task<int> VerificationAsync(int orgId, int payoutBankId, CancellationToken cancellationToken = default);
    }
}
