﻿using Domains.Entities.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IDashboardRepository
    {
        Task<IEnumerable<ServiceModel>> GetServicesAsync(int orgId, CancellationToken cancellationToken = default);
    }
}
