﻿using Domains.Entities.Common;
using Domains.Entities.DMT.Beneficiary;
using Domains.Entities.DMT.Common;
using Domains.Entities.DMT.Customer;
using Domains.Entities.DMT.Transaction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace Domains.RepositoryInterfaces
{
    public interface IDMTTransactionRepository : IDMTTransactionGenericRepository<DMTTransactionModel>
    {
        Task<CustomerOTPResponseModel> CreateCustomer(CustomerModel entity, CancellationToken cancellationToken = default);
        Task<CustomerModel> GetCustomer(string mobileNumber, CancellationToken cancellationToken = default);
        Task<CustomerModel> ValidateCustomerOTP(string mobileNumber, string otp, int moduleId, CancellationToken cancellationToken = default);
        Task<IEnumerable<BankModel>> GetBanksInfo(string searchString, CancellationToken cancellationToken = default);
        Task<IEnumerable<BankModel>> GetPraiorityBanksInfo( CancellationToken cancellationToken = default);
        Task<BankIFSCModel> GetBanksInfoIFSCCode(string ifscCode, CancellationToken cancellationToken = default);
        Task<BeneficiaryModel> CreateReceiver(BeneficiaryModel entity, CancellationToken cancellationToken = default);
        //Task<ResponseModelDto> GenerateReceiverOTP(T entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<BeneficiaryModel>> GetListOfReceivers(long senderid, CancellationToken cancellationToken = default);
        Task<BeneficiaryModel> GetReceiverDetails(long receiverid, CancellationToken cancellationToken = default);

        Task<ActiveDeactivateReceiverResponseModel> ActiveDeactivateReceiver(long receiverid, int status, int creator, string creatoripaddress, CancellationToken cancellationToken = default);
        Task<int> ValidateOTPActiveDeactivateReceiver(string p_mobilenumber, long receiverid, int otp, int p_moduleid, int p_status, CancellationToken cancellationToken = default);
        Task<DMTTransactionResponseModel> ValidateReceiverAccount(DMTTransactionRequestModel entity, CancellationToken cancellationToken = default);
        Task<DMTTransactionDisplayResponseModel> GetServiceCharges(DMTTransactionDisplayRequestModel entity, CancellationToken cancellationToken = default);
        Task<DMTTransactionResponseModel> FundTransfer(DMTTransactionRequestModel entity, CancellationToken cancellationToken = default);
        Task<DMTTransactionResponseModel> PostFundTransfer(DMTPostTransactionRequestModel entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<DMTTxnHistoryModel>> GetDMTTxnHistoryAsync(int userId, int orgId, int serviceId, int spId, int suppId, DateTime fromDate, DateTime toDate, string mobileno, long txnid, int p_offsetrows, int p_fetchrows, CancellationToken cancellationToken = default);
        Task<DMTTxnHistoryModel> GetDMTTxnDetailsAsync(int txnid, CancellationToken cancellationToken = default);
        Task<ActiveDeactivateReceiverResponseModel> RefundOTPRequest(long transactionid, double transactionamount, int creator, string creatoripaddress, CancellationToken cancellationToken = default);
        Task<DMTRefundPostTransactionResponsetModel> RefundOTPVerify(string p_mobilenumber, int otp, int p_moduleid, CancellationToken cancellationToken = default);


        /*
        //Task<ResponseModelDto> FundTransfer(T entity, CancellationToken cancellationToken = default);
        //Task<ResponseModelDto> GetTransactionStatus(T entity, CancellationToken cancellationToken = default);
        //Task<ResponseModelDto> RefundTransaction(T entity, CancellationToken cancellationToken = default);
        */

        //Task<ResponseModelDto> GetTransactionHistory(T entity, CancellationToken cancellationToken = default);
        //Task<ResponseModelDto> GenerateRefundOTP(T entity, CancellationToken cancellationToken = default);
        //Task<ResponseModelDto> GetCityStatebyPinCode(T entity, CancellationToken cancellationToken = default);
        //Task<ResponseModelDto> GetListOfBanks(T entity, CancellationToken cancellationToken = default);
        //Task<ResponseModelDto> SearchBankByIFSC(T entity, CancellationToken cancellationToken = default);
    }
}
