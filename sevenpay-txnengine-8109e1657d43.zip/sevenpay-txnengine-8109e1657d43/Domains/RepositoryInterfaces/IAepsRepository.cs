﻿using Domains.Entities.AEPS;
using Domains.Entities.BBPS;
using Domains.Entities.CPOnboard;
using Domains.Entities.DMT.Common;
using Domains.Entities.UserManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IAepsRepository
    {
        Task<IEnumerable<ListOfSupplierModel>> GetListOfSupplierAsync(int serviceId, CancellationToken cancellationToken = default);
        Task<CPOnboardStatus> GetCPOnboardStatusAsync(int orgid,int serviceid, CancellationToken cancellationToken = default);
        Task<IEnumerable<GetListOfAEPSbank>> GetListOfAEPSbankAsync(string supplier_bankid, int bankid,int aeps_enabled, CancellationToken cancellationToken = default);
        Task<IEnumerable<GetTxnHistory>> GetTxnHistoryAsync(int orgid, int txnid, int status, string mobilenumber, DateTime fromDate, DateTime toDate, CancellationToken cancellationToken = default);
        Task<AEPSTransactionResponseModel> AEPSPreTransactionAsync(AEPSTransactionRequestModel entity, CancellationToken cancellationToken = default);
        Task<AEPSTransactionResponseModel> AEPSPostTransactionAsync(AEPSPostTransactionRequestModel entity, CancellationToken cancellationToken = default);
		Task<IEnumerable<BankModel>> GetBanksInfo(string searchString, CancellationToken cancellationToken = default);
        Task<PostPSOnboardingInsert> OnboardingInsertPS(PostPSOnboardingInsert entity, CancellationToken cancellationToken = default);
        Task<OperationResult> AgentRegistrationService(AepsAgentRegistrationModel entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<getSuppPriorityforProdId>> getSuppPriorityforProdIdAsync(int serviceId, int productid, int orgId, CancellationToken cancellationToken = default);
        Task<TransactionResponseParameters> PreTransactionCall(TransactionInputParameters entity, CancellationToken cancellationToken = default);
        Task<OperationResult> AepsPostTxnDetails(AepsTransactionPostCallModel entity, CancellationToken cancellationToken = default);
    }
}
