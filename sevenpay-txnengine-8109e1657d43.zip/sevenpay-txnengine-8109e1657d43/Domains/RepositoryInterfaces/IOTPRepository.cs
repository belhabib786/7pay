﻿using Contracts.CPOnBoard;
using Domains.Entities.OTPManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IOTPRepository
    {
        Task<OTPDetails> Get(string loginId, int moduleId, CancellationToken cancellationToken = default);
        Task<OTPDetails> GetByMobile(string mobilenumber, int moduleId, CancellationToken cancellationToken = default);
        Task<OTPDetails> GetByPanNo(string ref_param2, int moduleId, CancellationToken cancellationToken = default);
        Task<OTPDetails> GetByAdharNoNo(string ref_param3, int moduleId, CancellationToken cancellationToken = default);
        Task<OTPDetails> GetByEmail(string ref_param1, int moduleId, CancellationToken cancellationToken = default);
        Task<OTPDetails> VerifyByMobileAndOtp(string mobilenumber, string otp, CancellationToken cancellationToken = default);
        Task<OTPDetails> VerifyByEmailAndOtp(string email, string otp, CancellationToken cancellationToken = default);
        Task<OTPDetails> AddAsync(OTPDetails entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsDto> UpdateAsync(EditCpDetailsDto entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsDto> UpdateAdharAsync(EditCpDetailsDto entity, CancellationToken cancellationToken = default);
    }
}
