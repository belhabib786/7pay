﻿using Domains.Entities.BBPS;
using Domains.Entities.Reports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IBBPSRepository
    {
        Task<IEnumerable<BbpsAgent>> getBBPSAgentId(int orgId, CancellationToken cancellationToken = default);
        Task<IEnumerable<SupplierPriority>> getSupplierPriority(int serviceId, int productId, CancellationToken cancellationToken = default);
        Task<IEnumerable<ListOfBillers>> getListOfBillers(int serviceId, int productid, CancellationToken cancellationToken = default);
        Task<IEnumerable<BillerInputParams>> getBillerInputParams(int bbpsbillerid, CancellationToken cancellationToken = default);
        Task<IEnumerable<getTransactionStatus>> getTransactionStatus(int orgid,int txnid, CancellationToken cancellationToken = default);
        Task<IEnumerable<TransactionHistory>> getTransactionHistory(int orgid,DateTime FromDate, DateTime ToDate, CancellationToken cancellationToken = default);
        Task<OperationResult> GetTxnForInitiatePayment(TransactionRequest entity, CancellationToken cancellationToken = default);
        Task<ComplaintModelBbps> AddComplaint(ComplaintModelBbps entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<BBSSTransactionHistory>> getBBSSTxnHistory(int? orgid, DateTime? FromDate, DateTime? ToDate, string? searchById,string? searchByValue, int? p_offsetrows, int? p_fetchrows, CancellationToken cancellationToken = default);
        Task<IEnumerable<TransactionUpdateResult>> TxnreportUpdateDetails(TransactionUpdateRequest request, CancellationToken cancellationToken = default);
    }
}
