﻿using Contracts.Transaction.Recharge;
using Contracts.Transaction;
using Domains.Entities.Recharge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IDthRechargeRepository
    {
        Task<RechargeTransactionResponseModel> ProcessRequest(TransactionCommonRequestDto<CommonRechargeDto> entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<DthServiceProviderModel>> GetServiceProvider(CancellationToken cancellationToken = default);
        Task<RechargeTransactionResponseModel> UpdateProcessRequest(RechargePostTransactionRequestModel entity, CancellationToken cancellationToken = default);
    }
}
