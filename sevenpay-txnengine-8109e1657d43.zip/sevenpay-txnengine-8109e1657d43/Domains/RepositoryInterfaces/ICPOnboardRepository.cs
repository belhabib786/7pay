﻿using Contracts.Common;
using Contracts.CPOnBoard;
using Domains.Entities.AEPS;
using Domains.Entities.CPOnboard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface ICPOnboardRepository
    {
        Task<BCAgreementStatus> checkBCAgreementAsync(int orgid, string consenttype, CancellationToken cancellationToken = default);
        Task<CheckKycStatus> checkOnboardStatusAsync(int orgid, CancellationToken cancellationToken = default);
        Task<IEnumerable<CheckOnboardStatus>> checkAllOnboardStatusByOrgidAsync(int orgid, CancellationToken cancellationToken = default);
        Task<ImpsEneableStatus> checkBankImpsStatussync(string ifsc_code, CancellationToken cancellationToken = default);
        Task<EditCPOnBoardModel> VerifyOtpForCP(EditCPOnBoardModel entity, CancellationToken cancellationToken = default);
        Task<EditCPOnBoardModel> VerifyOtpForCPFailed(EditCPOnBoardModel entity, CancellationToken cancellationToken = default);
        Task<EditCpOnBoardByMailModel> VerifyOtpForCPByMail(EditCpOnBoardByMailModel entity, CancellationToken cancellationToken = default);
        Task<EditCpOnBoardByMailModel> VerifyOtpForCPByMailFailed(EditCpOnBoardByMailModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> VerifyPanNo(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> VerifyPanNoFailed(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> EditPanNo(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> VerifyAdharNo(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> VerifyAdharNoFailed(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> EditAdharKycNo(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCPOnBoardModel> EditKycAsync(EditCPOnBoardModel entity, CancellationToken cancellationToken = default);
        Task<EditCPOnBoardModel> EditOtpStatusAsync(EditCPOnBoardModel entity, CancellationToken cancellationToken = default);
        Task<EditCpOnBoardByMailModel> EditMailKycAsync(EditCpOnBoardByMailModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> EditCpDetailsChannelPartenerAsync(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> EditCpDetailsChannelPartenerFailedAsync(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<InitiatBusinessinfo> EditCpDetailsKycDetailsAsync(InitiatBusinessinfo entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> EditSelfImageAsync(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> InisietBusinessInfoAsync(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> VerifyAccountNo(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        //Task<EditCpDetailsModel> VerifyAccountNoOfline(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> VerifyAccountNoFailed(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> EditAccountNo(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> EditAccountNoOfline(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> UpdateSelfImage(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EditCpDetailsModel> IfSelfImageFaield(EditCpDetailsModel entity, CancellationToken cancellationToken = default);
        Task<EmailOtpVerificationModel> UpdateUsersdetails(EmailOtpVerificationModel entity, CancellationToken cancellationToken = default);
        Task<AdharResponseUpdateInUserModel> AdhaDobAndGenderUpdate(AdharResponseUpdateInUserModel entity, CancellationToken cancellationToken = default);
        Task<UpdateAdharDetailsWithCpDetails> UpdateAdharDetailInCpTable(UpdateAdharDetailsWithCpDetails entity, CancellationToken cancellationToken = default);
        Task<AddConsentModel> UpdateConsent(AddConsentModel entity, CancellationToken cancellationToken = default);
        Task<OnBoardStatusDetailsModel> UpdateOnBoardStages(OnBoardStatusDetailsModel entity, CancellationToken cancellationToken = default);
        Task<updateKycServiceModel> UpdateKycService(updateKycServiceModel entity, CancellationToken cancellationToken = default);
        Task<OpperetionStausModel> AddKycService(AddKycServiceModel entity, CancellationToken cancellationToken = default);
        Task<OpperetionStausModel> AddKycVerification(AddKycVerificationModel entity, CancellationToken cancellationToken = default);
        Task<updateKycValidationModel> UpdateKycVerification(updateKycValidationModel entity, CancellationToken cancellationToken = default);
        Task<AddDefaultBankModel> AddDefaultBank(AddDefaultBankModel entity, CancellationToken cancellationToken = default);
    }
}
