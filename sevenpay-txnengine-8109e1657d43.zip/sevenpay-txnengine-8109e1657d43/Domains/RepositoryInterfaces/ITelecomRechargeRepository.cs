﻿using Contracts.Transaction.Recharge;
using Contracts.Transaction;
using Domains.Entities.DMT.Transaction;
using Domains.Entities.Recharge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Domains.Entities.Reports;

namespace Domains.RepositoryInterfaces
{
    public interface ITelecomRechargeRepository 
    {
        Task<RechargeTransactionResponseModel> ProcessRequest(TransactionCommonRequestDto<CommonRechargeDto> entity, CancellationToken cancellationToken = default);

        Task<IEnumerable<TelecomServiceProviderModel>> GetServiceProvider(CancellationToken cancellationToken = default);
        Task<RechargeTransactionResponseModel> UpdateProcessRequest(RechargePostTransactionRequestModel entity, CancellationToken cancellationToken = default);
        Task<IEnumerable<TelecomeRechargetxnHistoryModel>> TelecomeRechargetxnHistory(TelecomeRechargeRequestModel entity, CancellationToken cancellationToken = default);
    }
}
