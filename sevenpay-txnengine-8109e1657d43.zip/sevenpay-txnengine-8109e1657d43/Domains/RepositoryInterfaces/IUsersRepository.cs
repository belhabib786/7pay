﻿using Domains.Entities.AccountDetais;
using Domains.Entities.AEPS;
using Domains.Entities.CPOnboard;
using Domains.Entities.UserManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domains.RepositoryInterfaces
{
    public interface IUsersRepository
    {
        Task<Users> GetAuthenticateUserAsync(string loginId, string loginPassword, string ipAddress, CancellationToken cancellationToken = default);
        Task<int> ChangePasswordAsync(string loginId, string loginPassword, string newloginPassword, CancellationToken cancellationToken = default);
        Task<WalletBalanceModel> GetWalletBalanceAsync(string loginId, CancellationToken cancellationToken = default);
        Task<WalletBalanceModel> GetCashWalletBalanceAsync(string loginId, CancellationToken cancellationToken = default);
        Task<UserProfileModel> GetUserProfileAsync(string loginId, CancellationToken cancellationToken = default);
        Task<Users> AddAsync(Users entity, CancellationToken cancellationToken = default);
        Task<Users> GetUserByLoginId(string loginId, CancellationToken cancellationToken = default);
        Task<Users> GetUserByUserId(int userid, CancellationToken cancellationToken = default);
        Task<GetTokenData> GetUserToken(int loginid, CancellationToken cancellationToken = default);
        Task<UpdateMobileNo> UpdateMobile(UpdateMobileNo entity, CancellationToken cancellationToken = default);
        Task<Users> GetUserByMobile(string mobilenumber, CancellationToken cancellationToken = default);
        Task<Users> GetUserByMobileAndUserId(string mobilenumber, int userid, CancellationToken cancellationToken = default);
        Task<Users> GetUserToValidateByMobileAndUserId(string mobilenumber, int userid, CancellationToken cancellationToken = default);
        Task<Users> GetUserByEmail(string emailid, CancellationToken cancellationToken = default);
        Task<Users> GetUserByEmailAndUserid(string emailid, int userid, CancellationToken cancellationToken = default);
        Task<Users> GetUserValidateByEmailAndUserid(string emailid, int userid, CancellationToken cancellationToken = default);
        Task<IEnumerable<Users>> GetSubUserListByOrgId(long orgId, CancellationToken cancellationToken = default);
        Task<int> UpdateMobileToken(long loginId, string devicetoken, CancellationToken cancellationToken = default);
        Task<UpdateUsers> UpdateUserAsync(UpdateUsers updateUsersDto, CancellationToken cancellationToken = default);
        Task<int> ActivateOrDeActivateUser(int userId, int status, CancellationToken cancellationToken = default);
        Task<IEnumerable<UserDetails>> GetAllUserAsync(int userid, int orgid, string? loginid, string? emailid, string? mobilenumber, CancellationToken cancellationToken = default);
        Task<AepsAgentOnBoardingModel> GetAepsAgent(int orgid, int userid, CancellationToken cancellationToken = default);
        Task<UserOnBoardingModel> GetOnBoardingStatusByOrgId(long orgId, CancellationToken cancellationToken = default);
        Task<OpperetionStausModel> InsertToken(InsertTokenDataModel entity, CancellationToken cancellationToken = default);
        Task<GetTokenDataByUserid> GetTokenDataByUserid(long userid,string ipaddress, CancellationToken cancellationToken = default);
        Task<UpdateUsersToken> UpdateUserToken(UpdateUsersToken entity, CancellationToken cancellationToken = default);
        Task<int> UpdatePassword(string loginId, string password, CancellationToken cancellationToken = default);
    }
}
